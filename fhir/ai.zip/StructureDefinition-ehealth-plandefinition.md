# ehealth-plandefinition - eHealth Infrastructure v10.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ehealth-plandefinition**

## Resource Profile: ehealth-plandefinition 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-plandefinition | *Version*:10.0.2 |
| Active as of 2026-09-10 | *Computable Name*:ehealth-plandefinition |

# Introduction

This resource allows for the definition of various types of plans as a sharable, consumable, and executable artifact. The resource is general enough to support the description of a broad range of clinical artifacts such as clinical decision support rules, order sets and protocols.

# Scope and Usage

In scope of the eHealth infrastructure, PlanDefinitions are used for defining tele-medicine plans. A PlanDefinition is comprised by potentially a number of subplans (each also represented as a PlanDefinition), and a number of activities each represented by an ActivityDefinition instance. These in turn can specify an activity to be performed, for instance measuring of a measure or answering of a Questionnaire.

Once a PlanDefinition and all the PlanDefinition, ActivityDefinition, and Questionnaire instances comprising it has a status set to other than draft, it can be itself be set to active. With that status it can be used as a template for applying it into a CarePlan bound to a specific Patient. The CarePlan then references the PlanDefinition as its definition.

### Governance principles

PlanDefinitions (subplans), Questionnaires and ActivityDefinitions can be modified independently. Often by people in different organisations. PlanDefinitions (subplans), Questionnaires and ActivityDefinitions, can all be reused in different top level PlanDefinitions.

The following principles ensures that the owner of a resource can make controlled updates when resources maintained by other organisations are updated.

These principles are valid for PlanDefinitions, ActivityDefinitions, and Questionnaires. Plan is used as an example in the following principles:

* Each plan has a version and a status
* While a plan version is being worked on it shall be in status: **draft**
* When a plan version is approved it changes status to **active** and is now ready to be used by CarePlans or as a subplan in another plan.
* A plan with status: **active** can be **retired**, but cannot otherwise change, except for **ehealth-useContext**. Status **retired** means that new references to the plan cannot be created. Existing plans may still continue to use the retired version.
* If a plan needs to be updated, a new version must be created with status: **draft**. The new version will be a separate resource with a new id and version, but the same name as the previous version.
* References to plans in FHIR are always to a specific resource id. In practice this means that a reference will identify a specific (Name, Version) combination.
* If a subplan is available in a new active version, that the parent plan wants to use, then a new version of the parent plan must be created and then the reference can be updated to the new subplan.

Example: A new ActivityDefinition should be added to an existing PlanDefinition.

1. Read the existing PlanDefinition (Version: 1)
1. Bump the version to 2, change the status to**draft**, remove the id.
1. Add a reference to the new ActivityDefinition in**action.definition**
1. Call Create with the modified plan. This will create a new version of the plan in the database with the new ActivityDefinition added.

#### Properties allowed to be changed in regard to the status

* Draft 
* No restriction
 
* Active 
* Only **ehealth-useContext**
* **Status** can be changed to **retired**
 
* Retired 
* Only **ehealth-useContext**
 

### Update restrictions

The element `ehealth-modifier-role` specifies one or more Organization and each Organization's role in maintaining the PlanDefinition:

* `ehealth-modifier-role.reference` references the Organization
* `ehealth-modifier-role.role` set to `owner` means that the referenced Organization can update the resource and alter the entities referenced by `ehealth-modifier-role`, for instance, by adding more co-authors.
* `ehealth-modifier-role.role` set to `co-author` means that the referenced Organization can update the resource but not alter the element `ehealth-modifier-role`.

### Setting up an action trigger

An action in the plan can be set up with an action trigger that depend on one or more other actions in the plan. Although set up in the PlanDefinition and ActivityDefinition plane, the conditions are event driven and take place in the CarePlan and ServiceRequest plane, that is in the Patient specific use of the PlanDefinition.

An example use is a PlanDefinition with two actions: answering of an initial Questionnaire and answering of a follow-up Questionnaire. The `PlanDefinition.action` specifying answering of the follow-up Questionnaire can be set up with an action trigger with a trigger condition specifying a number of measurement submissions (in this case, submission of QuestionnaireResponse) of the first action, answering of the initial Questionnaire. In the action trigger, it is also specified what reaction is to be performed on the depending action once the conditions are met. An example reaction is activation. This way, an action trigger defined in a PlanDefinition can be used such that submitted measurements on one or more activities can trigger activation of another activity in the Patient specific CarePlan.

An action trigger is defined in the element `action.ehealth-actionTrigger` with contents as follows:

* `ehealth-triggerCondition` is a list of the conditions. Each trigger condition has contents: 
* `actionID` contains the actionID of the triggering action which shall be another action in the same PlanDefinition. It follows that actions intended to be used as trigger conditions must be given an actionID for the `triggerCondition` and the `actionTrigger` to function.
* `count` specifies the number of measurements that must be submitted before the particular trigger condition is fulfilled.
 
* `triggerBehavior` specifies whether all or at least one of the trigger conditions must be met
* `offset` the offset applied to timing bounds of the depending action when trigger conditions are met and the reaction is performed.
* `action` specifies what reaction shall be performed when trigger conditions are met. For now, activation of paused activity, that is change of ServiceRequest `status` from `on-hold` to `active`, is the only reaction defined.

### Referencing information material

PlanDefinitions can reference information material intended for [Practitioner](StructureDefinition-ehealth-practitioner.md), [Patient](StructureDefinition-ehealth-patient.md) or [RelatedPerson](StructureDefinition-ehealth-relatedperson.md). The material can be in the form of embedded material (of reasonable size) or referenced videos, PDF-files or printed material. Information material is contained or referenced using a [DocumentReference](StructureDefinition-ehealth-documentreference.md) resource and referenced from the PlanDefinition using the `relatedArtifact` element.

### Title and description

A PlanDefinition has two sets of titles and desriptions. `title` and `description` are intended for the citizens and should be of a natural language. Whereas `ehealth-employee-title` and `usage` are intended for clinicians and should be of a specific and professional language.

### Actions and Timing

Each `action` element must either have sub-actions or an `action.definition`. This makes it possible to create top-level group-actions that functions as containers for a number of related sub-actions.

It is possible to specify timing for each action in the `action.timing[x]` element. When the PlanDefiniton is applied to a Patient this will override any timing specified on the related ActivityDefinition.

### UseContext

The `useContext` element specifies the context in which the PlanDefinition is applicable. It consists of:

* **`useContext.code`** – Defines the context type.
* **`useContext.valueCodeableConcept`** – Defines the context value (e.g., a specific condition when `useContext.code` is `focus`).

When using `useContext.code` from [http://ehealth.sundhed.dk/vs/ehealth-usage-context-type](https://ehealth.sundhed.dk/fhir/ValueSet-ehealth-usage-context-type.html), the `useContext.valueCodeableConcept` is validated against the ValueSet outlined for the chosen `useContext.code` as described in the description sections on [ehealth-usage-context-type ValueSet page](https://ehealth.sundhed.dk/fhir/ValueSet-ehealth-usage-context-type.html).

> **Note:** The `useContext` element can be updated at any time, regardless of the PlanDefinition status.

**Example:** An PlanDefinition applicable only to a specific intended solution (codes are fictional):

```
{
  "useContext": [
    {
      "code": {
        "system": "http://terminology.hl7.org/CodeSystem/usage-context-type",
        "code": "program"
      },
      "valueCodeableConcept": {
        "system": "http://ehealth.sundhed.dk/cs/ehealth-program",
        "code": "some-intended-solution",
        "display": "Some Intended Solution"
      }
    }
  ]
}

```

### ApprovalDate

The date when the PlanDefinition's `status` is set to `active`, whether it is initially created as active or changed to active, will be recorded in the `approvalDate` field.

**Usages:**

* Refer to this Profile: [ehealth-careplan](StructureDefinition-ehealth-careplan.md) and [ehealth-plandefinition](StructureDefinition-ehealth-plandefinition.md)
* CapabilityStatements using this Profile: [plan](CapabilityStatement-plan.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/dk.ehealth.sundhed.fhir.ig.core|current/StructureDefinition/StructureDefinition-ehealth-plandefinition.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ehealth-plandefinition.csv), [Excel](StructureDefinition-ehealth-plandefinition.xlsx), [Schematron](StructureDefinition-ehealth-plandefinition.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ehealth-plandefinition",
  "url" : "http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-plandefinition",
  "version" : "10.0.2",
  "name" : "ehealth-plandefinition",
  "status" : "active",
  "date" : "2026-09-10T10:12:06+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "objimpl",
    "uri" : "http://hl7.org/fhir/object-implementation",
    "name" : "Object Implementation Information"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "PlanDefinition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/PlanDefinition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "PlanDefinition",
      "path" : "PlanDefinition"
    },
    {
      "id" : "PlanDefinition.extension",
      "path" : "PlanDefinition.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "PlanDefinition.extension:recommendation",
      "path" : "PlanDefinition.extension",
      "sliceName" : "recommendation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-recommendation"]
      }]
    },
    {
      "id" : "PlanDefinition.extension:intendedAudience",
      "path" : "PlanDefinition.extension",
      "sliceName" : "intendedAudience",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-intendedAudience"]
      }]
    },
    {
      "id" : "PlanDefinition.extension:modifierRole",
      "path" : "PlanDefinition.extension",
      "sliceName" : "modifierRole",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-modifier-role"]
      }]
    },
    {
      "id" : "PlanDefinition.extension:employeeTitle",
      "path" : "PlanDefinition.extension",
      "sliceName" : "employeeTitle",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-employee-title"]
      }]
    },
    {
      "id" : "PlanDefinition.extension:predecessor",
      "path" : "PlanDefinition.extension",
      "sliceName" : "predecessor",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-predecessor"]
      }]
    },
    {
      "id" : "PlanDefinition.extension:base",
      "path" : "PlanDefinition.extension",
      "sliceName" : "base",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-base"]
      }]
    },
    {
      "id" : "PlanDefinition.extension:baseEnvironment",
      "path" : "PlanDefinition.extension",
      "sliceName" : "baseEnvironment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-base-environment"]
      }]
    },
    {
      "id" : "PlanDefinition.version",
      "path" : "PlanDefinition.version",
      "min" : 1
    },
    {
      "id" : "PlanDefinition.jurisdiction",
      "path" : "PlanDefinition.jurisdiction",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://ehealth.sundhed.dk/vs/jurisdiction"
      }
    },
    {
      "id" : "PlanDefinition.topic",
      "path" : "PlanDefinition.topic",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://ehealth.sundhed.dk/vs/topic-type"
      }
    },
    {
      "id" : "PlanDefinition.library",
      "path" : "PlanDefinition.library",
      "type" : [{
        "code" : "canonical",
        "targetProfile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-library"]
      }]
    },
    {
      "id" : "PlanDefinition.action.extension",
      "path" : "PlanDefinition.action.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "PlanDefinition.action.extension:overviewUsageMode",
      "path" : "PlanDefinition.action.extension",
      "sliceName" : "overviewUsageMode",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-overviewUsageMode"]
      }]
    },
    {
      "id" : "PlanDefinition.action.extension:ehealth-actionTrigger",
      "path" : "PlanDefinition.action.extension",
      "sliceName" : "ehealth-actionTrigger",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-actionTrigger"]
      }]
    },
    {
      "id" : "PlanDefinition.action.extension:includeAsExtra",
      "path" : "PlanDefinition.action.extension",
      "sliceName" : "includeAsExtra",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-include-as-extra"]
      }]
    },
    {
      "id" : "PlanDefinition.action.extension:aggregateGroupId",
      "path" : "PlanDefinition.action.extension",
      "sliceName" : "aggregateGroupId",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-aggregate-group-id"]
      }]
    },
    {
      "id" : "PlanDefinition.action.definition[x]",
      "path" : "PlanDefinition.action.definition[x]",
      "type" : [{
        "code" : "canonical",
        "targetProfile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-activitydefinition",
        "http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-plandefinition"]
      }]
    }]
  }
}

```
