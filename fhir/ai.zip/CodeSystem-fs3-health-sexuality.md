# FS III, Seksualitet - eHealth Infrastructure v10.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FS III, Seksualitet**

## CodeSystem: FS III, Seksualitet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/fs3-health-sexuality | *Version*:10.0.2 |
| Active as of 2019-02-02 | *Computable Name*:FS III, Seksualitet |

 
FS III, Seksualitet 

 This Code system is referenced in the content logical definition of the following value sets: 

* [FS III, helbredstilstande](ValueSet-fs3-health.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fs3-health-sexuality",
  "url" : "http://ehealth.sundhed.dk/cs/fs3-health-sexuality",
  "version" : "10.0.2",
  "name" : "FS III, Seksualitet",
  "title" : "FS III, Seksualitet",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "FS III, Seksualitet",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "complete",
  "concept" : [{
    "code" : "SEXUALITY",
    "display" : "Problemer med seksualitet",
    "designation" : [{
      "language" : "da",
      "value" : "Problemer med seksualitet"
    }]
  }]
}

```
