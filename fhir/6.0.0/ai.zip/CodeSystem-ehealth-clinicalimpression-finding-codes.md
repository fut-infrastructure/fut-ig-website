# ClinicalImpression Finding Codes - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ClinicalImpression Finding Codes**

## CodeSystem: ClinicalImpression Finding Codes 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/clinicalimpression-finding-codes | *Version*:6.0.0 |
| Active as of 2019-01-29 | *Computable Name*:ClinicalImpressionFindingCodes |

 
Clinical Impression Finding Codes 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ClinicalImpressionFindingCodes](ValueSet-ehealth-clinicalimpression-finding-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-clinicalimpression-finding-codes",
  "url" : "http://ehealth.sundhed.dk/cs/clinicalimpression-finding-codes",
  "version" : "6.0.0",
  "name" : "ClinicalImpressionFindingCodes",
  "title" : "ClinicalImpression Finding Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-01-29T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "Clinical Impression Finding Codes",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [
    {
      "code" : "deprecated",
      "uri" : "http://hl7.org/fhir/concept-properties#deprecated",
      "description" : "Indicates that the concept is deprecated and should not be used",
      "type" : "dateTime"
    }
  ],
  "concept" : [
    {
      "code" : "red-question-answer",
      "display" : "red question and answer combination",
      "definition" : "Applied to a single question and answer pair, this indicates a red combination. Applied as summary to multiple question and answer pairs in a questionnaire response, this indicates at least one red combination found.",
      "designation" : [
        {
          "language" : "da",
          "value" : "Rød spørgsmål/svar-kombination fundet i spørgeskemabesvarelse"
        }
      ]
    },
    {
      "code" : "yellow-question-answer",
      "display" : "yellow question and answer combination",
      "definition" : "Applied to a single question and answer pair, this indicates a yellow combination. Applied as summary to multiple question and answer pairs in a questionnaire response, this indicates at least one yellow combination found and no red combinations found.",
      "designation" : [
        {
          "language" : "da",
          "value" : "Gul spørgsmål/svar-kombination fundet i spørgeskemabesvarelse"
        }
      ]
    },
    {
      "code" : "green-question-answer",
      "display" : "green question and answer combination",
      "definition" : "Applied to a single question and answer pair, this indicates a green combination. Applied as summary to multiple question and answer pairs in a questionnaire response, this indicates at least one green combination found and no red or yellow combinations found.",
      "designation" : [
        {
          "language" : "da",
          "value" : "Grøn spørgsmål/svar-kombination fundet i spørgeskemabesvarelse."
        }
      ]
    },
    {
      "code" : "no-effective-answer-significance",
      "display" : "no effective answer significance for answer and question combination",
      "definition" : "Applied to a single question and answer pair, this indicates that answer did not meet any answer significance conditions. Applied as summary to multiple question and answer pairs in a questionnaire response, this indicates that no answer met the conditions of any answer significance(s) in the related question.",
      "designation" : [
        {
          "language" : "da",
          "value" : "Ingen triageringsindikator for spørgsmål/svar-kombination har fundet anvendelse."
        }
      ]
    },
    {
      "code" : "no-answer-significance-defined",
      "display" : "no answer significance defined for question(s)",
      "definition" : "Applied to a single question and answer pair, this indicates that the question did not have any answer significance. Applied as summary to multiple question and answer pairs in a questionnaire response, this indicates that no question had any associated answer significance(s).",
      "designation" : [
        {
          "language" : "da",
          "value" : "Ingen triageringsindikator defineret i spørgeskemaet."
        }
      ]
    },
    {
      "code" : "red",
      "display" : "Red overall assessment",
      "definition" : "Overall assessment is red",
      "designation" : [
        {
          "language" : "da",
          "value" : "Samlet vurdering er rød"
        }
      ]
    },
    {
      "code" : "yellow",
      "display" : "Yellow overall assessment",
      "definition" : "Overall assessment is yellow",
      "designation" : [
        {
          "language" : "da",
          "value" : "Samlet vurdering er gul"
        }
      ]
    },
    {
      "code" : "green",
      "display" : "Green overall assessment",
      "definition" : "Overall assessment is green",
      "designation" : [
        {
          "language" : "da",
          "value" : "Samlet vurdering er grøn"
        }
      ]
    },
    {
      "code" : "data-absent",
      "display" : "measurement data is absent",
      "definition" : "measurement data is absent",
      "designation" : [
        {
          "language" : "da",
          "value" : "Måledata (måling) har fravær af værdi"
        }
      ]
    },
    {
      "code" : "TBD",
      "display" : "Example value - Under construction",
      "definition" : "Example value - Under construction",
      "property" : [
        {
          "code" : "deprecated",
          "valueDateTime" : "2020-02-03"
        }
      ]
    },
    {
      "code" : "measurement-invalidated",
      "display" : "Measurement has been deemed invalid",
      "definition" : "Measurement has been deemed invalid",
      "designation" : [
        {
          "language" : "da",
          "value" : "Måledata (måling, spørgeskemabesvarelse eller billede) er ugyldiggjort"
        }
      ]
    },
    {
      "code" : "measurement-invalidation-retracted",
      "display" : "Measurement invalidation has been retracted",
      "definition" : "Measurement invalidation has been retracted",
      "designation" : [
        {
          "language" : "da",
          "value" : "Ugyldiggørelse af måledata (måling, spørgeskemabesvarelse eller billede) er trukket tilbage"
        }
      ]
    }
  ]
}

```
