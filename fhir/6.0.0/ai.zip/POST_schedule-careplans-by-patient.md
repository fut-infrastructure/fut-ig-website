# POST Schedule Careplans by Patient - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* **POST Schedule Careplans by Patient**

## POST Schedule Careplans by Patient

`POST [base]/$schedule-careplans-by-patient`

**Header**

```
Accept-Charset: utf-8
Authorization: Bearer eyJhbGciOiJub25lIn0.eyJ1c2VyX2lkIjoiMTQ1OGY5ZGEtOTQ5OS00MzNkLTg1NjktNzRmMWZkZGJjNTU3IiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIiRmZXRjaC1jYXJlcGxhbnMtYnktcGF0aWVudCIsInJlcG9ydC1ub24tYW5vbnltaXplZCIsIkJpbmFyeS5yZWFkIl19LCJjb250ZXh0Ijp7Im9yZ2FuaXphdGlvbl9pZCI6Imh0dHBzOi8vb3JnYW5pemF0aW9uLmNpdC1yZXBvcnRpbmctMTE4Mi5sb2NhbC9maGlyL09yZ2FuaXphdGlvbi8xOTA1NSIsInRlYW1fb25fZW9jIjpmYWxzZX0sInVzZXJfdHlwZSI6IlBSQUNUSVRJT05FUiJ9.
Accept: application/fhir+json;q=1.0, application/json+fhir;q=0.9
User-Agent: HAPI-FHIR/6.10.5 (FHIR Client; FHIR 4.0.1/R4; apache)
Accept-Encoding: gzip
Content-Type: application/fhir+json; charset=UTF-8

```

**Body**:

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "anonymization",
      "valueString": "None"
    },
    {
      "name": "organization",
      "valueReference": {
        "reference": "https://organization.cit-reporting-1182.local/fhir/Organization/19055"
      }
    },
    {
      "name": "period",
      "valuePeriod": {
        "start": "2025-02-04T14:14:39+00:00",
        "end": "2025-02-04T14:14:39+00:00"
      }
    }
  ]
}

```

**Response**

```
{
  "resourceType": "Binary",
  "id": "3",
  "meta": {
    "versionId": "1",
    "lastUpdated": "2025-02-04T14:14:40.763+00:00",
    "source": "#66964e94-ef61-4a68-a5a1-c9305955978e",
    "profile": [
      "http://hl7.org/fhir/StructureDefinition/Binary"
    ]
  },
  "contentType": "text/plain",
  "securityContext": {
    "identifier": {
      "value": "1458f9da-9499-433d-8569-74f1fddbc557"
    }
  },
  "data": "Kk5PVCBHRU5FUkFURUQgWUVUKg=="
}

```

