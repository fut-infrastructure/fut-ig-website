# Device service types - eHealth Infrastructure v10.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Device service types**

## CodeSystem: Device service types 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/device-service-types | *Version*:10.0.0 |
| Active as of 2019-09-16 | *Computable Name*:DeviceServiceTypes |

 
Device service types. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [SSLServiceTypes](ValueSet-ehealth-device-service-types.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-device-service-types",
  "url" : "http://ehealth.sundhed.dk/cs/device-service-types",
  "version" : "10.0.0",
  "name" : "DeviceServiceTypes",
  "title" : "Device service types",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-09-16T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Device service types.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "TRAINING",
    "display" : "Training patient in use of device",
    "definition" : "Training patient in use of device",
    "designation" : [{
      "language" : "da",
      "value" : "Oplæring af patient/borger i brug af udstyr"
    }]
  },
  {
    "code" : "RE-TRAINING",
    "display" : "Re-training a patient previously trained in using a device",
    "definition" : "Re-training a patient previously trained in using a device",
    "designation" : [{
      "language" : "da",
      "value" : "Oplæring af patient/borger tidligere oplært i brug af udstyr"
    }]
  },
  {
    "code" : "CALIBRATION",
    "display" : "Calibration of device",
    "definition" : "Calibration of device",
    "designation" : [{
      "language" : "da",
      "value" : "Kalibrering af udstyr"
    }]
  },
  {
    "code" : "REPAIR",
    "display" : "Off-site repair of device",
    "definition" : "Off-site repair of device",
    "designation" : [{
      "language" : "da",
      "value" : "Hjemtagelse af udstyr til reparation"
    }]
  },
  {
    "code" : "MAINTENANCE",
    "display" : "On-site maintenance or repair of device",
    "definition" : "On-site maintenance or repair of device",
    "designation" : [{
      "language" : "da",
      "value" : "Reparation af udstyr på stedet"
    }]
  },
  {
    "code" : "REPLACE",
    "display" : "Replacement of device",
    "definition" : "Replacement of device",
    "designation" : [{
      "language" : "da",
      "value" : "Udskiftning af udstyr"
    }]
  },
  {
    "code" : "PICKUP",
    "display" : "Pickup and return device after use",
    "definition" : "Pickup and return device after use",
    "designation" : [{
      "language" : "da",
      "value" : "Afhentning af udstyr efter brug"
    }]
  },
  {
    "code" : "DELIVER",
    "display" : "Deliver device to patient",
    "definition" : "Deliver device to patient",
    "designation" : [{
      "language" : "da",
      "value" : "Levering til patient/borger"
    }]
  },
  {
    "code" : "INSTALL",
    "display" : "Install and configure device on-site with patient",
    "definition" : "Install and configure device on-site with patient",
    "designation" : [{
      "language" : "da",
      "value" : "Installation og opsætning hos patient/borger"
    }]
  }]
}

```
