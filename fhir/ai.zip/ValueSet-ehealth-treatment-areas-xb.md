# Treatment Area Collection xb - eHealth Infrastructure v10.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Treatment Area Collection xb**

## ValueSet: Treatment Area Collection xb 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/vs/ehealth-treatment-area-collection-xb | *Version*:10.0.0 |
| Active as of 2025-12-05 | *Computable Name*:TreatmentAreaCollection_xb |
| **Usage:**system treatment area: xb | |

 
Combined treatment areas for coexistence tag xb. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ehealth-treatment-areas-xb",
  "url" : "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-collection-xb",
  "version" : "10.0.0",
  "name" : "TreatmentAreaCollection_xb",
  "title" : "Treatment Area Collection xb",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-05T09:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Combined treatment areas for coexistence tag xb.",
  "useContext" : [{
    "code" : {
      "system" : "http://ehealth.sundhed.dk/cs/ehealth-usage-context-type",
      "code" : "system-treatment-area"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-system",
        "code" : "xb"
      }]
    }
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "valueSet" : ["http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-1",
      "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-2",
      "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-3",
      "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-4",
      "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-5",
      "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-6",
      "http://ehealth.sundhed.dk/vs/ehealth-treatment-area-xb-7"]
    }]
  }
}

```
