# Goal Description - eHealth Infrastructure v11.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Goal Description**

## CodeSystem: Goal Description 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/goal-description | *Version*:11.0.1 |
| Active as of 2021-01-13 | *Computable Name*:GoalDescription |

 
Goal Description 

This Code system is referenced in the definition of the following value sets:

* [Goal Description](ValueSet-ehealth-goal-description.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-goal-description",
  "url" : "http://ehealth.sundhed.dk/cs/goal-description",
  "version" : "11.0.1",
  "name" : "GoalDescription",
  "title" : "Goal Description",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-01-13T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Goal Description",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "reference-value",
    "display" : "Reference value for relative reference ranges",
    "definition" : "Reference value for relative reference ranges",
    "designation" : [{
      "language" : "da",
      "value" : "referenceværdi"
    }]
  }]
}

```
