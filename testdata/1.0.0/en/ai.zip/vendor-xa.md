# Vendor xa - eHealth Infrastructure Test Data v1.0.0

* [**Table of Contents**](toc.md)
* [**Vendors**](vendors.md)
* **Vendor xa**

## Vendor xa

The care team running programme telma and the practitioner on it.

### Practitioners

The practitioner on the care team.

| | |
| :--- | :--- |
| [Practitioner telma](Practitioner-practitioner-xa.md) | Practitioner for telma, assigned on a care team for telma. |

### CareTeams

The clinicians responsible for the episode.

| | |
| :--- | :--- |
| [KOL care team for telma](CareTeam-careteam-xa.md) | The care team responsible for the COPD monitoring under telma. |

