# POST Schedule Careplan and Episode of Care Stats - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* **POST Schedule Careplan and Episode of Care Stats**

## POST Schedule Careplan and Episode of Care Stats

`POST [base]/$schedule-careplan-and-episode-of-care-stats`

**Header**

```
Accept-Charset: utf-8
Authorization: Bearer eyJhbGciOiJub25lIn0.eyJ1c2VyX2lkIjoiMDJmNmZjNzYtYzg1My00ZTU1LTkwN2YtN2Q4OGFmMGUxZjA0IiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInJlcG9ydC1ub24tYW5vbnltaXplZCIsIiRmZXRjaC1lcGlzb2Rlb2ZjYXJlLXN0YXRzIiwiQmluYXJ5LnJlYWQiXX0sImNvbnRleHQiOnsib3JnYW5pemF0aW9uX2lkIjoiaHR0cHM6Ly9vcmdhbml6YXRpb24uY2l0LXJlcG9ydGluZy0xMTgyLmxvY2FsL2ZoaXIvT3JnYW5pemF0aW9uLzUzMjU1IiwidGVhbV9vbl9lb2MiOmZhbHNlfSwidXNlcl90eXBlIjoiUFJBQ1RJVElPTkVSIn0.
Accept: application/fhir+json;q=1.0, application/json+fhir;q=0.9
User-Agent: HAPI-FHIR/6.10.5 (FHIR Client; FHIR 4.0.1/R4; apache)
Accept-Encoding: gzip
Content-Type: application/fhir+json; charset=UTF-8

```

**Body**:

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "anonymization",
      "valueString": "None"
    },
    {
      "name": "organization",
      "valueReference": {
        "reference": "https://organization.cit-reporting-1182.local/fhir/Organization/53255"
      }
    },
    {
      "name": "period",
      "valuePeriod": {
        "start": "2025-02-04T14:15:45+00:00",
        "end": "2025-02-04T14:15:45+00:00"
      }
    }
  ]
}

```

**Response**

```
{
  "resourceType": "Binary",
  "id": "10",
  "meta": {
    "versionId": "1",
    "lastUpdated": "2025-02-04T14:15:46.982+00:00",
    "source": "#da764f27-969b-4e2e-a0c7-c207dd295f39",
    "profile": [
      "http://hl7.org/fhir/StructureDefinition/Binary"
    ]
  },
  "contentType": "text/plain",
  "securityContext": {
    "identifier": {
      "value": "02f6fc76-c853-4e55-907f-7d88af0e1f04"
    }
  },
  "data": "Kk5PVCBHRU5FUkFURUQgWUVUKg=="
}

```

