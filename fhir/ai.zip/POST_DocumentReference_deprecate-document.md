# POST Document Reference Deprecate Document - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* **POST Document Reference Deprecate Document**

## POST Document Reference Deprecate Document

`POST [base]/DocumentReference/$deprecate-document`

**Header**

```
Accept-Charset: utf-8
Authorization: Bearer eyJhbGciOiJub25lIn0.eyJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiQ29tcG9zaXRpb24ucmVhZCIsIiR0ZXN0LW9ubHktY3JlYXRlIiwiJGRlcHJlY2F0ZS1kb2N1bWVudCIsIkRvY3VtZW50UmVmZXJlbmNlLnNlYXJjaCIsIkRvY3VtZW50UmVmZXJlbmNlLnJlYWQiXX0sInVzZXJfdHlwZSI6IlNZU1RFTSJ9.
Accept: application/fhir+json;q=1.0, application/json+fhir;q=0.9
User-Agent: HAPI-FHIR/6.10.5 (FHIR Client; FHIR 4.0.1/R4; apache)
Accept-Encoding: gzip
Content-Type: application/fhir+json; charset=UTF-8

```

**Body**:

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "documentId",
      "valueString": "urn:oid:1.2.208.184|74f3ab29-ffe4-46df-97be-c14297d02244"
    },
    {
      "name": "cpr",
      "valueString": "0123456789"
    }
  ]
}

```

**Response**

```
{
  "resourceType": "OperationOutcome",
  "text": {
    "status": "generated",
    "div": "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Operation Outcome</h1><table border=\"0\"><tr><td style=\"font-weight: bold;\">INFORMATION</td><td>[]</td><td>No issues detected during validation</td></tr></table></div>"
  },
  "issue": [
    {
      "severity": "information",
      "code": "informational",
      "diagnostics": "No issues detected during validation"
    }
  ]
}

```

