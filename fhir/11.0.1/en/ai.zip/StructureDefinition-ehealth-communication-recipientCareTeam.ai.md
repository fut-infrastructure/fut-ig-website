# Recipient careteam - eHealth Infrastructure v11.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Recipient careteam**

## Extension: Recipient careteam 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-communication-recipientCareTeam | *Version*:11.0.1 |
| Active as of 2026-10-23 | *Computable Name*:ehealth-communication-recipientCareTeam |

CareTeam that is a recipient of a Communication

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [ehealth-communication](StructureDefinition-ehealth-communication.md) and [ehealth-message](StructureDefinition-ehealth-message.md)
* Search Parameters using this Extension: [careTeamRecipient](SearchParameter-ehealth-communication-search-careTeamRecipient.md), [communicationParticipant](SearchParameter-ehealth-communication-search-participant.md) and [communicationRelatesTo](SearchParameter-ehealth-communication-search-relates-to.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/dk.ehealth.sundhed.fhir.ig.core|current/StructureDefinition/StructureDefinition-ehealth-communication-recipientCareTeam.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ehealth-communication-recipientCareTeam.csv), [Excel](../StructureDefinition-ehealth-communication-recipientCareTeam.xlsx), [Schematron](../StructureDefinition-ehealth-communication-recipientCareTeam.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ehealth-communication-recipientCareTeam",
  "url" : "http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-communication-recipientCareTeam",
  "version" : "11.0.1",
  "name" : "ehealth-communication-recipientCareTeam",
  "title" : "Recipient careteam",
  "status" : "active",
  "date" : "2026-10-23T09:25:15+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "CareTeam that is a recipient of a Communication",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "CareTeam message recipient",
      "definition" : "CareTeam that is a recipient of a Communication"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-communication-recipientCareTeam"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://ehealth.sundhed.dk/fhir/StructureDefinition/ehealth-careteam"],
        "aggregation" : ["referenced"]
      }]
    }]
  }
}

```
