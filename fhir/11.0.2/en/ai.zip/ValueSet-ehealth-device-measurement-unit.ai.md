# Device Measurement Unit - eHealth Infrastructure v11.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Device Measurement Unit**

## ValueSet: Device Measurement Unit (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/vs/device-measurement-unit | *Version*:11.0.2 |
| Active as of 2019-09-16 | *Computable Name*:DeviceMeasurementUnit |

 
Device measurement unit 

 **References** 

* [ehealth-devicemetric](StructureDefinition-ehealth-devicemetric.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ehealth-device-measurement-unit",
  "url" : "http://ehealth.sundhed.dk/vs/device-measurement-unit",
  "version" : "11.0.2",
  "name" : "DeviceMeasurementUnit",
  "title" : "Device Measurement Unit",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-09-16T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Device measurement unit",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "urn:oid:1.2.208.176.2.1",
      "concept" : [{
        "code" : "NPU03011"
      },
      {
        "code" : "NPU21692"
      },
      {
        "code" : "NPU03804"
      }]
    }]
  }
}

```
