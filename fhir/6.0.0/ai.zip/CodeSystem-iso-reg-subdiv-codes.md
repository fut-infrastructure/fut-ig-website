# Regional subdivision codes - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Regional subdivision codes**

## CodeSystem: Regional subdivision codes (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.iso.org/obp/ui/#iso:code:3166:DK | *Version*:6.0.0 |
| Active as of 2019-02-02 | *Computable Name*:Regional subdivision codes |

 
Subdivision codes (Regional codes) used in Denmark 

 This Code system is referenced in the content logical definition of the following value sets: 

* [RegionalSubdivisionCodes](ValueSet-regional-subdivision-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "iso-reg-subdiv-codes",
  "url" : "https://www.iso.org/obp/ui/#iso:code:3166:DK",
  "version" : "6.0.0",
  "name" : "Regional subdivision codes",
  "title" : "Regional subdivision codes",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "Subdivision codes (Regional codes) used in Denmark",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "content" : "complete",
  "concept" : [
    {
      "code" : "DK-84",
      "display" : "Capital Region of Denmark",
      "designation" : [
        {
          "language" : "da",
          "value" : "Hovedstaden"
        }
      ]
    },
    {
      "code" : "DK-82",
      "display" : "Central Denmark Region",
      "designation" : [
        {
          "language" : "da",
          "value" : "Midtjylland"
        }
      ]
    },
    {
      "code" : "DK-81",
      "display" : "Nord Denmark Region",
      "designation" : [
        {
          "language" : "da",
          "value" : "Nordjylland"
        }
      ]
    },
    {
      "code" : "DK-85",
      "display" : "Region Zealand",
      "designation" : [
        {
          "language" : "da",
          "value" : "Sjælland"
        }
      ]
    },
    {
      "code" : "DK-83",
      "display" : "Region of Southern Denmark",
      "designation" : [
        {
          "language" : "da",
          "value" : "Syddanmark"
        }
      ]
    }
  ]
}

```
