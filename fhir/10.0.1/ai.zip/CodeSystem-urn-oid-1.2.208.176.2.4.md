# Sundhedsvæsenets klassifikationssystem (SKS) - eHealth Infrastructure v10.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Sundhedsvæsenets klassifikationssystem (SKS)**

## CodeSystem: Sundhedsvæsenets klassifikationssystem (SKS) 

| | |
| :--- | :--- |
| *Official URL*:urn:oid:1.2.208.176.2.4 | *Version*:10.0.1 |
| Active as of 2019-12-13 | *Computable Name*:SKS |
| *Other Identifiers:*OID:1.2.208.176.2.4 | |

 This Code system is referenced in the content logical definition of the following value sets: 

* [ActivityDefinitionCode](ValueSet-ehealth-activitydefinition-code.md)
* [Conditions](ValueSet-ehealth-conditions.md)
* [MentalDisordersAndMentalHealthProblems](ValueSet-ehealth-treatment-area-xb-1.md)
* [NeurologicalDiseases](ValueSet-ehealth-treatment-area-xb-2.md)
* [CardiovascularDiseases](ValueSet-ehealth-treatment-area-xb-3.md)
* [PulmonaryDiseases](ValueSet-ehealth-treatment-area-xb-4.md)
* [SomaticMetabolicDiseases](ValueSet-ehealth-treatment-area-xb-5.md)
* [Other](ValueSet-ehealth-treatment-area-xb-7.md)
* [Depression](ValueSet-ehealth-treatment-area-xc-1.md)
* [Angst](ValueSet-ehealth-treatment-area-xc-2.md)
* [ZDiagnosis](ValueSet-ehealth-treatment-area-xc-3.md)
* [Health_conditions](ValueSet-ehealth-health-conditions.md)
* [MediaCodes](ValueSet-ehealth-media-codes.md)
* [ObservationCodes](ValueSet-ehealth-observation-codes.md)
* [usageContextTaskTypeTeleWound](ValueSet-vs-usage-context-task-type-tele-wound.md)
* [WoundConditions](ValueSet-ehealth-wound-conditions.md)
* [DK_IHE_EventCodeLists_VS](ValueSet-dk-ihe-eventcodelists-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "urn-oid-1.2.208.176.2.4",
  "meta" : {
    "versionId" : "4",
    "lastUpdated" : "2021-02-08T08:14:10.630+00:00"
  },
  "url" : "urn:oid:1.2.208.176.2.4",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.208.176.2.4"
  }],
  "version" : "10.0.1",
  "name" : "SKS",
  "title" : "Sundhedsvæsenets klassifikationssystem (SKS)",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-12-13T00:00:00+01:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "A",
    "display" : "Administrative forhold",
    "concept" : [{
      "code" : "AL",
      "display" : "Administrative koder til LPR3",
      "concept" : [{
        "code" : "ALA",
        "display" : "Koder vedr. Forløbselement",
        "concept" : [{
          "code" : "ALAL",
          "display" : "Forløbselement label",
          "concept" : [{
            "code" : "ALAL01",
            "display" : "Kræftsygdomme"
          },
          {
            "code" : "ALAL02",
            "display" : "Hjertesygdomme"
          },
          {
            "code" : "ALAL03",
            "display" : "Psykiske lidelser og adfærdsmæssige forstyrrelser"
          },
          {
            "code" : "ALAL21",
            "display" : "Kronisk obstruktiv lungesygdom (KOL)"
          },
          {
            "code" : "ALAL22",
            "display" : "Type 2-diabetes"
          },
          {
            "code" : "ALAL23",
            "display" : "Osteoporose"
          },
          {
            "code" : "ALAL51",
            "display" : "Graviditet, fødsel og barsel"
          },
          {
            "code" : "ALAL52",
            "display" : "Nyfødte"
          }]
        }]
      },
      {
        "code" : "ALCA",
        "display" : "Kontakt type",
        "concept" : [{
          "code" : "ALCA00",
          "display" : "fysisk fremmøde"
        },
        {
          "code" : "ALCA03",
          "display" : "virtuel kontakt"
        }]
      }]
    }]
  },
  {
    "code" : "B",
    "display" : "Behandlings- og plejeklassifikation",
    "concept" : [{
      "code" : "BN",
      "display" : "Hud og underhud",
      "concept" : [{
        "code" : "BNP",
        "display" : "Forbinding og anden behandling af hudlidelser",
        "concept" : [{
          "code" : "BNPF",
          "display" : "Interventioner ved hudtransplantation",
          "concept" : [{
            "code" : "BNPF2",
            "display" : "Pleje af huddonorsted"
          }]
        }]
      }]
    }]
  },
  {
    "code" : "D",
    "display" : "Klassifikation af sygdomme og helbredsrelaterede tilstande",
    "concept" : [{
      "code" : "DA46",
      "display" : "Rosen",
      "concept" : [{
        "code" : "DA469",
        "display" : "Rosen UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Rosen uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Rosen uden specifikation"
        }]
      }]
    },
    {
      "code" : "DB02",
      "display" : "Zoster",
      "concept" : [{
        "code" : "DB028",
        "display" : "Herpes zoster-infektion med anden komplikation"
      }]
    },
    {
      "code" : "DC43",
      "display" : "Modermærkekræft i huden",
      "concept" : [{
        "code" : "DC434",
        "display" : "Malignt melanom i hud på skalpen eller halsen"
      },
      {
        "code" : "DC437",
        "display" : "Malignt melanom i hud på underekstremitet",
        "concept" : [{
          "code" : "DC437A",
          "display" : "Malignt melanom i hud på ben"
        }]
      }]
    },
    {
      "code" : "DC44",
      "display" : "Anden hudkræft",
      "concept" : [{
        "code" : "DC449",
        "display" : "Anden hudkræft UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Anden hudkræft uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Anden hudkræft uden specifikation"
        }]
      }]
    },
    {
      "code" : "DC50",
      "display" : "Brystkræft",
      "concept" : [{
        "code" : "DC509",
        "display" : "Brystkræft UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Brystkræft uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Brystkræft uden specifikation"
        }]
      }]
    },
    {
      "code" : "DD86",
      "display" : "Sarkoidose",
      "concept" : [{
        "code" : "DD863",
        "display" : "Sarkoidose i hud"
      }]
    },
    {
      "code" : "DE10",
      "display" : "Type 1-diabetes",
      "concept" : [{
        "code" : "DE100",
        "display" : "Type 1-diabetes med koma"
      },
      {
        "code" : "DE101",
        "display" : "Type 1-diabetes med ketoacidose"
      },
      {
        "code" : "DE102",
        "display" : "Type 1-diabetes med nyrekomplikation"
      },
      {
        "code" : "DE103",
        "display" : "Type 1-diabetes med øjenkomplikation"
      },
      {
        "code" : "DE104",
        "display" : "Type 1-diabetes med neurologisk komplikation"
      },
      {
        "code" : "DE105",
        "display" : "Type 1-diabetes med komplikationer i perifere karsystem",
        "concept" : [{
          "code" : "DE105A",
          "display" : "Type 1-diabetes med perifer angiopati"
        },
        {
          "code" : "DE105B",
          "display" : "Type 1-diabetes med fodsår"
        },
        {
          "code" : "DE105C",
          "display" : "Type 1-diabetes med gangræn"
        },
        {
          "code" : "DE105D",
          "display" : "Type 1-diabetes med mikroangiopati"
        }]
      },
      {
        "code" : "DE106",
        "display" : "Type 1-diabetes med anden komplikation"
      },
      {
        "code" : "DE107",
        "display" : "Type 1-diabetes med multiple komplikationer"
      },
      {
        "code" : "DE108",
        "display" : "Type 1-diabetes med komplikation UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Type 1-diabetes med komplikation uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Type 1-diabetes med komplikation uden specifikation"
        }]
      },
      {
        "code" : "DE109",
        "display" : "Type 1-diabetes uden komplikationer",
        "concept" : [{
          "code" : "DE109A",
          "display" : "Type 1-diabetes UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Type 1-diabetes uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Type 1-diabetes uden specifikation"
          }]
        }]
      }]
    },
    {
      "code" : "DE11",
      "display" : "Type 2-diabetes",
      "concept" : [{
        "code" : "DE110",
        "display" : "Type 2-diabetes med koma"
      },
      {
        "code" : "DE111",
        "display" : "Type 2-diabetes med ketoacidose"
      },
      {
        "code" : "DE112",
        "display" : "Type 2-diabetes med nyrekomplikation"
      },
      {
        "code" : "DE113",
        "display" : "Type 2-diabetes med øjenkomplikation"
      },
      {
        "code" : "DE114",
        "display" : "Type 2-diabetes med neurologisk komplikation"
      },
      {
        "code" : "DE115",
        "display" : "Type 2-diabetes med komplikationer i perifere karsystem",
        "concept" : [{
          "code" : "DE115A",
          "display" : "Type 2-diabetes med perifer angiopati"
        },
        {
          "code" : "DE115B",
          "display" : "Type 2-diabetes med fodsår"
        },
        {
          "code" : "DE115C",
          "display" : "Type 2-diabetes med gangræn"
        },
        {
          "code" : "DE115D",
          "display" : "Type 2-diabetes med mikroangiopati"
        }]
      },
      {
        "code" : "DE116",
        "display" : "Type 2-diabetes med anden komplikation"
      },
      {
        "code" : "DE117",
        "display" : "Type 2-diabetes med multiple komplikationer"
      },
      {
        "code" : "DE118",
        "display" : "Type 2-diabetes med komplikation UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Type 2-diabetes med komplikation uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Type 2-diabetes med komplikation uden specifikation"
        }]
      },
      {
        "code" : "DE119",
        "display" : "Type 2-diabetes uden komplikationer",
        "concept" : [{
          "code" : "DE119A",
          "display" : "Type 2-diabetes UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Type 2-diabetes uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Type 2-diabetes uden specifikation"
          }]
        }]
      }]
    },
    {
      "code" : "DE14",
      "display" : "Ikke specificeret diabetes",
      "concept" : [{
        "code" : "DE144",
        "display" : "Diabetes UNS med neurologisk komplikation",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Diabetes uden specifikation med neurologisk komplikation"
        },
        {
          "language" : "da",
          "value" : "Diabetes uden specifikation med neurologisk komplikation"
        }]
      },
      {
        "code" : "DE145",
        "display" : "Diabetes UNS med komplikationer i perifere karsystem",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Diabetes uden specifikation med komplikationer i perifere karsystem"
        },
        {
          "language" : "da",
          "value" : "Diabetes uden specifikation med komplikationer i perifere karsystem"
        }],
        "concept" : [{
          "code" : "DE145B",
          "display" : "Diabetes UNS med fodsår",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Diabetes uden specifikation med fodsår"
          },
          {
            "language" : "da",
            "value" : "Diabetes uden specifikation med fodsår"
          }]
        },
        {
          "code" : "DE145C",
          "display" : "Diabetes UNS med gangræn",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Diabetes uden specifikation med gangræn"
          },
          {
            "language" : "da",
            "value" : "Diabetes uden specifikation med gangræn"
          }]
        }]
      },
      {
        "code" : "DE147",
        "display" : "Diabetes UNS med multiple komplikationer",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Diabetes uden specifikation med multiple komplikationer"
        },
        {
          "language" : "da",
          "value" : "Diabetes uden specifikation med multiple komplikationer"
        }]
      }]
    },
    {
      "code" : "DF00",
      "display" : "Demens ved Alzheimers sygdom"
    },
    {
      "code" : "DF10",
      "display" : "Psykiske lidelser og adfærdsmæssige forstyrrelser forårsaget af brug af alkohol"
    },
    {
      "code" : "DF20",
      "display" : "Skizofreni"
    },
    {
      "code" : "DF30",
      "display" : "Manisk enkeltepisode"
    },
    {
      "code" : "DF32",
      "display" : "Depressiv enkeltepisode",
      "concept" : [{
        "code" : "DF320",
        "display" : "Depressiv enkeltepisode af lettere grad"
      },
      {
        "code" : "DF321",
        "display" : "Depressiv enkeltepisode af moderat grad"
      }]
    },
    {
      "code" : "DF33",
      "display" : "Periodisk depression",
      "concept" : [{
        "code" : "DF330",
        "display" : "Periodisk depression i episode af lettere grad"
      },
      {
        "code" : "DF331",
        "display" : "Periodisk depression i episode af moderat grad"
      }]
    },
    {
      "code" : "DF40",
      "display" : "Fobiske angsttilstande",
      "concept" : [{
        "code" : "DF400",
        "display" : "Agorafobi",
        "concept" : [{
          "code" : "DF4000",
          "display" : "Agorafobi uden panikangst"
        },
        {
          "code" : "DF4001",
          "display" : "Agorafobi med panikangst"
        }]
      },
      {
        "code" : "DF401",
        "display" : "Socialfobi"
      },
      {
        "code" : "DF402",
        "display" : "Enkelfobi"
      }]
    },
    {
      "code" : "DF41",
      "display" : "Andre angsttilstande",
      "concept" : [{
        "code" : "DF410",
        "display" : "Panikangst"
      }]
    },
    {
      "code" : "DF50",
      "display" : "Spiseforstyrrelser"
    },
    {
      "code" : "DF60",
      "display" : "Specifikke forstyrrelser af personlighedsstrukturen"
    },
    {
      "code" : "DF70",
      "display" : "Mental retardering af lettere grad"
    },
    {
      "code" : "DF80",
      "display" : "Specifikke udviklingsforstyrrelser af tale og sprog"
    },
    {
      "code" : "DF90",
      "display" : "Hyperkinetiske forstyrrelser"
    },
    {
      "code" : "DF99",
      "display" : "Ikke nærmere specificerede psykiske lidelser",
      "concept" : [{
        "code" : "DF999",
        "display" : "Psykisk lidelse eller forstyrrelse UNS"
      }]
    },
    {
      "code" : "DG20",
      "display" : "Parkinsons sygdom"
    },
    {
      "code" : "DG62",
      "display" : "Andre polyneuropatier",
      "concept" : [{
        "code" : "DG629",
        "display" : "Polyneuropati UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Polyneuropati uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Polyneuropati uden specifikation"
        }]
      }]
    },
    {
      "code" : "DG83",
      "display" : "Andre syndromer med lammelse",
      "concept" : [{
        "code" : "DG834",
        "display" : "Cauda equina-syndrom",
        "concept" : [{
          "code" : "DG834B",
          "display" : "Neurogen claudicatio intermittens"
        }]
      }]
    },
    {
      "code" : "DI20",
      "display" : "Angina pectoris",
      "concept" : [{
        "code" : "DI200",
        "display" : "Ustabil angina pectoris",
        "concept" : [{
          "code" : "DI200B",
          "display" : "Klinisk vurderet ustabil angina pectoris"
        },
        {
          "code" : "DI200C",
          "display" : "Ustabil angina pectoris med dokumenteret iskæmi"
        }]
      },
      {
        "code" : "DI201",
        "display" : "Prinzmetals angina pectoris"
      },
      {
        "code" : "DI208",
        "display" : "Anden form for angina pectoris",
        "concept" : [{
          "code" : "DI208D",
          "display" : "Mikrovaskulær angina"
        },
        {
          "code" : "DI208E",
          "display" : "Stabil angina pectoris",
          "concept" : [{
            "code" : "DI208E1",
            "display" : "Klinisk vurderet angina pectoris"
          },
          {
            "code" : "DI208E2",
            "display" : "Angina pectoris med dokumenteret iskæmi"
          }]
        }]
      },
      {
        "code" : "DI209",
        "display" : "Angina pectoris UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Angina pectoris uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Angina pectoris uden specifikation"
        }]
      }]
    },
    {
      "code" : "DI25",
      "display" : "Kronisk iskæmisk hjertesygdom",
      "concept" : [{
        "code" : "DI251",
        "display" : "Arteriosklerotisk hjertesygdom"
      },
      {
        "code" : "DI252",
        "display" : "Gammelt myokardieinfarkt",
        "concept" : [{
          "code" : "DI252A",
          "display" : "Tidligere myokardieinfarkt (non-Q-tak)"
        },
        {
          "code" : "DI252B",
          "display" : "Tidligere myokardieinfarkt (Q-tak, anteriort)"
        },
        {
          "code" : "DI252C",
          "display" : "Tidligere myokardieinfarkt (Q-tak, inferiort/posteriort)"
        }]
      },
      {
        "code" : "DI253",
        "display" : "Hjerteaneurisme"
      },
      {
        "code" : "DI254",
        "display" : "Koronararterieaneurisme og -dissektion",
        "concept" : [{
          "code" : "DI254A",
          "display" : "Fistula arteriovenosa coronaria acquisita"
        },
        {
          "code" : "DI254B",
          "display" : "Spontan Koronararteriedissektion (SKAD)"
        }]
      },
      {
        "code" : "DI255",
        "display" : "Iskæmisk kardiomyopati"
      },
      {
        "code" : "DI256",
        "display" : "Stum myokardieiskæmi"
      },
      {
        "code" : "DI258",
        "display" : "Anden form for kronisk iskæmisk hjertesygdom"
      },
      {
        "code" : "DI259",
        "display" : "Kronisk iskæmisk hjertesygdom UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Kronisk iskæmisk hjertesygdom uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Kronisk iskæmisk hjertesygdom uden specifikation"
        }]
      }]
    },
    {
      "code" : "DI34",
      "display" : "Ikke-reumatiske sygdomme i mitralklappen",
      "concept" : [{
        "code" : "DI340",
        "display" : "Mitralinsufficiens"
      }]
    },
    {
      "code" : "DI35",
      "display" : "Ikke-reumatiske sygdomme i aortaklappen",
      "concept" : [{
        "code" : "DI350",
        "display" : "Aortastenose"
      }]
    },
    {
      "code" : "DI48",
      "display" : "Atrieflagren og atrieflimren"
    },
    {
      "code" : "DI50",
      "display" : "Hjertesvigt"
    },
    {
      "code" : "DI51",
      "display" : "Dårligt definerede hjertesygdomme og komplikationer til hjertesygdomme",
      "concept" : [{
        "code" : "DI511",
        "display" : "Ruptur af chordae tendineae IKA",
        "concept" : [{
          "code" : "DI511A",
          "display" : "Mitralklapinsufficiens ved chordaruptur"
        }]
      }]
    },
    {
      "code" : "DI70",
      "display" : "Åreforkalkning",
      "concept" : [{
        "code" : "DI702",
        "display" : "Aterosklerose i arterie i ekstremitet",
        "concept" : [{
          "code" : "DI702A",
          "display" : "Aterosklerotisk gangræn"
        }]
      },
      {
        "code" : "DI708",
        "display" : "Aterosklerose i anden arterie"
      }]
    },
    {
      "code" : "DI71",
      "display" : "Aorta-aneurisme og aortadissektion",
      "concept" : [{
        "code" : "DI719",
        "display" : "Aorta-aneurisme UNS uden ruptur",
        "concept" : [{
          "code" : "DI719A",
          "display" : "Dilateret aorta"
        }]
      }]
    },
    {
      "code" : "DI73",
      "display" : "Andre sygdomme i perifere kar",
      "concept" : [{
        "code" : "DI739",
        "display" : "Sygdom i perifere kar UNS ",
        "concept" : [{
          "code" : "DI739A",
          "display" : "Claudicatio intermittens"
        }]
      }]
    },
    {
      "code" : "DI83",
      "display" : "Varicer i underekstremiteter",
      "concept" : [{
        "code" : "DI830",
        "display" : "Varicer i underekstremitet med ulcus",
        "concept" : [{
          "code" : "DI830A",
          "display" : "Varicøst ulcus på underekstremite"
        },
        {
          "code" : "DI830B",
          "display" : "Ulcus cruris post-thromboticum"
        }]
      },
      {
        "code" : "DI831",
        "display" : "Varicer i underekstremitet med eksem"
      },
      {
        "code" : "DI832",
        "display" : "Varicer i underekstremitet med både ulcus og eksem"
      }]
    },
    {
      "code" : "DI87",
      "display" : "Andre sygdomme i vener",
      "concept" : [{
        "code" : "DI870",
        "display" : "Posttrombotisk syndrom"
      }]
    },
    {
      "code" : "DI89",
      "display" : "Andre ikke-infektiøse sygdommme i lymfesystemet",
      "concept" : [{
        "code" : "DI890",
        "display" : "Lymfødem IKA"
      }]
    },
    {
      "code" : "DJ44",
      "display" : "Kronisk obstruktiv lungesygdom",
      "concept" : [{
        "code" : "DJ440",
        "display" : "Kronisk obstruktiv lungesygdom med akut nedre luftvejs infektion"
      },
      {
        "code" : "DJ441",
        "display" : "Kronisk obstruktiv lungesygdom med akut eksacerbation UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Kronisk obstruktiv lungesygdom med akut eksacerbation uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Kronisk obstruktiv lungesygdom med akut eksacerbation uden specifikation"
        }]
      },
      {
        "code" : "DJ448",
        "display" : "Anden form for kronisk obstruktiv lungesygdom",
        "concept" : [{
          "code" : "DJ448A",
          "display" : "Kronisk obstruktiv bronkitis"
        },
        {
          "code" : "DJ448B",
          "display" : "Kronisk astmatisk bronkitis"
        },
        {
          "code" : "DJ448C",
          "display" : "Kronisk bronkitis med emfysem"
        }]
      },
      {
        "code" : "DJ449",
        "display" : "Kronisk obstruktiv lungesygdom UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Kronisk obstruktiv lungesygdom uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Kronisk obstruktiv lungesygdom uden specifikation"
        }]
      }]
    },
    {
      "code" : "DJ45",
      "display" : "Astma"
    },
    {
      "code" : "DL02",
      "display" : "Bylder i huden",
      "concept" : [{
        "code" : "DL022",
        "display" : "Absces, furunkel eller karbunkel i huden på truncus",
        "concept" : [{
          "code" : "DL022N",
          "display" : "Absces på ryggen"
        }]
      },
      {
        "code" : "DL023",
        "display" : "Absces, furunkel eller karbunkel i huden i sæderegionen"
      },
      {
        "code" : "DL024",
        "display" : "Absces, furunkel eller karbunkel i huden på ekstremitet"
      }]
    },
    {
      "code" : "DL03",
      "display" : "Flegmone",
      "concept" : [{
        "code" : "DL030",
        "display" : "Flegmone i finger eller tå",
        "concept" : [{
          "code" : "DL030A",
          "display" : "Panaritium tendinosum"
        }]
      },
      {
        "code" : "DL039",
        "display" : "Flegmone UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Flegmone uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Flegmone uden specifikation"
        }]
      }]
    },
    {
      "code" : "DL05",
      "display" : "Hårrede over halebenet",
      "concept" : [{
        "code" : "DL050",
        "display" : "Pilonidalcyste med absces"
      },
      {
        "code" : "DL059",
        "display" : "Pilonidalcyste uden absces"
      }]
    },
    {
      "code" : "DL12",
      "display" : "Pemfigoid",
      "concept" : [{
        "code" : "DL120",
        "display" : "Bulløs pemfigoid"
      }]
    },
    {
      "code" : "DL13",
      "display" : "Andre former for blæreudslæt",
      "concept" : [{
        "code" : "DL138",
        "display" : "Anden bulløs dermatitis"
      }]
    },
    {
      "code" : "DL28",
      "display" : "Lichenisering og prurigo",
      "concept" : [{
        "code" : "DL281",
        "display" : "Prurigo nodularis"
      },
      {
        "code" : "DL282",
        "display" : "Anden form for prurigo"
      }]
    },
    {
      "code" : "DL30",
      "display" : "Andre former for dermatitis",
      "concept" : [{
        "code" : "DL308",
        "display" : "Anden form for dermatitis",
        "concept" : [{
          "code" : "DL308H",
          "display" : "Håndeksem UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Håndeksem uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Håndeksem uden specifikation"
          }]
        }]
      },
      {
        "code" : "DL309",
        "display" : "Dermatitis UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Dermatitis uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Dermatitis uden specifikation"
        }]
      }]
    },
    {
      "code" : "DL40",
      "display" : "Psoriasis"
    },
    {
      "code" : "DL57",
      "display" : "Hudforandringer ved langvarig eksponering for ikke-joniserende stråling",
      "concept" : [{
        "code" : "DL570",
        "display" : "Aktinisk keratose"
      }]
    },
    {
      "code" : "DL60",
      "display" : "Sygdomme i negle",
      "concept" : [{
        "code" : "DL600",
        "display" : "Nedgroet negl"
      },
      {
        "code" : "DL609",
        "display" : "Neglesygdom UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Neglesygdom uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Neglesygdom uden specifikation"
        }]
      }]
    },
    {
      "code" : "DL73",
      "display" : "Andre follikulære sygdomme i hud og underhud",
      "concept" : [{
        "code" : "DL732",
        "display" : "Suppurerende hidrosadenitis"
      },
      {
        "code" : "DL738",
        "display" : "Anden follikulær sygdom i hud og underhud",
        "concept" : [{
          "code" : "DL738A",
          "display" : "Folliculitis UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Folliculitis uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Folliculitis uden specifikation"
          }]
        }]
      }]
    },
    {
      "code" : "DL84",
      "display" : "Hård hud og ligtorne",
      "concept" : [{
        "code" : "DL849",
        "display" : "Callositas et clavus"
      }]
    },
    {
      "code" : "DL88",
      "display" : "Pusdannelse i huden",
      "concept" : [{
        "code" : "DL889",
        "display" : "Pyoderma gangraenosum"
      }]
    },
    {
      "code" : "DL89",
      "display" : "Tryksår",
      "concept" : [{
        "code" : "DL890",
        "display" : "Decubitus grad I",
        "concept" : [{
          "code" : "DL890A",
          "display" : "Decubitus grad I ved neurologiske udfald"
        }]
      },
      {
        "code" : "DL891",
        "display" : "Decubitus grad II",
        "concept" : [{
          "code" : "DL891A",
          "display" : "Decubitus grad II ved neurologiske udfald"
        }]
      },
      {
        "code" : "DL892",
        "display" : "Decubitus grad III",
        "concept" : [{
          "code" : "DL892A",
          "display" : "Decubitus grad III ved neurologiske udfald"
        }]
      },
      {
        "code" : "DL893",
        "display" : "Decubitus grad IV",
        "concept" : [{
          "code" : "DL893A",
          "display" : "Decubitus grad IV ved neurologiske udfald"
        }]
      }]
    },
    {
      "code" : "DL92",
      "display" : "Granulomatøse sygdomme i hud og underhud",
      "concept" : [{
        "code" : "DL920",
        "display" : "Annulært granulom",
        "concept" : [{
          "code" : "DL920B",
          "display" : "Granuloma annulare perforans"
        }]
      },
      {
        "code" : "DL921",
        "display" : "Necrobiosis lipoidica IKA"
      }]
    },
    {
      "code" : "DL95",
      "display" : "Vaskulitis begrænset til huden IKA",
      "concept" : [{
        "code" : "DL951",
        "display" : "Erythema elevatum diutinum"
      },
      {
        "code" : "DL958",
        "display" : "Anden vaskulitis begrænset til huden"
      },
      {
        "code" : "DL959",
        "display" : "Vaskulitis begrænset til huden UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Vaskulitis begrænset til huden uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Vaskulitis begrænset til huden uden specifikation"
        }]
      }]
    },
    {
      "code" : "DL97",
      "display" : "Sår på ben IKA",
      "concept" : [{
        "code" : "DL979",
        "display" : "Ulcus på ben IKA",
        "concept" : [{
          "code" : "DL979A",
          "display" : "Neurogent ulcus på ben"
        },
        {
          "code" : "DL979B",
          "display" : "Ulcus cruris arterioscleroticum"
        },
        {
          "code" : "DL979C",
          "display" : "Ulcus perforans pedis"
        },
        {
          "code" : "DL979E",
          "display" : "Ulcus pedis arterioscleroticum"
        }]
      }]
    },
    {
      "code" : "DL98",
      "display" : "Andre sygdomme i hud og underhud IKA",
      "concept" : [{
        "code" : "DL982",
        "display" : "Dermatosis neutrophilica febrilis"
      },
      {
        "code" : "DL984",
        "display" : "Kronisk ulcus i huden IKA",
        "concept" : [{
          "code" : "DL984B",
          "display" : "Hudfissur"
        }]
      }]
    },
    {
      "code" : "DM14",
      "display" : "Artropatier ved andre sygdomme klassificeret andetsteds",
      "concept" : [{
        "code" : "DM142",
        "display" : "Diabetisk artropati"
      },
      {
        "code" : "DM146",
        "display" : "Neuropatisk artropati"
      }]
    },
    {
      "code" : "DM16",
      "display" : "Slidgigt i hofte"
    },
    {
      "code" : "DM17",
      "display" : "Slidgigt i knæ"
    },
    {
      "code" : "DM54",
      "display" : "Rygsmerter"
    },
    {
      "code" : "DM72",
      "display" : "Fibroblastsygdomme",
      "concept" : [{
        "code" : "DM726",
        "display" : "Nekrotiserende bløddelsinfektion"
      }]
    },
    {
      "code" : "DQ23",
      "display" : "Medfødte misdannelser af aorta- og mitralklapperne",
      "concept" : [{
        "code" : "DQ231",
        "display" : "Medfødt aortaklapinsufficiens",
        "concept" : [{
          "code" : "DQ231A",
          "display" : "Valvula aortae bicuspidalis"
        }]
      }]
    },
    {
      "code" : "DQ25",
      "display" : "Medfødte misdannelser i de store arterier",
      "concept" : [{
        "code" : "DQ251",
        "display" : "Coarctatio aortae"
      }]
    },
    {
      "code" : "DQ82",
      "display" : "Andre medfødte misdannelser af hud",
      "concept" : [{
        "code" : "DQ828",
        "display" : "Anden medfødt misdannelse af huden",
        "concept" : [{
          "code" : "DQ828F",
          "display" : "Dyskeratosis follicularis"
        }]
      }]
    },
    {
      "code" : "DR60",
      "display" : "Ødem IKA",
      "concept" : [{
        "code" : "DR609",
        "display" : "Ødem UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Ødem uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Ødem uden specifikation"
        }]
      }]
    },
    {
      "code" : "DR69",
      "display" : "Ukendte og ikke specificerede årsager til sygdom",
      "concept" : [{
        "code" : "DR699",
        "display" : "Sygdom uden kendt eller specificeret årsag"
      }]
    },
    {
      "code" : "DS00",
      "display" : "Overfladisk læsion af hovedet",
      "concept" : [{
        "code" : "DS000",
        "display" : "Overfladisk læsion af skalpen"
      },
      {
        "code" : "DS098",
        "display" : "Anden læsion af hovedet"
      }]
    },
    {
      "code" : "DS31",
      "display" : "Åbent sår på abdomen, lænden og bækkenet",
      "concept" : [{
        "code" : "DS318",
        "display" : "Åbent sår på anden eller ikke specificeret del af abdomen, lænden eller bækkenet",
        "concept" : [{
          "code" : "DS318A",
          "display" : "Åbent sår på abdomen UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Åbent sår på abdomen uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Åbent sår på abdomen uden specifikation"
          }]
        }]
      }]
    },
    {
      "code" : "DS41",
      "display" : "Åbent sår på skulder og overarm",
      "concept" : [{
        "code" : "DS411",
        "display" : "Åbent sår på overarm"
      }]
    },
    {
      "code" : "DS51",
      "display" : "Åbent sår på albueregion og underarm",
      "concept" : [{
        "code" : "DS510",
        "display" : "Åbent sår på albue"
      },
      {
        "code" : "DS519",
        "display" : "Åbent sår på albueregion eller underarm UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Åbent sår på albueregion eller underarm uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Åbent sår på albueregion eller underarm uden specifikation"
        }]
      }]
    },
    {
      "code" : "DS61",
      "display" : "Åbent sår på håndled og hånd",
      "concept" : [{
        "code" : "DS610",
        "display" : "Åbent sår på finger uden beskadigelse af negl",
        "concept" : [{
          "code" : "DS610A",
          "display" : "Åbent sår på finger UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Åbent sår på finger uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Åbent sår på finger uden specifikation"
          }]
        }]
      },
      {
        "code" : "DS611",
        "display" : "Åbent sår på finger med beskadigelse af negl"
      }]
    },
    {
      "code" : "DS68",
      "display" : "Traumatisk amputation af håndled og hånd",
      "concept" : [{
        "code" : "DS681",
        "display" : "Traumatisk amputation af anden specificeret finger",
        "concept" : [{
          "code" : "DS681D",
          "display" : "Traumatisk amputation af 5. finger"
        }]
      }]
    },
    {
      "code" : "DS71",
      "display" : "Åbent sår på hofteregion og lår",
      "concept" : [{
        "code" : "DS711",
        "display" : "Åbent sår på lår"
      },
      {
        "code" : "DS718",
        "display" : "Åbent sår på anden eller ikke specificeret del af hofteregion eller lår"
      }]
    },
    {
      "code" : "DS81",
      "display" : "Åbent sår på knæ og underben",
      "concept" : [{
        "code" : "DS819",
        "display" : "Åbent sår på underben UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Åbent sår på underben uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Åbent sår på underben uden specifikation"
        }]
      }]
    },
    {
      "code" : "DS82",
      "display" : "Fraktur af knæ, underben og ankel"
    },
    {
      "code" : "DS89",
      "display" : "Andre og ikke specificerede læsioner af knæregion og underben",
      "concept" : [{
        "code" : "DS898",
        "display" : "Anden læsion i knæregion eller på underben"
      }]
    },
    {
      "code" : "DS91",
      "display" : "Åbent sår på ankel og fod",
      "concept" : [{
        "code" : "DS911",
        "display" : "Åbent sår på tå uden beskadigelse af negl"
      },
      {
        "code" : "DS912",
        "display" : "Åbent sår på tå med beskadigelse af negl"
      },
      {
        "code" : "DS913",
        "display" : "Åbent sår på anden del af fod",
        "concept" : [{
          "code" : "DS913A",
          "display" : "Åbent sår på fod UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Åbent sår på fod uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Åbent sår på fod uden specifikation"
          }]
        }]
      },
      {
        "code" : "DS917",
        "display" : "Multiple åbne sår på ankel og fod"
      }]
    },
    {
      "code" : "DS99",
      "display" : "Andre og ikke specificerede læsioner af ankel og fod",
      "concept" : [{
        "code" : "DS999",
        "display" : "Læsion af ankel eller fod UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Læsion af ankel eller fod uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Læsion af ankel eller fod uden specifikation"
        }]
      }]
    },
    {
      "code" : "DT01",
      "display" : "Åbne sår på flere legemsregioner",
      "concept" : [{
        "code" : "DT019",
        "display" : "Multiple åbne sår UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Multiple åbne sår uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Multiple åbne sår uden specifikation"
        }]
      }]
    },
    {
      "code" : "DT09",
      "display" : "Andre læsioner af rygsøjle og krop uden angivelse af lokalisation",
      "concept" : [{
        "code" : "DT091",
        "display" : "Åbent sår på truncus UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Åbent sår på truncus uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Åbent sår på truncus uden specifikation"
        }]
      }]
    },
    {
      "code" : "DT11",
      "display" : "Andre læsioner af overekstremitet uden angivelse af lokalisation",
      "concept" : [{
        "code" : "DT111",
        "display" : "Åbent sår på arm UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Åbent sår på arm uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Åbent sår på arm uden specifikation"
        }]
      }]
    },
    {
      "code" : "DT14",
      "display" : "Læsion uden angivelse af legemsregion",
      "concept" : [{
        "code" : "DT140",
        "display" : "Overfladisk læsion uden angivelse af legemsregion",
        "concept" : [{
          "code" : "DT140D",
          "display" : "Hæmatom UNS",
          "designation" : [{
            "language" : "da",
            "use" : {
              "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
              "code" : "consumer"
            },
            "value" : "Hæmatom uden specifikation"
          },
          {
            "language" : "da",
            "value" : "Hæmatom uden specifikation"
          }]
        }]
      }]
    },
    {
      "code" : "DT20",
      "display" : "Forbrænding og ætsning på hovedet og halsen",
      "concept" : [{
        "code" : "DT200",
        "display" : "Forbrænding UNS på hovedet og halsen",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Forbrænding uden specifikation på hovedet og halsen"
        },
        {
          "language" : "da",
          "value" : "Forbrænding uden specifikation på hovedet og halsen"
        }]
      }]
    },
    {
      "code" : "DT23",
      "display" : "Forbrænding og ætsning på håndled og hånd",
      "concept" : [{
        "code" : "DT232",
        "display" : "2° forbrænding på håndled og hånd",
        "concept" : [{
          "code" : "DT232B",
          "display" : "2° forbrænding på hånd"
        }]
      }]
    },
    {
      "code" : "DT24",
      "display" : "Forbrænding og ætsning på hofte og ben",
      "concept" : [{
        "code" : "DT247",
        "display" : "3° ætsning på underekstremitet",
        "concept" : [{
          "code" : "DT247B",
          "display" : "3° ætsning på ben"
        }]
      }]
    },
    {
      "code" : "DT66",
      "display" : "Skade forårsaget af stråling",
      "concept" : [{
        "code" : "DT669",
        "display" : "Stråleskade UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Stråleskade uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Stråleskade uden specifikation"
        }]
      }]
    },
    {
      "code" : "DT69",
      "display" : "Andre virkninger af nedsat temperatur",
      "concept" : [{
        "code" : "DT691",
        "display" : "Pernio"
      }]
    },
    {
      "code" : "DT81",
      "display" : "Komplikationer til indgreb IKA",
      "concept" : [{
        "code" : "DT813",
        "display" : "Postoperativ sårruptur IKA",
        "concept" : [{
          "code" : "DT813C",
          "display" : "Overfladisk bristning eller nekrose af operationssår"
        },
        {
          "code" : "DT813D",
          "display" : "Dyb bristning af operationssår"
        }]
      },
      {
        "code" : "DT814",
        "display" : "Infektion efter indgreb IKA",
        "concept" : [{
          "code" : "DT814F",
          "display" : "Postoperativ sårinfektion"
        },
        {
          "code" : "DT814G",
          "display" : "Postoperativ overfladisk sårinfektion"
        },
        {
          "code" : "DT814H",
          "display" : "Postoperativ dyb sårinfektion"
        }]
      }]
    },
    {
      "code" : "DT86",
      "display" : "Svigt og afstødning af transplanterede organer og væv",
      "concept" : [{
        "code" : "DT860",
        "display" : "Afstødning af knoglemarvstransplantat",
        "concept" : [{
          "code" : "DT860A",
          "display" : "Graft-versus-host reaktion"
        }]
      }]
    },
    {
      "code" : "DT87",
      "display" : "Komplikationer til påsætning og amputation",
      "concept" : [{
        "code" : "DT875",
        "display" : "Nekrose i amputationsstump"
      },
      {
        "code" : "DT876",
        "display" : "Anden eller ikke specificeret komplikation i amputationstump"
      }]
    },
    {
      "code" : "DT95",
      "display" : "Følgetilstande efter forbrændinger, ætsninger og forfrysninger",
      "concept" : [{
        "code" : "DT959",
        "display" : "Følgetilstand efter forbrænding, ætsning eller forfrysning UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Følgetilstand efter forbrænding, ætsning eller forfrysning uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Følgetilstand efter forbrænding, ætsning eller forfrysning uden specifikation"
        }]
      }]
    },
    {
      "code" : "DZ48",
      "display" : "Kontakter mhp. andre efterbehandlinger efter kirurgisk indgreb",
      "concept" : [{
        "code" : "DZ489",
        "display" : "Efterbehandling efter kirurgisk indgreb UNS",
        "designation" : [{
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Efterbehandling efter kirurgisk indgreb uden specifikation"
        },
        {
          "language" : "da",
          "value" : "Efterbehandling efter kirurgisk indgreb uden specifikation"
        }]
      }]
    },
    {
      "code" : "DZ03",
      "display" : "Lægelig observation for og vurdering af personer mistænkt for sygdom",
      "concept" : [{
        "code" : "DZ032",
        "display" : "Observation pga. mistanke om psykisk lidelse eller adfærdsforstyrrelse"
      }]
    },
    {
      "code" : "DZ71",
      "display" : "Personer i kontakt med sundhedsvæsenet mhp. rådgivning og lægelig vejledning IKA",
      "concept" : [{
        "code" : "DZ718",
        "display" : "Anden rådgivning"
      }]
    },
    {
      "code" : "DZ76",
      "display" : "Personer i kontakt med sundhedsvæsenet af andre årsager"
    },
    {
      "code" : "DZ87",
      "display" : "Anamnese med andre sygdomme og tilstande",
      "concept" : [{
        "code" : "DZ872",
        "display" : "Anamnese med sygdom i hud eller underhud"
      }]
    },
    {
      "code" : "DZ93",
      "display" : "Tilstand med kunstig legemsåbning",
      "concept" : [{
        "code" : "DZ933",
        "display" : "Tilstand med kolostomi"
      }]
    },
    {
      "code" : "DZ94",
      "display" : "Tilstand med transplanteret organ eller væv",
      "concept" : [{
        "code" : "DZ940",
        "display" : "Nyretransplanteret"
      },
      {
        "code" : "DZ945",
        "display" : "Hudtransplanteret"
      }]
    },
    {
      "code" : "DZ95",
      "display" : "Tilstand med hjerte- eller karimplantater og -transplantater",
      "concept" : [{
        "code" : "DZ952",
        "display" : "Tilstand med kunstig hjerteklap"
      }]
    }]
  },
  {
    "code" : "ZZ0150",
    "display" : "Journaloptagelse",
    "concept" : [{
      "code" : "ZZ0150A",
      "display" : "Anamneseoptagelse"
    }]
  },
  {
    "code" : "ZZ3170",
    "display" : "Hjemmeblodtryksmåling udført af patienten"
  },
  {
    "code" : "ZZ7011",
    "display" : "Klinisk foto"
  },
  {
    "code" : "ZM",
    "display" : "Tillægskoder Morfologi",
    "concept" : [{
      "code" : "ZM80703",
      "display" : "planocellulært karcinom"
    },
    {
      "code" : "ZM80903",
      "display" : "basocellulært karcinom"
    }]
  }]
}

```
