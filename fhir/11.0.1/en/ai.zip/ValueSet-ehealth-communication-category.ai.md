# Communication Category - eHealth Infrastructure v11.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Communication Category**

## ValueSet: Communication Category (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/vs/communication-category | *Version*:11.0.1 |
| Active as of 2019-09-27 | *Computable Name*:CommunicationCategory |

 
Communication Category. 

 **References** 

* [ehealth-communication](StructureDefinition-ehealth-communication.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ehealth-communication-category",
  "url" : "http://ehealth.sundhed.dk/vs/communication-category",
  "version" : "11.0.1",
  "name" : "CommunicationCategory",
  "title" : "Communication Category",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-09-27T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Communication Category.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://ehealth.sundhed.dk/cs/communication-category"
    }]
  }
}

```
