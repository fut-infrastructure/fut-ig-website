# FS III, Bevægeapparat - eHealth Infrastructure v11.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FS III, Bevægeapparat**

## CodeSystem: FS III, Bevægeapparat (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/fs3-health-musculoskeletal | *Version*:11.0.2 |
| Active as of 2019-02-02 | *Computable Name*:FS III, Bevægeapparat |

 
FS III, Bevægeapparat 

This Code system is referenced in the definition of the following value sets:

* [FS III, helbredstilstande](ValueSet-fs3-health.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fs3-health-musculoskeletal",
  "url" : "http://ehealth.sundhed.dk/cs/fs3-health-musculoskeletal",
  "version" : "11.0.2",
  "name" : "FS III, Bevægeapparat",
  "title" : "FS III, Bevægeapparat",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "FS III, Bevægeapparat",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "complete",
  "concept" : [{
    "code" : "MOBILITY_AND_MOVEMENT",
    "display" : "Problemer med mobilitet og bevægelse",
    "designation" : [{
      "language" : "da",
      "value" : "Problemer med mobilitet og bevægelse"
    }]
  }]
}

```
