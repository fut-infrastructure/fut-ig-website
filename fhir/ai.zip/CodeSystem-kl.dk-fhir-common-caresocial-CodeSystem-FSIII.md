# FSIII - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FSIII**

## CodeSystem: FSIII 

| | |
| :--- | :--- |
| *Official URL*:http://kl.dk/fhir/common/caresocial/CodeSystem/FSIII | *Version*:6.0.0 |
| Active as of 2022-01-10 | *Computable Name*:FSIII |
| *Other Identifiers:*urn:oid#urn:oid:1.2.208.176.2.21 | |

 
Codes from FSIII 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Conditions](ValueSet-ehealth-conditions.md)
* [KLConditionCodesNursing](ValueSet-kl.dk-fhir-common-caresocial-ValueSet-KLConditionCodesNursing.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "kl.dk-fhir-common-caresocial-CodeSystem-FSIII",
  "url" : "http://kl.dk/fhir/common/caresocial/CodeSystem/FSIII",
  "identifier" : [
    {
      "system" : "urn:oid",
      "value" : "urn:oid:1.2.208.176.2.21"
    }
  ],
  "version" : "6.0.0",
  "name" : "FSIII",
  "title" : "FSIII",
  "status" : "active",
  "date" : "2022-01-10T11:49:35+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "Codes from FSIII",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "hierarchyMeaning" : "is-a",
  "content" : "complete",
  "concept" : [
    {
      "code" : "E",
      "display" : "Resultat af opfølgning",
      "concept" : [
        {
          "code" : "E3",
          "display" : "Afsluttes"
        },
        {
          "code" : "E1",
          "display" : "Fortsættes"
        },
        {
          "code" : "E2",
          "display" : "Ændres inden for rammen"
        },
        {
          "code" : "E4",
          "display" : "Revisitation"
        }
      ]
    },
    {
      "code" : "G",
      "display" : "Sundhedslov Indsatskatalog",
      "concept" : [
        {
          "code" : "G2",
          "display" : "0-ydelser",
          "concept" : [
            {
              "code" : "G2.4",
              "display" : "Generel 0-ydelse",
              "definition" : "Ydelsen kan anvendes kommunalt eller tværkommunalt i en periode, fx ved/i forbindelse med tiltag iht. puljemidler, som ex. kan være opfølgende hjemmebesøg eller systematisk faldforebyggelse."
            },
            {
              "code" : "G2.3",
              "display" : "Koordinering",
              "definition" : "Ydelsen omfatter en systematisk koordinering af kommunale og tværsektorielle aktørers indsatser til borgeren, fx hjemmehjælp, sygepleje, træningsenhed, praktiserende læge, ambulatorium og sygehus."
            },
            {
              "code" : "G2.1",
              "display" : "Sygeplejefaglig udredning",
              "definition" : "Ydelsen omfatter en systematisk indsamling og analyse af data om borgerens aktuelle og potentielle helbredstilstande inden for de 12 sygeplejefaglige problemområder, tildeling af indsatser, udarbejdelse af handlingsanvisninger og stillingtagen til opgaveoverdragelse. Der skal foretages en sygeplejefaglig udredning, før en (ny) indsats kan iværksættes."
            },
            {
              "code" : "G2.2",
              "display" : "Opfølgning",
              "definition" : "Ydelsen omfatter en systematisk opfølgning på borgerens helbredstilstande, forventede helbredstilstande og fastsatte mål for indsatser. Det skal vurderes, om der skal fortsættes, ændres, afsluttes eller udredes på ny."
            }
          ]
        },
        {
          "code" : "G1",
          "display" : "SUL § 138",
          "concept" : [
            {
              "code" : "G1.34",
              "display" : "Sondeernæring",
              "definition" : "Indsatsen omfatter typisk anlæggelse af sonde, indgift af næring og væske via sonde og skift af forbinding og hudpleje ved indstikssted."
            },
            {
              "code" : "G1.20",
              "display" : "Medicinadministration",
              "definition" : "Indsatsen omfatter udlevering og/eller tilføring af medicin. Ved ’medicin’ forstås ordinerede lægemidler, naturlægemidler og kosttilskud. Når ’medicinadministration’ og ’medicindispensering’ effektueres i en og samme handling, som det fx er tilfældet med øjendrypning og injektion, registreres det som ’medicinadministration’."
            },
            {
              "code" : "G1.11",
              "display" : "Drænpleje",
              "definition" : "Indsatsen omfatter sikring af afløb, tømning og skylning af dræn, skift af forbinding og pleje af hud ved indstikssted."
            },
            {
              "code" : "G1.31",
              "display" : "Samarbejde med netværk",
              "definition" : "Indsatsen består i samarbejde med pårørende om de indsatser, der ydes til borgeren, fx støtte til pårørende til en borger med demens eller psykisk sygdom."
            },
            {
              "code" : "G1.15",
              "display" : "Iltbehandling",
              "definition" : "Indsatsen omfatter saturationsmåling, indstilling af iltmængde iht. ordination, skift og rengøring af iltkatetre og andet udstyr samt vejledning i korrekt håndtering af iltudstyr."
            },
            {
              "code" : "G1.32",
              "display" : "Sekretsugning",
              "definition" : "Indsatsen omfatter sugning af mundhule og svælg, udførelse af eller støtte til mundhygiejne og instruktion i korrekt hosteteknik."
            },
            {
              "code" : "G1.7",
              "display" : "Behandling og pleje af hudproblem",
              "definition" : "Indsatsen omfatter typisk behandling og pleje af hud samt forebyggelse af tryksår og andre sårtyper."
            },
            {
              "code" : "G1.38",
              "display" : "Særlig kommunikationsform",
              "definition" : "Indsatsen omfatter samtale med borgeren og evt. også med pårørende ved hjælp af tolk og/eller instrumentelle kommunikationshjælpemidler som fx pc eller pegeplade."
            },
            {
              "code" : "G1.22",
              "display" : "Nonfarmakologisk smertelindring",
              "definition" : "Indsatsen omfatter nonfarmakologisk behandling/lindring af smerter, fx vejledning i visualiseringsøvelser, massage og kulde-/varmebehandling."
            },
            {
              "code" : "G1.44",
              "display" : "Væske per os",
              "definition" : "Indsatsen omfatter støtte til indtagelse af væske, herunder fx registrering af væskeindtag i væskeskema samt udregning af væskebalance."
            },
            {
              "code" : "G1.29",
              "display" : "Respirationsbehandling",
              "definition" : "Indsatsen omfatter typisk behandling med fx CPAP-, PEEP- eller BIPAP-maske og vejledning i vejrtrækningsteknikker og mundpleje."
            },
            {
              "code" : "G1.8",
              "display" : "Behandling og pleje af mave-tarmproblem",
              "definition" : "Indsatsen omfatter typisk vejledning om kost, væskeindtag, fysisk aktivitet og gode toiletvaner samt vurdering af medicinsk behandling."
            },
            {
              "code" : "G1.47",
              "display" : "Supplerende udredning",
              "definition" : "Indsatsen tildeles borgere, hvor der er behov for, at en helbredstilstand skal afdækkes og udredes mere dybtgående"
            },
            {
              "code" : "G1.37",
              "display" : "Subkutan væskebehandling",
              "definition" : "Indsatsen omfatter typisk anlæggelse af subkutan kanyle, samt tilkobling af infusionssæt, tilslutning og afkobling af infusionsvæsker, indstilling af infusionshastighed og pleje af hud ved indstikssted."
            },
            {
              "code" : "G1.16",
              "display" : "Inkontinensbehandling",
              "definition" : "Indsatsen omfatter typisk kontinensudredning, bækkenbundstræning, vejledning i blære- og tarmtømning, toiletvaner og brug af kontinenshjælpemidler."
            },
            {
              "code" : "G1.25",
              "display" : "Pleje ved anvendelse af personlige hjælpemidler",
              "definition" : "Indsatsen omfatter typisk vejledning i og støtte til brug af personlige hjælpemidler, fx rensning af glasøje og vedligeholdelse af høreapparat."
            },
            {
              "code" : "G1.5",
              "display" : "Anlæggelse og pleje af kateter",
              "definition" : "Indsatsen omfatter midlertidig eller permanent anlæggelse af kateter, skylning af kateter, tømning og skift af kateterpose, kontrol af kateterballon samt skift af forbinding og pleje af hud ved indstikssted."
            },
            {
              "code" : "G1.26",
              "display" : "Psykiatrisk pleje",
              "definition" : "Indsatsen omfatter typisk opbygning af relation, støtte til at få praktisk og mental struktur i dagligdagen, fx til håndtering og accept af psykiatriske symptomer, diagnoser, behandling og afledte problemer."
            },
            {
              "code" : "G1.39",
              "display" : "Sårbehandling",
              "definition" : "Indsatsen omfatter typisk skift af forbinding, sårbehandling og hudpleje. Indsatsen kan fx også omfatte trykaflastning, VAC-behandling samt fjernelse af suturer og agraffer."
            },
            {
              "code" : "G1.14",
              "display" : "Forflytning og mobilisering",
              "definition" : "Indsatsen omfatter forflytning og/eller mobilisering. Forflytning omfatter fx træk, skub og flytning vha. hjælpemidler. Mobilisering omfatter fx støtte til at bevæge sig rundt vha. gangstativ."
            },
            {
              "code" : "G1.19",
              "display" : "Kompressionsbehandling",
              "definition" : "Indsatsen omfatter typisk anlæggelse og aftagning af kompressionsforbinding eller kompressionsærmer, -handsker og -strømper, vejledning i venepumpeøvelser samt hudpleje."
            },
            {
              "code" : "G1.30",
              "display" : "Respiratorbehandling",
              "definition" : "Indsatsen omfatter typisk justering af respiratorordination, sekretsugning og mundpleje."
            },
            {
              "code" : "G1.12",
              "display" : "Ernæringsindsats",
              "definition" : "Indsatsen omfatter typisk løbende vægtkontrol, kostvejledning og støtte til indtagelse af mad og drikke."
            },
            {
              "code" : "G1.17",
              "display" : "Intravenøs medicinsk behandling",
              "definition" : "Indsatsen omfatter dispensering og administration af medicin, der skal gives intravenøst. Ved ’medicin’ forstås ordinerede lægemidler, naturlægemidler og kosttilskud. Indsatsen omfatter typisk behandling og pleje af iv-adgang og indstikssted samt indgift af medicin. Indsatsen kan også omfatte anlæggelse af iv-adgang."
            },
            {
              "code" : "G1.36",
              "display" : "Støtte til ADL-aktivitet",
              "definition" : "Indsatsen omfatter typisk støtte til at udføre eller udførelse af aktiviteter i ’almindelig daglig livsførelse’ (ADL), fx påklædning, madlavning, spisning, telefonering, oprydning, rengøring og betaling af regninger."
            },
            {
              "code" : "G1.21",
              "display" : "Medicindispensering",
              "definition" : "Indsatsen omfatter bestilling, modtagelse, kontrol, opbevaring, klargøring og bortskaffelse af medicin samt dokumentation, opfølgning på medicinsk behandling og receptfornyelser. Ved ’medicin’ forstås ordinerede lægemidler, naturlægemidler og kosttilskud. Klargøring omfatter typisk ophældning, optrækning, opløsning eller blanding af medicin. Indsatsen omfatter både medicin, der modtages maskinelt dosisdispenseret og medicin, der dispenseres (manuelt) umiddelbart før administration."
            },
            {
              "code" : "G1.42",
              "display" : "Vejledning",
              "definition" : "Indsatsen omfatter typisk samtale om, hvordan borgeren kan håndtere og agere ift. fysiske, psykiske, sociale og åndelige potentielle og/eller aktuelle tilstande, fx hvordan borgeren søger kommunale indsatser, eller hvordan konflikter kan håndteres."
            },
            {
              "code" : "G1.46",
              "display" : "Personlig pleje",
              "definition" : "Indsatsen anvendes i de tilfælde, hvor komplekse og/eller kritiske situationer omkring borger og/eller i hjemmet kræver et særligt kompetenceniveau til at løse opgaven."
            },
            {
              "code" : "G1.35",
              "display" : "Stomipleje",
              "definition" : "Indsatsen omfatter typisk skift af pladesystem og pose/tømning af pose samt hudpleje."
            },
            {
              "code" : "G1.10",
              "display" : "Dialyse",
              "definition" : "Indsatsen omfatter enten håndtering af posedialyse fx klargøring af dialysemaskine, klargøring af posevæsker, til- og frakobling af poser og behandling og pleje af indstikssted og dialysekateter eller observation efter hæmodialyse."
            },
            {
              "code" : "G1.40",
              "display" : "Trakeostomipleje",
              "definition" : "Indsatsen omfatter typisk skift af trakealkanyle, skift af forbinding og pleje af hud ved indstikssted."
            },
            {
              "code" : "G1.18",
              "display" : "Intravenøs væskebehandling",
              "definition" : "Indsatsen omfatter typisk tilkobling af infusionssæt, til- og frakobling af infusionsvæsker, indstilling af infusionshastighed samt behandling og pleje af indstikssted."
            },
            {
              "code" : "G1.28",
              "display" : "Rehabilitering",
              "definition" : "Indsatsen omfatter en korterevarende, tidsafgrænset, helhedsorienteret og tværfaglig tilrettelæggelse og træning af aktiviteter der er genkendelige og betydningsfulde for borgeren."
            },
            {
              "code" : "G1.27",
              "display" : "Psykisk støtte",
              "definition" : "Indsatsen omfatter typisk støtte til at mestre dagligdagen, bevare livskvalitet, forbedre mulighederne for livsudfoldelse og forebygge forværring."
            },
            {
              "code" : "G1.6",
              "display" : "Behandling med ortopædiske hjælpemidler",
              "definition" : "Indsatsen omfatter typisk fx anlæggelse af og støtte til brug af ordinerede arm-, ben- og knæskinner, armslynger og korsetter."
            },
            {
              "code" : "G1.9",
              "display" : "Cirkulationsbehandling",
              "definition" : "Indsatsen omfatter typisk måling af vægt, venepumpeøvelser og evt. anlæggelse af stumpforbinding efter amputation."
            },
            {
              "code" : "G1.41",
              "display" : "Undersøgelser og måling af værdier",
              "definition" : "Indsatsen omfatter lægeordineret undersøgelse af urin og afføring og målinger af fx blodsukker, temperatur, blodtryk og puls."
            },
            {
              "code" : "G1.24",
              "display" : "Parenteral ernæring",
              "definition" : "Indsatsen omfatter klargøring af ordineret ernæringspræparat, herunder tilsætning af vitaminer, samt tilkobling af infusionssæt, tilslutning til og frakobling fra iv-adgang, indstilling af infusionshastighed, skift af forbinding og pleje af iv-adgang og indstikssted."
            },
            {
              "code" : "G1.23",
              "display" : "Oplæring",
              "definition" : "Indsatsen omfatter typisk at oplære borger og/eller pårørende i at varetage hele eller dele af en indsats, fx sårbehandling, blodsukkermåling, stomi- og kateterpleje, brug af personlige og ortopædiske hjælpemidler samt medicinadministration."
            }
          ]
        }
      ]
    },
    {
      "code" : "0fa991ef-adf5-4202-8cfe-a31454ed6e9d",
      "display" : "§119 tilstande",
      "concept" : [
        {
          "code" : "d03da587-94dc-46e6-ba71-eb1e43ec7df6",
          "display" : "Kroppen",
          "concept" : [
            {
              "code" : "43f0b6da-11da-4eed-b00b-19b2177690b5",
              "display" : "Håndtere genstande",
              "definition" : "Beskrivelse af ændringer og fund relateret til evnen til fysisk at løfte, bære, flytte og håndtere genstande."
            },
            {
              "code" : "abc0b770-d080-4cc8-851a-aa62556730e6",
              "display" : "Mobilitet og bevægelse",
              "definition" : "Beskrivelse af ændringer og fund relateret til mobilitet og det at bevæge sig."
            },
            {
              "code" : "febbd20d-f5ff-41e7-bf12-dfa0700678e0",
              "display" : "Vægt",
              "definition" : "Beskrivelse af ændringer og fund relateret til vægt."
            },
            {
              "code" : "e3ff3fea-a4ff-4c7b-ad04-f4aad2e67fd3",
              "display" : "Cirkulation",
              "definition" : "Beskrivelse af ændringer og fund, der opstår som følge af uhensigtsmæssige kredsløbsforandringer."
            },
            {
              "code" : "e33396bb-019a-4fda-b901-1dbfdea1fc10",
              "display" : "Respiration",
              "definition" : "Beskrivelse af ændringer og fund, der opstår som følge af uhensigtsmæssige vejrtrækningsforandringer."
            },
            {
              "code" : "c0ee1cf6-47a9-4523-8fda-a80a13e28e30",
              "display" : "Ernæring",
              "definition" : "Beskrivelse af ændringer og fund relateret til indtag af mad og drikke. Fokus på det som borgeren indtager - ud fra et ernæringsperspektiv."
            },
            {
              "code" : "e7531532-7b7f-4ac0-863a-0b6a4cbe6ce2",
              "display" : "Smerte",
              "definition" : "Beskrivelse af ændringer og fund relateret til smerte, samt eventuelle årsager til eller sammenhænge med smerteoplevelsen"
            },
            {
              "code" : "880cdd75-c63a-44a0-a4e4-8209644c8628",
              "display" : "Kontinens",
              "definition" : "Beskrivelse af ændringer og fund relateret til urin- og afføringsmønstre"
            }
          ]
        },
        {
          "code" : "7b3b3587-4ddd-4b93-a81b-455bfc601492",
          "display" : "Hverdagsliv",
          "concept" : [
            {
              "code" : "fab34c19-4805-45af-b961-56099c849744",
              "display" : "Daglige aktiviteter",
              "definition" : "Beskrivelse af ændringer og fund relateret til basale aktiviteter i hverdagen. At kunne planlægge, strukturere, administrere og udføre aktiviteter i løbet dagen"
            },
            {
              "code" : "08042057-72f4-4798-a727-75ce6205dc86",
              "display" : "Sociale relationer",
              "definition" : "Beskrivelse af evne, lyst og vilje til at indgå i sociale relationer og netværk -  omfatter familie, det umiddelbare netværk og større fællesskaber."
            }
          ]
        },
        {
          "code" : "b349c7ec-86c5-4c52-aaf2-9034d98b0e3b",
          "display" : "Sundhedsadfærd",
          "concept" : [
            {
              "code" : "57b8979f-cf46-4312-aafa-3a0dd93aa921",
              "display" : "Alkohol",
              "definition" : "Beskrivelse af ændringer og fund relateret til alkohol."
            },
            {
              "code" : "bb7e9e71-73f6-4ec6-a0bf-eaec1e5982b4",
              "display" : "Sundhedskompetencer",
              "definition" : "Beskrivelse af ændringer og fund relateret til borgerens evne til at mestre egen situation"
            },
            {
              "code" : "f1f1eee3-a3ea-4ca1-bfa9-ebb381af1a1f",
              "display" : "Fysisk aktivitet",
              "definition" : "Beskrivelse af ændringer og fund relateret til borgerens fysiske aktivitetsniveau"
            },
            {
              "code" : "1a34ed6c-083b-451f-b8c8-137f99126b0c",
              "display" : "Tobak",
              "definition" : "Beskrivelse af ændringer og fund relateret til tobaksrygning"
            },
            {
              "code" : "f0b62265-6c83-4239-af97-4d6e9ba9dea7",
              "display" : "Medicin og stoffer",
              "definition" : "Beskrivelse af ændringer eller fund relateret til uhensigtsmæssig indtagelse af medicin og stoffer."
            },
            {
              "code" : "f715168e-125b-4d00-8e93-2ca4147ed13f",
              "display" : "Spisemønster",
              "definition" : "Beskrivelse af ændringer og fund vedr. uhensigtsmæssigheder relateret til borgerens spisemønster."
            }
          ]
        },
        {
          "code" : "3547a306-8623-4713-a8ce-db1e82839c50",
          "display" : "Mental sundhed",
          "concept" : [
            {
              "code" : "cb55874a-93d9-45c7-a25a-8ff677c24385",
              "display" : "Søvn og hvile",
              "definition" : "Beskrivelse af ændringer og fund relateret til søvn og hvilemønster."
            },
            {
              "code" : "43ad3091-f684-4d6f-8885-20ecd1cf2255",
              "display" : "Kropsopfattelse",
              "definition" : "Beskrivelse af ændringer og fund relateret til kropsopfattelse."
            },
            {
              "code" : "525b5dd8-d62b-4efa-bf66-262ac47eca5b",
              "display" : "Emotionel funktion",
              "definition" : "Beskrivelse af ændringer og fund relateret til håndtering af en ændret livssituation med afledte emotionelle udfordringer eller oplevelser."
            },
            {
              "code" : "0520a107-2bb0-47b8-8856-c53e27607e51",
              "display" : "Kognitiv funktion",
              "definition" : "Beskrivelse af ændringer og fund relateret til evnen til at forstå, ræsonnere, reflektere."
            }
          ]
        }
      ]
    },
    {
      "code" : "7deb81de-12c0-4a49-bd5b-72ea6fe89d83",
      "display" : "Træningsspor indsatskatalog",
      "concept" : [
        {
          "code" : "58293f63-00d7-4730-8dbc-c784d40f9e23",
          "display" : "Funktionstræning"
        },
        {
          "code" : "2abe20c7-c0b4-41c1-b397-52acf36499ef",
          "display" : "Fysisk træning",
          "definition" : "Indsatsen anvendes ved superviseret øvelsesterapi, der er målrettet bevægelighed, muskelfunktion, kredsløb, koordination og balance"
        },
        {
          "code" : "7f825e3e-1a5c-4249-bf41-9f7171fb6b8a",
          "display" : "ADL-træning",
          "definition" : "Indsatsen anvendes ved struktureret og systematisk træning gennem hverdagsaktiviteter."
        },
        {
          "code" : "571fa7da-a155-4a84-b780-ef19170d48a0",
          "display" : "Opfølgning",
          "definition" : "Indsatsen anvendes ved opfølgning på borgerens tilstande efter afsluttede indsatser"
        },
        {
          "code" : "ba3e17bd-d4aa-4848-acad-25adc8285c19",
          "display" : "Koordinering og kommunikation",
          "definition" : "Indsatsen anvendes ved systematisk koordinering af kommunale og tværsektorielle aktørers indsatser til borgeren"
        },
        {
          "code" : "8d714c98-f23a-4722-8a2f-85c162fe4840",
          "display" : "Psykomotorisk træning",
          "definition" : "Indsatsen anvendes ved træning målrettet mentalt og kropsligt samspil"
        },
        {
          "code" : "66fb32c9-ecc3-484b-be49-f20094be237c",
          "display" : "Vejledning og undervisning",
          "definition" : "Indsatsen anvendes ved vejledning, undervisning, instruktion, rådgivning af borger, pårørende og samarbejdspartnere i forbindelse med træningsforløbet"
        },
        {
          "code" : "1130ad70-6553-490d-87f8-5e8941687a0c",
          "display" : "Terapeutfaglig udredning",
          "definition" : "Indsatsen anvendes ved anamnese, undersøgelse, test, faglig vurdering af undersøgelsesfund og på denne baggrund opstilling af borgerens mål og planlægning af den videre indsats"
        },
        {
          "code" : "2c661159-1bb3-4af2-bdf1-f3a9927a99e2",
          "display" : "Kognitiv træning",
          "definition" : "Indsatsen anvendes ved superviseret øvelsesterapi, der er målrettet bevægelighed, muskelfunktion, kredsløb, koordination og balance"
        },
        {
          "code" : "f8ac963c-6ec5-4ec5-bd90-a22fea4e2d16",
          "display" : "Manuel behandling",
          "definition" : "Indsatsen anvendes ved manuelle behandlingsteknikker, der virker udspændende, mobiliserende og/eller stimulerende på fx led, muskler og senevæv"
        }
      ]
    },
    {
      "code" : "102ea764-d2cf-4a24-979d-68c2e8d638cf",
      "display" : "§119 indsatskatalog",
      "concept" : [
        {
          "code" : "f30cab6d-2a42-4358-99d7-811127fb6e05",
          "display" : "Mental håndtering",
          "definition" : "Vejledning eller undervisning i øvelser og teknikker, der fremmer mentalt velbefindende."
        },
        {
          "code" : "e71b7d85-5c78-49c2-8624-8499d162317b",
          "display" : "Sygdomshåndtering",
          "definition" : "Støtte til at forstå og håndtere livet med kronisk sygdom."
        },
        {
          "code" : "6eddbaf7-2a73-49d4-91e7-6138d419f58c",
          "display" : "Afklarende samtale"
        },
        {
          "code" : "ee5606ac-1bed-487e-aa3c-72dcc30ec037",
          "display" : "Behovssamtale",
          "definition" : "Samtale der bidrager til at afstemme borgerens motivation, ønsker og behov under igangværende forløb."
        },
        {
          "code" : "924e9828-84cf-4689-9551-0ebb6dc71b98",
          "display" : "Samtale om alkohol",
          "definition" : "Rådgivning om og støtte til hensigtsmæssig alkoholadfærd."
        },
        {
          "code" : "01a500f6-c221-4fd0-b518-cd361218b60d",
          "display" : "Madlavning i praksis",
          "definition" : "Aktiviteter hvor kostråd, ernæringsanbefalinger samt hensigtsmæssige mad- og måltidsvaner omsættes til praksis."
        },
        {
          "code" : "c203c6b5-3be0-40a8-8204-e93751deabf5",
          "display" : "Tobaksafvænning",
          "definition" : "Rådgivning om og støtte til forandring af vaner i relation til tobaksanvendelse."
        },
        {
          "code" : "cf7a55c2-7061-47ed-b7c5-e29620fe93bf",
          "display" : "Diætbehandling",
          "definition" : "En intervention i forhold til et ernæringsproblem, der er opstået som følge af sygdom eller behandling."
        },
        {
          "code" : "c9a99304-1788-43b7-b7be-e187b092ae9c",
          "display" : "Kostvejledning",
          "definition" : "Vejledning om de officielle (generelle) kostråd suppleret af relevante ernæringsanbefalinger."
        },
        {
          "code" : "ab87c0b5-40be-4e0a-b749-d9f833bfed2d",
          "display" : "Fysisk træning",
          "definition" : "Superviserede aktiviteter der bidrager til øget muskelstyrke og/eller øget kondition."
        },
        {
          "code" : "61692d91-69b8-4830-9453-3d58454e49d3",
          "display" : "Færdighedstræning",
          "definition" : "Vejledning, introduktion og igangsætning af aktiviteter, der bidrager til øget selvhjulpenhed i hverdagslivet"
        },
        {
          "code" : "abe847e0-1ce0-44dc-a675-ce05b66f47e6",
          "display" : "Vejledning og introduktion til fysiske aktiviteter",
          "definition" : "Vejledning og støtte til at være fysisk aktiv \"på egen hånd\" og introduktion til fysiske aktiviteter."
        },
        {
          "code" : "03a3ebdb-9e2d-4be1-b32b-42f0bd2a3362",
          "display" : "Afsluttende samtale",
          "definition" : "Samtale der afslutter en eller flere indsatser."
        },
        {
          "code" : "d1e016b5-150a-4ac4-97ba-d3e19e28471e",
          "display" : "Opfølgning",
          "definition" : "Aktivitet der følger op på borgerens fastholdelse af ændringer i hverdagslivet efter afsluttede indsatser."
        }
      ]
    },
    {
      "code" : "C",
      "display" : "Udførelse",
      "concept" : [
        {
          "code" : "C4",
          "display" : "Ikke relevant"
        },
        {
          "code" : "C2",
          "display" : "Udfører dele af"
        },
        {
          "code" : "C3",
          "display" : "Udfører ikke selv"
        },
        {
          "code" : "C1",
          "display" : "Udfører selv"
        }
      ]
    },
    {
      "code" : "I",
      "display" : "Helbredstilstande",
      "concept" : [
        {
          "code" : "I9",
          "display" : "Smerter og sanseindtryk",
          "concept" : [
            {
              "code" : "I9.8",
              "display" : "Problemer med smagssans",
              "definition" : "Brug for støtte til at kompensere for ændret smagssans."
            },
            {
              "code" : "I9.3",
              "display" : "Kroniske smerter",
              "definition" : "Brug for støtte til at håndtere kroniske smerter."
            },
            {
              "code" : "I9.6",
              "display" : "Problemer med synssans",
              "definition" : "Brug for støtte til at kompensere for ændret synssans."
            },
            {
              "code" : "I9.2",
              "display" : "Periodevise smerter",
              "definition" : "Brug for støtte til at håndtere periodevise smerter."
            },
            {
              "code" : "I9.7",
              "display" : "Problemer med hørelse",
              "definition" : "Brug for støtte til at kompensere for ændret høresans."
            },
            {
              "code" : "I9.1",
              "display" : "Akutte smerter",
              "definition" : "Brug for støtte til at håndtere akutte smerter."
            },
            {
              "code" : "I9.5",
              "display" : "Problemer med følesans",
              "definition" : "Brug for støtte til at kompensere for ændret følesans."
            },
            {
              "code" : "I9.4",
              "display" : "Problemer med lugtesans",
              "definition" : "Brug for støtte til at kompensere for ændret lugtesans."
            }
          ]
        },
        {
          "code" : "I2",
          "display" : "Bevægeapparat",
          "concept" : [
            {
              "code" : "I2.1",
              "display" : "Problemer med mobilitet og bevægelse",
              "definition" : "Brug for støtte til at ændre kropsstilling, forflytning og/eller at bevæge sig omkring."
            }
          ]
        },
        {
          "code" : "I11",
          "display" : "Viden og udvikling",
          "concept" : [
            {
              "code" : "I11.3",
              "display" : "Problemer med sygdomsindsigt",
              "definition" : "Brug for støtte til at indse manglende evne til egenomsorg."
            },
            {
              "code" : "I11.1",
              "display" : "Problemer med hukommelse",
              "definition" : "Brug for støtte til at huske, genkende og anvende tidligere erfaringer."
            },
            {
              "code" : "I11.2",
              "display" : "Problemer med indsigt i behandlingsformål",
              "definition" : "Brug for støtte til at forstå hensigt med behandling (compliance)."
            },
            {
              "code" : "I11.4",
              "display" : "Kognitive problemer",
              "definition" : "Brug for støtte til logisk tænkning, tilegnelse af viden, overblik, planlægning og organisering."
            }
          ]
        },
        {
          "code" : "I1",
          "display" : "Funktionsniveau",
          "concept" : [
            {
              "code" : "I1.2",
              "display" : "Problemer med daglige aktiviteter",
              "definition" : "Brug for støtte til planlægning og koordinering af dagligdagen."
            },
            {
              "code" : "I1.1",
              "display" : "Problemer med personlig pleje",
              "definition" : "Brug for støtte til kropspleje, af- og påklædning og/eller toiletbesøg."
            }
          ]
        },
        {
          "code" : "I5",
          "display" : "Kommunikation",
          "concept" : [
            {
              "code" : "I5.1",
              "display" : "Problemer med kommunikation",
              "definition" : "Brug for støtte til kommunikation."
            }
          ]
        },
        {
          "code" : "I7",
          "display" : "Respiration og cirkulation",
          "concept" : [
            {
              "code" : "I7.2",
              "display" : "Cirkulationsproblemer",
              "definition" : "Brug for støtte til håndtering af cardio-vaskulære problemer."
            },
            {
              "code" : "I7.1",
              "display" : "Respirationsproblemer",
              "definition" : "Brug for støtte til håndtering af vejrtrækningsproblemer."
            }
          ]
        },
        {
          "code" : "I4",
          "display" : "Hud og slimhinder",
          "concept" : [
            {
              "code" : "I4.9",
              "display" : "Andre problemer med hud og slimhinder",
              "definition" : "Brug for støtte til behandling af hud- og slimhindeproblemer, som ikke er sår."
            },
            {
              "code" : "I4.6",
              "display" : "Problemer med venøst sår",
              "definition" : "Brug for støtte til behandling af venøst sår."
            },
            {
              "code" : "I4.1",
              "display" : "Problemer med kirurgisk sår",
              "definition" : "Brug for støtte til behandling af kirurgisk sår."
            },
            {
              "code" : "I4.2",
              "display" : "Problemer med diabetisk sår",
              "definition" : "Brug for støtte til behandling af diabetisk sår."
            },
            {
              "code" : "I4.7",
              "display" : "Problemer med blandingssår",
              "definition" : "Brug for støtte til behandling af blandingssår."
            },
            {
              "code" : "I4.3",
              "display" : "Problemer med cancersår",
              "definition" : "Brug for støtte til behandling af cancersår"
            },
            {
              "code" : "I4.4",
              "display" : "Problemer med tryksår",
              "definition" : "Brug for støtte til behandling af tryksår."
            },
            {
              "code" : "I4.5",
              "display" : "Problemer med arterielt sår",
              "definition" : "Brug for støtte til behandling af arterielt sår."
            },
            {
              "code" : "I4.8",
              "display" : "Problemer med traumesår",
              "definition" : "Brug for støtte til behandling af traumesår."
            }
          ]
        },
        {
          "code" : "I8",
          "display" : "Seksualitet",
          "concept" : [
            {
              "code" : "I8.1",
              "display" : "Problemer med seksualitet",
              "definition" : "Brug for støtte til seksuel aktivitet."
            }
          ]
        },
        {
          "code" : "I3",
          "display" : "Ernæring",
          "concept" : [
            {
              "code" : "I3.5",
              "display" : "Problemer med undervægt",
              "definition" : "Brug for støtte til at håndtere undervægt."
            },
            {
              "code" : "I3.2",
              "display" : "Problemer med fødeindtag",
              "definition" : "Brug for støtte til fødeindtag."
            },
            {
              "code" : "I3.1",
              "display" : "Problemer med væskeindtag",
              "definition" : "Brug for støtte til væskeindtag."
            },
            {
              "code" : "I3.4",
              "display" : "Problemer med overvægt",
              "definition" : "Brug for støtte til at håndtere overvægt."
            },
            {
              "code" : "I3.3",
              "display" : "Uhensigtsmæssig vægtændring",
              "definition" : "Brug for støtte til at håndtere uplanlagt vægtændring."
            }
          ]
        },
        {
          "code" : "I12",
          "display" : "Udskillelse af affaldsstoffer",
          "concept" : [
            {
              "code" : "I12.3",
              "display" : "Problemer med urininkontinens",
              "definition" : "Brug for støtte til at håndtere urininkontinens."
            },
            {
              "code" : "I12.2",
              "display" : "Problemer med vandladning",
              "definition" : "Brug for støtte til at håndtere vandladningsproblemer, der ikke er inkontinens."
            },
            {
              "code" : "I12.1",
              "display" : "Problemer med afføringsinkontinens",
              "definition" : "Brug for støtte til at håndtere afføringsproblemer/styre afføring."
            },
            {
              "code" : "I12.4",
              "display" : "Problemer med mave og tarm",
              "definition" : "Brug for støtte til at håndtere fordøjelsesproblemer."
            }
          ]
        },
        {
          "code" : "I10",
          "display" : "Søvn og hvile",
          "concept" : [
            {
              "code" : "I10.1",
              "display" : "Døgnrytmeproblemer",
              "definition" : "Brug for støtte til at håndtere for manglende evne til at adskille dag og nat."
            },
            {
              "code" : "I10.2",
              "display" : "Søvnproblemer",
              "definition" : "Brug for støtte til at kompensere for dårlig søvnkvalitet."
            }
          ]
        },
        {
          "code" : "I6",
          "display" : "Psykosociale forhold",
          "concept" : [
            {
              "code" : "I6.2",
              "display" : "Emotionelle problemer",
              "definition" : "Brug for støtte til at håndtere følelser."
            },
            {
              "code" : "I6.4",
              "display" : "Mentale problemer",
              "definition" : "Brug for støtte til at håndtere psykiske og psykiatriske symptomer."
            },
            {
              "code" : "I6.1",
              "display" : "Problemer med socialt samvær",
              "definition" : "Brug for støtte til at fungere socialt."
            },
            {
              "code" : "I6.3",
              "display" : "Problemer med misbrug",
              "definition" : "Brug for støtte til at håndtere misbrugsproblemer."
            }
          ]
        }
      ]
    },
    {
      "code" : "94db6c71-859d-43e6-9a62-4e7fa7daf767",
      "display" : "Træningstilstande",
      "concept" : [
        {
          "code" : "7e608d37-3f3c-4374-bbc8-e317505d8bc2",
          "display" : "Samfundsliv",
          "concept" : [
            {
              "code" : "5f2310b3-cad1-43f6-9dc7-d982da141860",
              "display" : "Varetage beskæftigelse",
              "definition" : "Deltage i alle aspekter af beskæftigelse"
            },
            {
              "code" : "73642409-bcd7-41b7-a2ed-50ae37352167",
              "display" : "Varetage uddannelse",
              "definition" : "Deltage i grundlæggende læring, skole eller uddannelse"
            },
            {
              "code" : "9c2c29fb-4df7-4be4-a72f-383b488d575d",
              "display" : "Deltage i fritidsaktiviteter og fællesskaber",
              "definition" : "Deltage i enhver form for leg, forlystelses-, fælles- eller fritidsaktiviteter"
            },
            {
              "code" : "04d9580e-669a-42d5-b20f-3c651ad5b8bf",
              "display" : "Samspil og kontakt",
              "definition" : "Indgå i relationer og samspil med andre mennesker på en kontekstuelt og socialt passende måde"
            },
            {
              "code" : "064f983b-5ec5-40a3-bc90-c3fcec6b6ef5",
              "display" : "Kommunikation",
              "definition" : "Forstå og fremstille meddelelser samt anvende udstyr til kommunikationsformål"
            }
          ]
        },
        {
          "code" : "ebd91b5e-114a-48a5-90b8-d3c1fd50b72b",
          "display" : "Viden og udvikling",
          "concept" : [
            {
              "code" : "a2e013fb-7c91-4c5a-90c6-d119ff3e0ce8",
              "display" : "Udføre daglige rutiner",
              "definition" : "Udføre simple, komplekse og sammensatte handlinger til planlægning, styring og gennemførelse af dagligt tilbagevendende rutiner eller pligter"
            },
            {
              "code" : "3bba13c9-c429-408e-b82c-3f2bf25b8d39",
              "display" : "Læring og anvendelse af viden",
              "definition" : "Udvikle og anvende viden mhp problemløsning og beslutningstagen"
            }
          ]
        },
        {
          "code" : "ecb5e72d-40a2-4af3-9135-25974026bf02",
          "display" : "Ernæring",
          "concept" : [
            {
              "code" : "c0624874-bdd4-4879-99c5-3a7330f83cc9",
              "display" : "Fødeindtagelse",
              "definition" : "Indtagelse og bearbejdning af føde og væske gennem munden"
            }
          ]
        },
        {
          "code" : "b9c4561d-20bc-48c9-a727-fea719424a86",
          "display" : "Praktiske opgaver",
          "concept" : [
            {
              "code" : "bd088375-65fc-4e1d-9a8b-78dc918e6581",
              "display" : "Indkøb",
              "definition" : "Planlægge og foretage indkøb der er nødvendige i dagligdagen"
            },
            {
              "code" : "2bd07f7c-e6bb-424b-ab8f-f7c1de2afe80",
              "display" : "Lave mad",
              "definition" : "Planlægge, tilberede og servere enkle eller sammensatte måltider til sig selv og andre"
            },
            {
              "code" : "b53bca74-fd3f-4127-89ae-1a39d7836b93",
              "display" : "Lave husligt arbejde",
              "definition" : "Planlægge og udføre aktiviteter i hjemmet mhp at passe de fysiske omgivelser og holde rent og hygiejnisk"
            }
          ]
        },
        {
          "code" : "ddbd7477-9579-4a83-a3e7-74ed716a0451",
          "display" : "Hud og hævelser",
          "concept" : [
            {
              "code" : "263a2c2f-7ae2-4264-8808-7e8216b1a118",
              "display" : "Sår og cicatriser",
              "definition" : "Fund relateret til cicatriser og sår herunder tryksår"
            },
            {
              "code" : "65ca1484-390b-4f1e-ba14-86a170ba75b9",
              "display" : "Ødem",
              "definition" : "Fund relateret til hævelser"
            }
          ]
        },
        {
          "code" : "e3242303-2506-4a09-ac65-59dfd06cb489",
          "display" : "Mobilitet",
          "concept" : [
            {
              "code" : "713fcbca-3776-4fb5-b423-2b82fcab7865",
              "display" : "Håndtere genstande",
              "definition" : "Bære, flytte og håndtere genstande med hænder og arme"
            },
            {
              "code" : "3f27a7bc-790d-444e-bcf4-6e22a6b1da7e",
              "display" : "Gang og bevægelse",
              "definition" : "Bevæge sig fra et sted til et andet i forskellige omgivelser"
            },
            {
              "code" : "271c791c-7b6e-4a43-bf2f-d2a815386749",
              "display" : "Færden med transportmidler",
              "definition" : "Bruge transportmidler som passager eller chauffør til at komme omkring"
            },
            {
              "code" : "2a641de6-1017-4647-a0fb-c3c8b7b1f43e",
              "display" : "Ændre og opretholde kropsstilling",
              "definition" : "Ændre kropsstilling og forflytte sig fra et sted til et andet"
            }
          ]
        },
        {
          "code" : "df62498e-7ad1-4f01-93ce-a0441f879a2c",
          "display" : "Egenomsorg",
          "concept" : [
            {
              "code" : "a05628c5-0128-42f7-844c-0f8261041328",
              "display" : "Spise og drikke",
              "definition" : "Tage mad og drikke fra bord og føre til mund og spise og drikke på en kulturelt acceptabel måde"
            },
            {
              "code" : "91fbebf5-9cd2-4a95-ab7f-3e94e635253e",
              "display" : "Varetage egen sundhed",
              "definition" : "Sikre sit velvære, helbred og fysiske og psykiske velbefindende"
            },
            {
              "code" : "dc2691db-fcc5-406f-a790-3c1f2f91c6b9",
              "display" : "Kropspleje",
              "definition" : "Pleje af de dele af kroppen, som behøver anden pleje end vask og tørring"
            },
            {
              "code" : "1e199483-7201-43ef-a685-7fee7f4398ce",
              "display" : "Af- og påklædning",
              "definition" : "Tage tøj og sko af og på i rækkefølge og i overensstemmelse med den sociale sammenhæng og de klimatiske forhold"
            },
            {
              "code" : "0c126894-60e1-4781-96b7-9b227677bfb6",
              "display" : "Vaske sig",
              "definition" : "Vaske og tørre sig på kroppen og kropsdele med anvendelse af vand og passende rensemidler"
            },
            {
              "code" : "cffd4ef7-0282-4a68-a542-bae128172047",
              "display" : "Gå på toilet",
              "definition" : "Planlægge og udføre toiletbesøg til udskillelse af affaldsstoffer og efterfølgende rengøring"
            }
          ]
        },
        {
          "code" : "99b18761-88d7-44b2-915d-c64aa0b3b562",
          "display" : "Hjerte og lunger",
          "concept" : [
            {
              "code" : "acb817ea-63aa-4d7e-aa67-f557c73f7c8a",
              "display" : "Udholdenhed",
              "definition" : "Funktioner bestemmende for respiratorisk og kardiovaskulær kapacitet, som er nødvendig ved fysisk anstrengelse"
            },
            {
              "code" : "a2253dcc-4806-4491-af3a-373344a70ccc",
              "display" : "Cirkulation",
              "definition" : "Funktioner relateret til det kardiovaskulære system"
            },
            {
              "code" : "fa0028ca-72c5-4180-aefe-7b696698b196",
              "display" : "Respiration",
              "definition" : "Funktioner relateret til vejrtrækning"
            }
          ]
        },
        {
          "code" : "2b11e7a0-1faf-4b45-a653-4c347f019266",
          "display" : "Bevægeapperatet",
          "concept" : [
            {
              "code" : "d6a26f74-bff7-40e0-95d5-0b382119ad6d",
              "display" : "Koordination",
              "definition" : "Kontrol over og koordinering af viljebestemte bevægelser"
            },
            {
              "code" : "396c3048-410b-46a8-89e6-ba89cd0e8fda",
              "display" : "Muskelfunktion",
              "definition" : "Funktioner relateret til muskelstyrke, -udholdenhed og -tonus"
            },
            {
              "code" : "3c366bd0-0c87-4f2d-a755-0fba564c7a9d",
              "display" : "Ledfunktion",
              "definition" : "Funktioner relateret til ledbevægelighed og -stabilitet"
            }
          ]
        },
        {
          "code" : "1dae1e1e-306e-48f2-b9e1-2a180301d8dd",
          "display" : "Mentale funktioner",
          "concept" : [
            {
              "code" : "56860429-eabe-4d48-b8ad-d7f7b28f6df5",
              "display" : "Hukommelse",
              "definition" : "Mentale funktioner bestemmende for registrering, lagring og genkaldelse af informationer efter behov"
            },
            {
              "code" : "87a689e9-fe3b-4696-a15f-07b7be8fecf4",
              "display" : "Psykomotoriske funktioner",
              "definition" : "Mentale funktioner som styrer motoriske og psykologiske forhold på det kropslige plan"
            },
            {
              "code" : "95fbdaed-00a4-461e-961d-629322c89914",
              "display" : "Orienteringsevne",
              "definition" : "Mentale funktioner bestemmende for kendskab til og konstatering af relationerne til en selv, til andre, til tid, sted og andre omgivelser"
            },
            {
              "code" : "d377b371-64f5-416c-93f3-852e437ae1cb",
              "display" : "Følelsesfunktioner",
              "definition" : "Mentale funktioner forbundet med følelser og affektive komponenter i sindet"
            },
            {
              "code" : "1d9759c6-6526-4d07-994a-5dee3fa65177",
              "display" : "Energi og handlekraft",
              "definition" : "Mentale funktioner af fysiologisk og psykologisk art, som får personen til at opnå tilfredsstillelse af specifikke behov og overordnede mål på en vedholdende måde"
            },
            {
              "code" : "36248229-67ac-4f5a-9446-b72c7208e34d",
              "display" : "Opmærksomhed",
              "definition" : "Mentale funktioner bestemmende for fokusering på eksterne stimuli eller indre oplevelser så længe som nødvendigt"
            },
            {
              "code" : "eec8fc0a-7a30-49ea-ba3d-1c1d3cb50bfb",
              "display" : "Oplevelse af egen krop",
              "definition" : "Mentale funktioner bestemmende for repræsentation og bevidsthed om egen krop"
            },
            {
              "code" : "2c99f93c-4459-471d-a6b8-303d32c15ed6",
              "display" : "Overordnede kognitive funktioner",
              "definition" : "Mentale funktioner omfattende kompleks målrettet adfærd, såkaldte eksekutive funktioner"
            }
          ]
        },
        {
          "code" : "0337193a-b5cc-43e1-a324-fa28944bfc3b",
          "display" : "Sanser og smerter",
          "concept" : [
            {
              "code" : "40cbf3ef-9ec0-4795-bb3b-ea7c788b49e2",
              "display" : "Smerter",
              "definition" : "Fund relateret til smerter"
            },
            {
              "code" : "1b5ad154-d22c-4949-a5db-c01ccefd64d9",
              "display" : "Balance",
              "definition" : "Funktioner relateret til kroppens balance"
            },
            {
              "code" : "2d3a12d0-c0d9-4702-a96e-1d7824c80c6c",
              "display" : "Sanser",
              "definition" : "Fund og funktioner relateret til det sensoriske nervesystem"
            }
          ]
        }
      ]
    },
    {
      "code" : "H",
      "display" : "Servicelov Indsatskatalog",
      "concept" : [
        {
          "code" : "H3",
          "display" : "SEL § 84 stk. 1",
          "concept" : [
            {
              "code" : "H3.3",
              "display" : "Praktisk hjælp efter §84",
              "definition" : "Afløsning af den pårørendes indsats med praktisk hjælp."
            },
            {
              "code" : "H3.1",
              "display" : "Aflastningsophold uden for hjemmet",
              "definition" : "Dækker aflastning af den pårørende. Alle former for aflastningsophold uden for hjemmet, således at den pårørende kan aflastes og/eller deltage i sociale aktiviteter, som den pårørende ellers ville være afskåret fra at deltage i."
            },
            {
              "code" : "H3.2",
              "display" : "Afløsning i hjemmet",
              "definition" : "Dækker afløsning af den pårørende. Dvs. kommunal tilstedeværelse således at den pårørende fx kan deltage i sociale aktiviteter, som den pårørende ellers ville være afskåret fra at deltage i."
            }
          ]
        },
        {
          "code" : "H6",
          "display" : "SEL § 86 stk. 2",
          "concept" : [
            {
              "code" : "H6.1",
              "display" : "Vedligehold af færdigheder",
              "definition" : "Træning med henblik på at fastholde færdigheder/funktionsniveau, der er risiko for forringelse eller bortfald af."
            }
          ]
        },
        {
          "code" : "H7",
          "display" : "0-ydelser",
          "concept" : [
            {
              "code" : "H7.2",
              "display" : "Koordinerende 0-ydelse",
              "definition" : "Ydelsen omfatter en systematisk koordinering af kommunale aktørers tværfaglige indsatser. Som udgangspunkt sammen med borgeren og evt. med deltagelse af pårørende."
            },
            {
              "code" : "H7.1",
              "display" : "Generel 0-ydelse",
              "definition" : "Ydelsen kan anvendes kommunalt eller tværkommunalt i en periode, fx i forbindelse med puljemidler, projekter eller lignende."
            }
          ]
        },
        {
          "code" : "H2",
          "display" : "SEL § 83A",
          "concept" : [
            {
              "code" : "H2.11",
              "display" : "RH Praktiske indsatser i relation til børn i husstanden"
            },
            {
              "code" : "H2.9",
              "display" : "RH Tøjvask"
            },
            {
              "code" : "H2.10",
              "display" : "RH Udskillelser"
            },
            {
              "code" : "H2.6",
              "display" : "RH Rengøring"
            },
            {
              "code" : "H2.2",
              "display" : "RH Hverdagens aktiviteter"
            },
            {
              "code" : "H2.8",
              "display" : "RH Tilsyn/omsorg"
            },
            {
              "code" : "H2.5",
              "display" : "RH Personlig hygiejne"
            },
            {
              "code" : "H2.3",
              "display" : "RH Indkøb"
            },
            {
              "code" : "H2.7",
              "display" : "RH Tilberede/anrette mad"
            },
            {
              "code" : "H2.1",
              "display" : "RH Ernæring"
            },
            {
              "code" : "H2.4",
              "display" : "RH Mobilitet"
            }
          ]
        },
        {
          "code" : "H1",
          "display" : "SEL § 83",
          "concept" : [
            {
              "code" : "H1.4",
              "display" : "Mobilitet",
              "definition" : "Alle aktiviteter i forbindelse med forflytning, lejring og vending."
            },
            {
              "code" : "H1.12",
              "display" : "Praktiske indsatser i relation til børn i husstanden",
              "definition" : "Tilbagevendende praktiske opgaver der relaterer sig til børn i husstanden. Indsatsen bevilliges som praktisk bistand til den forælder, der ikke selv er i stand til at udføre opgaven"
            },
            {
              "code" : "H1.2",
              "display" : "Udskillelser",
              "definition" : "Alle indsatser relateret til det at gå på toilettet, hvad enten borgeren selv kan, har brug for assistance eller for en erstatning for toiletbesøg i form af bleskift, uridomskift eller bækken-/kolbetømning"
            },
            {
              "code" : "H1.11",
              "display" : "Madservice",
              "definition" : "Madservice er alene den ydelse, der visiteres til borgere, der modtager mad via en madserviceordning. Der kan ikke tildeles konkrete indsatser med tidsangivelse til madservice."
            },
            {
              "code" : "H1.1",
              "display" : "Personlig hygiejne",
              "definition" : "Alle indsatser relateret til den personlige hygiejne, som fx bad, hårvask, øvre og nedre toilette, af- og påklædning og negleklipning. Inkluderer også af- og påsætning af kropsbårne hjælpemidler (der ikke er omfattet af en sundhedslovsydelse)"
            },
            {
              "code" : "H1.7",
              "display" : "Indkøb",
              "definition" : "Aktiviteter foretaget for at skaffe dagligvarer – fra indkøbsseddel skrives, til varer er stillet på plads"
            },
            {
              "code" : "H1.3",
              "display" : "Ernæring",
              "definition" : "Aktiviteter der foregår fra bord til mund. Altså alle indsatser, der vedrører indtagelse af mad og drikke, hvad enten der er tale om indsats til den egentlig handling at spise eller en indsats, der sikrer samvær under måltidet."
            },
            {
              "code" : "H1.9",
              "display" : "Tøjvask",
              "definition" : "Alle former for håndtering af vasketøj – fra snavsetøjskurven til tøjskabet"
            },
            {
              "code" : "H1.8",
              "display" : "Rengøring",
              "definition" : "Alle dele af rengøring, både den daglige og hovedrengøring. Bemærk: Skift af sengelinned samt evt. snerydning er en rengøringsydelse. Bækken-/kolbetømning kan også placeres her, såfremt det ikke indgår i forbindelse med en personlig pleje-indsats"
            },
            {
              "code" : "H1.5",
              "display" : "Hverdagens aktiviteter",
              "definition" : "Alle administrative og strukturelle opgaver. Det gælder både brevskrivning, hjælp til struktur, hjælp til medicin, hvor der ikke er tale om en overleveret ydelse, men fordi borgeren ikke selv har fysik til fx at håndtere sine piller, kontakt til myndighedspersoner, familie og venner"
            },
            {
              "code" : "H1.6",
              "display" : "Tilsyn/omsorg",
              "definition" : "Besøg der ikke er forbundet med en konkret opgave, men handler om at give en psykisk støtte, tryghed hos borgeren."
            },
            {
              "code" : "H1.10",
              "display" : "Tilberede/anrette mad",
              "definition" : "Aktiviteter der foregår fra køkken til bord – den praktiske del af måltidet."
            }
          ]
        },
        {
          "code" : "H4",
          "display" : "SEL § 84 stk. 2",
          "concept" : [
            {
              "code" : "H4.1",
              "display" : "Midlertidig ophold",
              "definition" : "\"Midlertidig ophold\" er udelukkende en bevilling af en plads. De indsatser, der leveres under et midlertidigt ophold, vil være indsatser, der er visiteret efter §§ 83, 83a, 86 De indsatser, der leveres under et midlertidigt ophold, vil være indsatser, der er visiteret efter §83a, §83, §86, stk. 1, 86, stk. 2."
            }
          ]
        },
        {
          "code" : "H5",
          "display" : "SEL § 86 stk. 1",
          "concept" : [
            {
              "code" : "H5.1",
              "display" : "Genoptræning af funktionsnedsættelse",
              "definition" : "Træning med henblik på at opnå et funktionsniveau svarende til det borgeren havde forud for en hændelse."
            }
          ]
        }
      ]
    },
    {
      "code" : "D",
      "display" : "Betydning",
      "concept" : [
        {
          "code" : "D2",
          "display" : "Oplever begrænsninger"
        },
        {
          "code" : "D1",
          "display" : "Oplever ikke begrænsninger"
        }
      ]
    },
    {
      "code" : "F",
      "display" : "Generelle oplysninger",
      "concept" : [
        {
          "code" : "F12",
          "display" : "Boligens indretning",
          "definition" : "En beskrivelse af boligens fysiske rammer og omgivelser, der har betydning for borgerens hverdagsliv og funktionsevne."
        },
        {
          "code" : "F2",
          "display" : "Motivation",
          "definition" : "Drivkraften bag at borgeren handler på en bestemt måde eller går i gang med/opretholder en opgave/indsats."
        },
        {
          "code" : "F6",
          "display" : "Uddannelse og job",
          "definition" : "Nuværende eller tidligere uddannelsesog/eller erhvervsmæssig baggrund. Fx folkeskole, erhvervsuddannelse og videregående uddannelse."
        },
        {
          "code" : "F8",
          "display" : "Netværk",
          "definition" : "Personer som er tæt på borgeren, og som giver praktisk og/eller følelsesmæssigt støtte og omsorg overfor borgeren. Netværk kan være offentligt eller privat. Et offentligt netværk består af personlige hjælpere, sundhedspersonale og andre professionelle primært omsorgsgivere. Privat netværk er familie, slægtning, venner og bekendtskaber."
        },
        {
          "code" : "F7",
          "display" : "Livshistorie",
          "definition" : "En beskrivelse af borgerens oplevelse af væsentlige begivenheder, interesser og gøremål igennem livet."
        },
        {
          "code" : "F5",
          "display" : "Vaner",
          "definition" : "Regelmæssig adfærd som borgeren har tillært gennem stadig gentagelse og udførelse helt eller delvist ubevidst.Vaner er fx døgnrytmen, måden at blive tiltalt på, kontakt med medmennesker og relationer, måde at anskue verden på."
        },
        {
          "code" : "F4",
          "display" : "Roller",
          "definition" : "De roller som er særligt vigtige for borgeren i forhold til familie, arbejde og samfund."
        },
        {
          "code" : "F3",
          "display" : "Ressourcer",
          "definition" : "De fysiske eller mentale kræfter, som borgerenen i et vist omfang har til rådighed og kan udnytte. Fysiske kræfter kan fx være i form af fysisk sundhed og styrke. Mentale kræfter kan fx være i form af psykisk sundhed og styrke, herunder tanker og måder at forholde sig til situationer og andre mennesker på."
        },
        {
          "code" : "F9",
          "display" : "Helbredsoplysninger",
          "definition" : "Helbredsoplysninger: Aktuelle eller tidligere sygdomme og handicap der har betydning for borgerens situation. Sundhedsfaglige kontakter: Medarbejder eller enheder indenfor sundhedsvæsenet borgeren er tilknyttet, fx øjenlæge, tandlæge, fodterapeut eller afdeling/ambulatorium."
        },
        {
          "code" : "F1",
          "display" : "Mestring",
          "definition" : "Borgerens bevidste eller ubevidste håndtering af livet/sygdommen – både udfordringer og muligheder."
        },
        {
          "code" : "F10",
          "display" : "Hjælpemidler",
          "definition" : "Udstyr, produkter og teknologi som anvendes af borgeren i daglige aktiviteter, inkl. sådanne som er tilpasset eller særligt fremstillet til, implanteret i, placeret på eller nær personen, som anvender dem. (Inkl. almindelige genstande og hjælpemidler og teknologi til personlig anvendelse)."
        }
      ]
    },
    {
      "code" : "A",
      "display" : "Henvendelse/henvisning fra",
      "concept" : [
        {
          "code" : "A15",
          "display" : "Andre"
        },
        {
          "code" : "A3",
          "display" : "Sagsbehandler, anden forvaltning"
        },
        {
          "code" : "A1",
          "display" : "Borger"
        },
        {
          "code" : "A13",
          "display" : "Sygehus - psykiatrisk"
        },
        {
          "code" : "A12",
          "display" : "Sygehus - medicinsk"
        },
        {
          "code" : "A10",
          "display" : "Speciallæge"
        },
        {
          "code" : "A9",
          "display" : "Egen læge/vagtlæge"
        },
        {
          "code" : "A8",
          "display" : "Anden kommune"
        },
        {
          "code" : "A4",
          "display" : "Hjemmeplejen"
        },
        {
          "code" : "A11",
          "display" : "Sygehus - kirurgisk"
        },
        {
          "code" : "A6",
          "display" : "Træning"
        },
        {
          "code" : "A5",
          "display" : "Hjemmesygeplejen"
        },
        {
          "code" : "A7",
          "display" : "Sundhedsfremme og forebyggelse"
        },
        {
          "code" : "A14",
          "display" : "Sygehus - akutmodtagelse"
        },
        {
          "code" : "A2",
          "display" : "Pårørende"
        }
      ]
    },
    {
      "code" : "J",
      "display" : "Funktionsevnetilstande",
      "concept" : [
        {
          "code" : "J1",
          "display" : "Egenomsorg",
          "concept" : [
            {
              "code" : "J1.6",
              "display" : "Spise",
              "definition" : "Udføre sammensatte handlinger i forbindelse med indtagelse af føde, som er serveret for en, få maden op til munden og spise på en kulturelt accepteret måde, skære eller bryde maden i stykker, åbne flasker og dåser, anvende spiseredskaber, deltage i måltider og i festligheder."
            },
            {
              "code" : "J1.3",
              "display" : "Af- og påklædning",
              "definition" : "Udføre sammensatte handlinger i forbindelse med på- og afklædning, at tage fodbeklædning på og af i rækkefølge og i overensstemmelse med den sociale sammenhæng og de klimatiske forhold som f.eks. iføre sig, rette på og afføre sig skjorter, bluser, bukser, undertøj, sarier, kimonoer, strømpebukser, hatte, handsker, frakker, sko, støvler, sandaler og hjemmesko."
            },
            {
              "code" : "J1.2",
              "display" : "Kropspleje",
              "definition" : "Pleje af de dele af kroppen, som behøver anden pleje end vask og tørring f.eks. hud, ansigt, tænder, hår, negle og kønsdele."
            },
            {
              "code" : "J1.4",
              "display" : "Drikke",
              "definition" : "Holde fast om en drik, tage drikken op til munden og drikke på en kulturelt accepteret måde, blande, omrøre og skænke drikke op, åbne flasker og dåser, bruge sugerør eller drikke af rindende vand fra en hane eller en kilde; amning."
            },
            {
              "code" : "J1.7",
              "display" : "Varetage egen sundhed",
              "definition" : "Sikre sit velvære, helbred og fysiske og psykiske velbefindende ved f.eks. at indtage varieret kost, have passende niveau af fysisk aktivitet, holde sig varm eller afkølet, undgå skader på helbredet, dyrke sikker sex inkl. anvendelse af kondomer, lade sig vaccinere og følge regelmæssige helbredsundersøgelser."
            },
            {
              "code" : "J1.8",
              "display" : "Gå på toilet",
              "definition" : "Planlægge og udføre toiletbesøg til udskillelse af affaldsprodukter (menstruation, urin og afføring) og efterfølgende rengøring."
            },
            {
              "code" : "J1.5",
              "display" : "Fødeindtagelse",
              "definition" : "Indtagelse og bearbejdning af fødemidler og væsker gennem munden."
            },
            {
              "code" : "J1.1",
              "display" : "Vaske sig",
              "definition" : "Vaske og tørre sig på kroppen og kropsdele med anvendelse af vand og passende rensemidler f.eks. tage bad, brusebad, vaske hænder og fødder, ansigt og hår og tørre sig med håndklæde."
            }
          ]
        },
        {
          "code" : "J5",
          "display" : "Samfundsliv",
          "concept" : [
            {
              "code" : "J5.1",
              "display" : "Have lønnet beskæftigelse",
              "definition" : "Deltage i alle aspekter af et arbejde, erhverv eller anden form for beskæftigelse som ansat på fuldtid eller deltid eller som selvstændig som f.eks. at søge et arbejde og få det, udføre de nødvendige opgaver i jobbet, møde på arbejde til tiden, lede andre arbejdere eller selv blive ledet, udføre de nødvendige opgaver alene eller i gruppe."
            }
          ]
        },
        {
          "code" : "J2",
          "display" : "Praktiske opgaver",
          "concept" : [
            {
              "code" : "J2.2",
              "display" : "Lave mad",
              "definition" : "Planlægge, tilberede og servere enkle eller sammensatte måltider til sig selv og andre som f.eks. at sammen sætte et måltid, udvælge appetitlig mad og drikke, fremskaffe ingredienser til tilberedning af måltider; forberede mad og drikke til tilberedning, lave varm og kold mad og drikke, servere maden."
            },
            {
              "code" : "J2.4",
              "display" : "Skaffe sig varer og tjenesteydelser",
              "definition" : "Vælge, tilvejebringe og transportere varer, som er nødvendige i dagliglivet som f.eks. at vælge, købe, transportere og opbevare mad, drikke, tøj, rengøringsmidler, brændsel, husholdningsgenstande og værktøj; tilvejebringe brugsgenstande og service."
            },
            {
              "code" : "J2.3",
              "display" : "Udføre daglige rutiner",
              "definition" : "Udføre simple, komplekse og sammensatte handlinger til planlægning, styring og gennemførelse af dagligt tilbagevendende rutiner eller pligter som f.eks. at overholde tider og lægge planer for særlige aktiviteter i løbet af dagen."
            },
            {
              "code" : "J2.1",
              "display" : "Lave husligt arbejde",
              "definition" : "Holde hus ved at gøre rent, vaske tøj, bruge husholdningsmaskiner, opbevare mad og smide affald ud, f.eks. ved at feje, moppe, tørre borde, vægge og andre overflader af; holde orden i værelser og stuer, i skabe og skuffer; samle, vaske, tørre og stryge tøj; gøre fodtøj rent; bruge kost, børster og støvsuger; bruge vaskemaskine, tørretumbler og strygejern."
            }
          ]
        },
        {
          "code" : "J3",
          "display" : "Mobilitet",
          "concept" : [
            {
              "code" : "J3.6",
              "display" : "Ændre kropsstilling",
              "definition" : "Skifte kropsstilling og bevæge sig fra et sted til et andet som f.eks. at flytte sig fra en stol til liggende stilling og skifte til og fra knælende eller hugsiddende stilling."
            },
            {
              "code" : "J3.5",
              "display" : "Forflytte sig",
              "definition" : "Flytte sig fra en overflade til en anden som f.eks. at glide hen ad en bænk eller bevæge sig fra seng til stol uden at ændre kroppens stilling."
            },
            {
              "code" : "J3.4",
              "display" : "Færden i forskellige omgivelser",
              "definition" : "Gang og færden i forskellige omgivelser som f.eks. at gå mellem rum i huset, inden for en bygning eller ned ad gaden."
            },
            {
              "code" : "J3.8",
              "display" : "Gå",
              "definition" : "Bevæge sig til fods skrift for skridt på et underlag, således at den ene fod hele tiden hviler på underlaget, som når man slentrer, går forlæns, baglæns eller sidelæns."
            },
            {
              "code" : "J3.9",
              "display" : "Udholdenhed",
              "definition" : "Funktioner bestemmende for respiratorisk og kardiovaskulær kapacitet, som er nødvendig ved fysisk anstrengelse."
            },
            {
              "code" : "J3.7",
              "display" : "Muskelstyrke",
              "definition" : "Kraften som opstår ved kontraktion af en muskel eller en muskelgruppe."
            },
            {
              "code" : "J3.1",
              "display" : "Løfte og bære",
              "definition" : "Løfte en genstand op og flytte noget fra et sted til et andet som f.eks. at løfte en kop eller bære et barn fra et rum til et andet."
            },
            {
              "code" : "J3.2",
              "display" : "Bevæge sig omkring",
              "definition" : "Bevæge sig fra et sted til et andet på andre måder end ved at gå som f.eks. ved at klatre over en sten, løbe ned ad en gade, hoppe, springe, slå kolbøtter eller rende rundt om genstande."
            },
            {
              "code" : "J3.3",
              "display" : "Bruge transportmidler",
              "definition" : "Bruge transportmidler som passager til at færdes omkring som f.eks. at blive kørt i en bil eller køre med bus, rickshaw, hestetrukken vogn, private eller offentlig taxi, bus, tog, sporvogn, undergrundsbane, skib eller fly."
            }
          ]
        },
        {
          "code" : "J4",
          "display" : "Mentale funktioner",
          "concept" : [
            {
              "code" : "J4.1",
              "display" : "Anvende kommunikationsudstyr og -teknikker",
              "definition" : "Anvende udstyr, teknikker og andre midler med kommunikationsformål som f. eks. at ringe til en ven."
            },
            {
              "code" : "J4.6",
              "display" : "Energi og handlekraft",
              "definition" : "Overordnede mentale funktioner af fysiologiske og psykologiske art, som får personen til at opnå tilfredsstillelse af specifikke behov og overordnede mål på en vedholdende måde."
            },
            {
              "code" : "J4.3",
              "display" : "Orienteringsevne",
              "definition" : "Overordnede mentale funktioner bestemmende kendskab til og konstatering af relationerne til en selv, til andre, til tid, sted og andre omgivelser."
            },
            {
              "code" : "J4.8",
              "display" : "Problemløsning",
              "definition" : "Løsning af spørgsmål eller situationer ved at identificere og analysere emner, udvikle muligheder og løsninger, evaluere mulige virkninger af løsninger og gennemføre en valgt løsning som f.eks. ved løsning af en uoverensstemmelse mellem to personer."
            },
            {
              "code" : "J4.2",
              "display" : "Hukommelse",
              "definition" : "Specifikke mentale funktioner bestemmende for registrering, lagring genkaldelse af information efter behov."
            },
            {
              "code" : "J4.4",
              "display" : "Overordnede kognitive funktioner",
              "definition" : "Specifikke mentale funktioner først og fremmest knyttet til hjernens pandelapper omfattende kompleks målrettet adfærd som beslutningstagning, abstrakt tænkning, planlægning og gennemførelse af planer, mental fleksibilitet og tilpasning af adfærden efter omstændighederne, såkaldte eksekutive funktioner."
            },
            {
              "code" : "J4.5",
              "display" : "Følelsesfunktioner",
              "definition" : "Specifikke mentale funktioner forbundet med følelser og affektive komponenter i sindet."
            },
            {
              "code" : "J4.7",
              "display" : "Tilegne sig færdigheder",
              "definition" : "Udvikle basale og komplekse kompetencer i sammensatte handlinger eller opgaver med det formål at påbegynde og gennemføre erhvervelsen af en færdighed, som f.eks. håndtering af værktøj eller spil som skak."
            }
          ]
        }
      ]
    },
    {
      "code" : "B",
      "display" : "Funktionsniveau",
      "concept" : [
        {
          "code" : "B5",
          "display" : "Totale begrænsninger"
        },
        {
          "code" : "B2",
          "display" : "Lette begrænsninger"
        },
        {
          "code" : "B1",
          "display" : "Ingen/ubetydelige begrænsninger"
        },
        {
          "code" : "B6",
          "display" : "Ikke relevant"
        },
        {
          "code" : "B3",
          "display" : "Moderate begrænsninger"
        },
        {
          "code" : "B4",
          "display" : "Svære begrænsninger"
        }
      ]
    },
    {
      "code" : "59c107b1-afc2-400e-a129-f9676a0aa9bf",
      "display" : "Måltype",
      "concept" : [
        {
          "code" : "e182c5dc-9f91-474a-92e8-f62be3d498f4",
          "display" : "Tilstand forsvinder, mindskes eller forbliver uændret",
          "definition" : "Helbredstilstand eller funktionsevnetilstand forventes at forsvinde, mindskes eller forblive uændret ifm. indsatsen",
          "concept" : [
            {
              "code" : "15846728-58b4-4413-a9d1-be0f1404b10f",
              "display" : "Tilstand forbliver uændret",
              "definition" : "Helbredstilstand eller funktionsevnetilstand forventes at forblive uændret ifm. indsatsen."
            },
            {
              "code" : "8addc23a-f7c6-47c4-97fb-a73fcdfc9f65",
              "display" : "Tilstand mindskes",
              "definition" : "Helbredstilstand eller funktionsevnetilstand forventes at mindskes ifm. indsatsen"
            },
            {
              "code" : "81c827de-ef31-4410-aa57-0d1d1bc6c264",
              "display" : "Tilstand forsvinder",
              "definition" : "Helbredstilstand eller funktionsevnetilstand forventes at forsvinde ifm. indsatsen"
            }
          ]
        }
      ]
    }
  ]
}

```
