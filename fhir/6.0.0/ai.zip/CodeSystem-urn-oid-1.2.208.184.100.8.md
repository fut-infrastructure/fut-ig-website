# MedCom Measurement CodeSystem - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MedCom Measurement CodeSystem**

## CodeSystem: MedCom Measurement CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:urn:oid:1.2.208.184.100.8 | *Version*:6.0.0 |
| Active as of 2025-05-21 | *Computable Name*:MedComMeasurementCodeSystem |
| *Other Identifiers:*OID:1.2.208.184.100.8 | |

 
Complete MedCom Measurement CodeSystem (MCS) 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ObservationCodes](ValueSet-ehealth-observation-codes.md)
* [MedComPHMRObservationValueSet](ValueSet-phmr-observation-vs.md)
* [DK_IHE_EventCodeLists_VS](ValueSet-dk-ihe-eventcodelists-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "urn-oid-1.2.208.184.100.8",
  "url" : "urn:oid:1.2.208.184.100.8",
  "identifier" : [
    {
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:1.2.208.184.100.8"
    }
  ],
  "version" : "6.0.0",
  "name" : "MedComMeasurementCodeSystem",
  "title" : "MedCom Measurement CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-05-21T10:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "Complete MedCom Measurement CodeSystem (MCS)",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [
    {
      "code" : "phmr-unit",
      "uri" : "http://ehealth.sundhed.dk/cs/ehealth-property#phmr-unit",
      "type" : "string"
    }
  ],
  "concept" : [
    {
      "code" : "DIB0010",
      "display" : "Følsomhed højre;Fod",
      "definition" : "Fod—Følsomhed højre arb.akt.(ingen; normal; reduceret) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følsomhed højre;Fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0011",
      "display" : "Følsomhed venstre;Fod",
      "definition" : "Fod—Følsomhed venstre arb.akt.(ingen; normal; reduceret) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følsomhed venstre;Fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0014",
      "display" : "Blodtryk højre,index;Ankel/Arm",
      "definition" : "Ankel/Arm—Blodtryk højre,index  =  ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Blodtryk højre,index;Ankel/Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0015",
      "display" : "Blodtryk venstre,index;Ankel/Arm",
      "definition" : "Ankel/Arm—Blodtryk venstre,index  =  ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Blodtryk venstre,index;Ankel/Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0018",
      "display" : "Fodsår;højre fod = ? Ja, Nej",
      "definition" : "Fodsår;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodsår;højre fod = ? Ja, Nej"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0019",
      "display" : "Fodsår;venstre fod = ? Ja, Nej",
      "definition" : "Fodsår;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodsår;venstre fod = ? Ja, Nej"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0020",
      "display" : "Tidligere fodsår;højre fod",
      "definition" : "Tidligere fodsår;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidligere fodsår;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "DIB0021",
      "display" : "Tidligere fodsår;venstre fod",
      "definition" : "Tidligere fodsår;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidligere fodsår;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88001",
      "display" : "Ugentligt;Pt(motion)",
      "definition" : "Pt(motion)—Ugentligt; tid = ? time/uge",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ugentligt;Pt(motion)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "time/uge"
        }
      ]
    },
    {
      "code" : "MCS88002",
      "display" : "Dagligt;Pt(rygning)",
      "definition" : "Pt(rygning)—Dagligt; antal = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Dagligt;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88005",
      "display" : "Rygestop tilbudt;Pt(rygning)",
      "definition" : "Pt(rygning)—Rygestop tilbudt; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rygestop tilbudt;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88006",
      "display" : "Tobaksrygning ophørt;Pt(rygning)",
      "definition" : "Pt(rygning)—Ophørt = ? Årstal",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tobaksrygning ophørt;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88008",
      "display" : "Passiv tobaksrygning;Pt(rygning)",
      "definition" : "Pt(rygning)—Udsættes du for passiv tobaksrygning; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Passiv tobaksrygning;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88009",
      "display" : "Rygestop hjælp ønskes;Pt(rygning)",
      "definition" : "Pt(rygning)—Vil du gerne have hjælp til at holde op; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rygestop hjælp ønskes;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88010",
      "display" : "Vil du gerne holde op;Pt(rygning)",
      "definition" : "Pt(rygning)—Vil du gerne holde op; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Vil du gerne holde op;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88011",
      "display" : "Ryger du tobak;Pt(rygning)",
      "definition" : "Pt(rygning)—Ryger du tobak; arb.akt.(dagligt; lejlighedsvis; ophørt; aldrig røget) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ryger du tobak;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88014",
      "display" : "Diabeteskontrol aftalt;Pt(diabetes)",
      "definition" : "Pt(diabetes)—Antal diabeteskontroller aftalt i det kommende år; antal (værdi 0-10) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Diabeteskontrol aftalt;Pt(diabetes)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88015",
      "display" : "FEV1;Lunge",
      "definition" : "Lunge—Lungefunktionsundersøgelse FEV1; vol. = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "FEV1"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L"
        }
      ]
    },
    {
      "code" : "MCS88016",
      "display" : "FVC;Lunge",
      "definition" : "Lunge—Lungefunktionsundersøgelse vitalkapasitet FVC; vol. = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "FVC"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FVC;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88017",
      "display" : "FEV1/FVC;Lunge",
      "definition" : "Lunge—FEV1/FVC; ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1/FVC;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88019",
      "display" : "Blodtryk hjemme systolisk;Arm",
      "definition" : "Arm—Blodtryk(systolisk) hjemme; tryk = ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Systolisk blodtryk"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Blodtryk hjemme systolisk;Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmHg"
        }
      ]
    },
    {
      "code" : "MCS88020",
      "display" : "Blodtryk hjemme diastolisk;Arm",
      "definition" : "Arm—Blodtryk(diastolisk) hjemme; tryk = ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Diastolisk blodtryk"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Blodtryk hjemme diastolisk;Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmHg"
        }
      ]
    },
    {
      "code" : "MCS88021",
      "display" : "MRC skala;Pt(KOL)",
      "definition" : "Pt(KOL) —MRC skala; arb.antal(værdi 1-5) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "MRC"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "MRC skala;Pt(KOL)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88022",
      "display" : "Eksacerbationer;Pt(KOL)",
      "definition" : "Pt(KOL)—Antal eksacerbationer i det sidst forløbne år; antal (værdi 1-20) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Eksacerbationer;Pt(KOL)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88023",
      "display" : "FEV1 af forventet værdi;Pt(KOL)",
      "definition" : "Pt(KOL)—FEV1 i % af den forventede værdi (efter højde,alder og køn); ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "FEV1 af forventet værdi"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1 af forventet værdi;Pt(KOL)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88024",
      "display" : "Pakkeår;Pt(rygning)",
      "definition" : "Pt(rygning)—Antal pakkeår (20 cigaretter dagligt i et år) = ? År",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Pakkeår;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "År"
        }
      ]
    },
    {
      "code" : "MCS88025",
      "display" : "HbA1c, patientaftalt mål;Hb(B)",
      "definition" : "Hb(B)(mål)—HbA1c patientmål aftalt for kommende år; stofratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "HbA1c, patientaftalt mål;Hb(B)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88026",
      "display" : "LDL-Kolesterol, patientaftalt mål;P",
      "definition" : "P(mål)—LDL Kolesterol patientmål aftalt for kommende år; stofk. = ? mmol/L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "LDL-Kolesterol, patientaftalt mål;P"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmol/L"
        }
      ]
    },
    {
      "code" : "MCS88027",
      "display" : "BT(sys), patientaftalt mål;Arm",
      "definition" : "Arm(mål)—Blodtryk(systolisk) patientmål aftalt for kommende år = ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "BT(sys), patientaftalt mål;Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmHg"
        }
      ]
    },
    {
      "code" : "MCS88028",
      "display" : "Legeme vægt, mål aftalt;Pt(mål)",
      "definition" : "Pt(mål)—Legeme; masse mål aftalt for kommende år = ? kg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Legeme vægt, mål aftalt;Pt(mål)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "kg"
        }
      ]
    },
    {
      "code" : "MCS88030",
      "display" : "FEV1 reversibilitet;Lunge",
      "definition" : "Lunge—FEV1 reversibilitet = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1 reversibilitet;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L"
        }
      ]
    },
    {
      "code" : "MCS88032",
      "display" : "Hjertesvigts funktionskl.;Pt(NYHA)",
      "definition" : "Pt(NYHA)—Hjerteinsufficiens funktionsklasse; antal (værdi 0-4) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hjertesvigts funktionskl.;Pt(NYHA)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88033",
      "display" : "BT(dia), patientaftalt mål;Arm",
      "definition" : "Arm(mål)—Blodtryk(diastolisk) patientmål aftalt for kommende år = ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "BT(dia), patientaftalt mål;Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmHg"
        }
      ]
    },
    {
      "code" : "MCS88034",
      "display" : "BMI, mål aftalt;Pt(mål)",
      "definition" : "Pt(mål)—Legeme; massekoefficient(masse/kvadreret højde) mål aftalt for det kommende år  = ? kg/m²",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "BMI, mål aftalt;Pt(mål)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "kg/m²"
        }
      ]
    },
    {
      "code" : "MCS88036",
      "display" : "Alkoholforbrug;Pt(alkohol)",
      "definition" : "Pt(alkohol)—Alkoholforbrug ugentlig; antal = ? Uge",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Alkoholforbrug;Pt(alkohol)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "Uge"
        }
      ]
    },
    {
      "code" : "MCS88039",
      "display" : "Til rådighed for arbejdsmark.;Pt",
      "definition" : "Pt—Står til rådighed for arbejdsmarkedet; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Til rådighed for arbejdsmark.;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88040",
      "display" : "ASS score;Pt(angst)",
      "definition" : "Pt(angst)—Angst scoreskema; antal (værdi 0-50) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "ASS score;Pt(angst)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88041",
      "display" : "MDI score;Pt(depression)",
      "definition" : "Pt(depression)—Major Depression Inventory; antal (værdi 0-50) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "MDI score;Pt(depression)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88042",
      "display" : "MMSE score;Pt",
      "definition" : "Pt—Mini-Mental State Examination score; antal (værdi 0-30) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "MMSE score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88043",
      "display" : "Er der talt om kost;Pt(kost)",
      "definition" : "Pt(kost)—Er der talt om kost; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Er der talt om kost;Pt(kost)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88044",
      "display" : "Øjenus., fundusundersøgelse;Pt(øje)",
      "definition" : "Pt(øje)—Øjenbaggrundsundersøgelse, fundusundersøgelse; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øjenus., fundusundersøgelse;Pt(øje)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88050",
      "display" : "Rejse sætte sig testen;Pt",
      "definition" : "Pt—Rejse sætte sig testen; antal (værdi 0-50) =  × 1/30s",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "Rejse-sætte-sig-test"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rejse sætte sig testen;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "1/30s"
        }
      ]
    },
    {
      "code" : "MCS88052",
      "display" : "Kostscore;Pt(kost)",
      "definition" : "Pt(kost)—kostscore; antal (0-12) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kostscore;Pt(kost)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88053",
      "display" : "Helbred;Pt(selvvurderet helbred)",
      "definition" : "Pt(selvvurderet helbred)—hvordan synes du dit helbred er alt i alt; arb.akt.(Fremragende, vældigt godt, godt, mindre godt, dårligt) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Helbred;Pt(selvvurderet helbred)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88058",
      "display" : "GOLD Inddeling;Pt(KOL)",
      "definition" : "Pt(KOL) —GOLD Inddeling; arb.akt.(A; B; C; D; E) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "GOLD Inddeling;Pt(KOL)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88059",
      "display" : "Symptom;Pt(CMDQ)",
      "definition" : "Pt(CMDQ) —Symptom; antal (værdi 0-48) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Symptom;Pt(CMDQ)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88060",
      "display" : "Helbredsangst;Pt(CMDQ)",
      "definition" : "Pt(CMDQ) —Helbredsangst; antal (værdi 0-28)  = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Helbredsangst;Pt(CMDQ)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88061",
      "display" : "Angsttilstand;Pt(CMDQ)",
      "definition" : "Pt(CMDQ) —Angsttilstand; antal (værdi 0-16) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Angsttilstand;Pt(CMDQ)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88062",
      "display" : "Depression;Pt(CMDQ)",
      "definition" : "Pt(CMDQ) —Depression; antal (værdi 0-24) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Depression;Pt(CMDQ)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88063",
      "display" : "Alkohol;Pt(CMDQ)",
      "definition" : "Pt(CMDQ) —Alkohol; antal (værdi 0-4) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Alkohol;Pt(CMDQ)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88067",
      "display" : "Taljeomkreds mål aftalt;Pt(diabet)",
      "definition" : "Pt(diabetes)—Taljeomkreds mål aftalt for det kommende år; længde = ? M",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Taljeomkreds mål aftalt;Pt(diabet)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "m"
        }
      ]
    },
    {
      "code" : "MCS88068",
      "display" : "Fysisk aktivitet fritid.;Pt(motion)",
      "definition" : "Pt(motion)—fysisk aktivitet i fritiden; arb.akt.(konkurrence; motionsidræt, lettere motion, stillesiddende) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fysisk aktivitet fritid.;Pt(motion)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88069",
      "display" : "Svangre us.;Pt(svangreundersøgelse)",
      "definition" : "Pt(svangreundersøgelse)—Hvilken svangreundersøgelse;  arb.akt.(første; anden; tredje; fjerde) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Svangre us.;Pt(svangreundersøgelse)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88070",
      "display" : "Børne us.;Pt(børneundersøgelse)",
      "definition" : "Pt(børneundersøgelse)—Hvilken børneundersøgelse; arb.akt.( 1 uges; 5 ugers; 5 måneders; 1 års; 2 års; 3 års; 4 års; 5 års) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Børne us.;Pt(børneundersøgelse)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88071",
      "display" : "30 minutter om dagen;Pt(motion)",
      "definition" : "Pt(motion)—fysisk aktiv 30 minutter om dagen; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "30 minutter om dagen;Pt(motion)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88072",
      "display" : "DAN-PSS;Pt(urinvejssymptomer)",
      "definition" : "Pt(urinvejssymptomer)—Dansk Prostata Symptom Scoringsskema; arb.akt.(tømning; fyldning; andre; seksual) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "DAN-PSS;Pt(urinvejssymptomer)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88099",
      "display" : "FEV1/FEV6;Lunge",
      "definition" : "Lunge—FEV1/FEV6 ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1/FEV6;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88100",
      "display" : "FEV6;Lunge",
      "definition" : "Lunge—Lungefunktionsundersøgelse COPD FEV6; vol. = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV6;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L"
        }
      ]
    },
    {
      "code" : "MCS88101",
      "display" : "Strep A test",
      "definition" : "Halspodning A streptokok antigen",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Strep A test"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88102",
      "display" : "Peakflow;Pt",
      "definition" : "Pt—Peakflow",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Peakflow;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88104",
      "display" : "FVC reversibilitet;Lunge",
      "definition" : "Lunge—FVC reversibilitet = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FVC reversibilitet;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L"
        }
      ]
    },
    {
      "code" : "MCS88105",
      "display" : "FEV1/FVC reversibilitet;Lunge",
      "definition" : "Lunge—FEV1/FVC reversibilitet; ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1/FVC reversibilitet;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88106",
      "display" : "Stoffer;Pt(problematisk stofbrug)",
      "definition" : "Pt(problematisk stofbrug)—Hash 4 eller flere dg inden for den seneste mnd og/eller andre euforiserende stoffer, som fx amfetamin, kokain og ecstasy 1 eller flere dg inden for den seneste mnd; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stoffer;Pt(problematisk stofbrug)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88108",
      "display" : "Stress score;Pt(stress)",
      "definition" : "Pt(stress)—Stress scoreskema; antal (værdi 0-20) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stress score;Pt(stress)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88109",
      "display" : "FVC/FVC forventet;Lunge",
      "definition" : "Lunge—FVC/FVC forventet;  ratio= ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FVC/FVC forventet;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88110",
      "display" : "FEV1/FEV1 forventet;Lunge",
      "definition" : "Lunge—FEV1/FEV1 forventet; ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1/FEV1 forventet;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88111",
      "display" : "Set Score FVC;Lunge",
      "definition" : "Lunge—Set Score FVC lungefunktion = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Set Score FVC;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88112",
      "display" : "Set score FEV1;Lunge",
      "definition" : "Lunge—Set Score FEV1 lungefunktion = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Set score FEV1;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88113",
      "display" : "Væske+vandskema;Pt(urinvejssympt)",
      "definition" : "Pt(urinvejssymptomer)—Væske+vandladningsskema; arb.akt.(normal; unormal) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Væske+vandskema;Pt(urinvejssympt)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88114",
      "display" : "Hovedpinedagbog;Pt(voksen)",
      "definition" : "Pt(voksen)—Hovedpinedagbog Diagnostik; arb.akt.(normal; unormal) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hovedpinedagbog;Pt(voksen)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88115",
      "display" : "Væske+vandskema;Pt(barn)",
      "definition" : "Pt(barn)—Væske+vandladningsskema; arb.akt.(normal; unormal) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Væske+vandskema;Pt(barn)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88116",
      "display" : "Debutår;Pt(diabetes)",
      "definition" : "Pt(diabetes)—Debutår = ? Årstal",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Debutår;Pt(diabetes)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88117",
      "display" : "Retinopati;Pt(diabetes)",
      "definition" : "Pt(diabetes)—Retinopati; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Retinopati;Pt(diabetes)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88118",
      "display" : "PEP-fløjte;Pt",
      "definition" : "Pt—Positive Expiratory Pressure",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "PEP-fløjte;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88119",
      "display" : "Tungeskrab",
      "definition" : "Tungeskrab",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tungeskrab"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88120",
      "display" : "Stabil Angina Pectoris;Pt(CCS)",
      "definition" : "Pt(CCS)—Stabil Angina Pectoris; antal (værdi 1-4) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stabil Angina Pectoris;Pt(CCS)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88121",
      "display" : "Residualurin;Pt",
      "definition" : "Pt—Residualurin; mængde = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Residualurin;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L"
        }
      ]
    },
    {
      "code" : "MCS88122",
      "display" : "Respirationsfrekvens;Pt",
      "definition" : "Pt—Respiration; frekvens = ? X 1/min",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Respirationsfrekvens;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "x1/min"
        }
      ]
    },
    {
      "code" : "MCS88123",
      "display" : "Væske pr os, 24h;Pt",
      "definition" : "Pt—Væske pr os, seneste døgn; mængde = ? L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Væske pr os, 24h;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L"
        }
      ]
    },
    {
      "code" : "MCS88124",
      "display" : "Barthel-20 Index;Pt",
      "definition" : "Pt—Barthel-20 Index; antal (værdi 0-20) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Barthel-20 Index;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88125",
      "display" : "TOBS score;Pt",
      "definition" : "Pt—Tidlig Opsporing af Begyndende Sygdom (TOBS) score; antal (værdi 0-15) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "TOBS score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88126",
      "display" : "Bevidsthed;Pt",
      "definition" : "Pt—Bevidsthedsniveau; arb.antal(værdi 0-3) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Bevidsthed;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88127",
      "display" : "Spisning;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Spisning; antal(værdi 0-2) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Spisning;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88128",
      "display" : "Forflytning;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Forflytning fra seng til stol; antal(værdi 0-3) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forflytning;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88129",
      "display" : "Pers.hygiejne;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Personlig hygiejne; antal(værdi 0-1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Pers.hygiejne;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88130",
      "display" : "Toiletbesøg;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Toiletbesøg; antal(værdi 0-2) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Toiletbesøg;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88131",
      "display" : "Badning;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Badning; antal(værdi 0-1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Badning;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88132",
      "display" : "Mobilitet;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Mobilitet indendørs; antal(værdi 0-3) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobilitet;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88133",
      "display" : "Trappegang;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Trappegang; antal(værdi 0-2) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Trappegang;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88134",
      "display" : "Påklædning;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Påklædning; antal(værdi 0-2) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Påklædning;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88135",
      "display" : "Tarmkontrol;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Tarmkontrol seneste uge; antal(værdi 0-2) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tarmkontrol;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88136",
      "display" : "Blærekontrol;Pt(hjælp afhængighed)",
      "definition" : "Pt(hjælp afhængighed)—Blærekontrol seneste uge; antal(værdi 0-2) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Blærekontrol;Pt(hjælp afhængighed)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88137",
      "display" : "CAT score;Pt",
      "definition" : "Pt—COPD Assessment Test (CAT) score; antal(værdi 0-40) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
            "code" : "consumer"
          },
          "value" : "CAT"
        },
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "CAT score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88138",
      "display" : "CMDQ score gruppe;Pt",
      "definition" : "Pt—Common Mental Disorders Questionnaire (CMDQ) score; egenskabsart(liste; proc.)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "CMDQ score gruppe;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88139",
      "display" : "Estimeret lungealder;Pt",
      "definition" : "Pt—Estimeret Lungealder; tid = ? år",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Estimeret lungealder;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "år"
        }
      ]
    },
    {
      "code" : "MCS88140",
      "display" : "Sund kost;Pt(kost)",
      "definition" : "Pt(kost)—Anser du din kost for at være sund - jf. Fødevarestyrelsens kostråd; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Sund kost;Pt(kost)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88141",
      "display" : "KRAM;Pt",
      "definition" : "Pt—Kost,Rygning,Alkohol,Motion(KRAM); arb.akt.(sund;usund) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "KRAM;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88142",
      "display" : "Inhalationsteknik kontrol;Pt",
      "definition" : "Pt—Inhalationsteknik for indtagelse af inhalationsmedicin kontrolleret i praksis; antal(værdi 0-1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Inhalationsteknik kontrol;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88143",
      "display" : "Lungefunktion undersøgt;Pt",
      "definition" : "Pt—Lungefunktion undersøgt; arb.akt.(Ja; Nej; Ej relevant; Ej muligt) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lungefunktion undersøgt;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88144",
      "display" : "Henvist til Rehabilitering;Pt",
      "definition" : "Pt—Henvist til Rehabilitering; arb.akt.(Ja; Nej; Ikke egnet; Ønsker ikke; Ej relevant; Ej spurgt) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Henvist til Rehabilitering;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88145",
      "display" : "Fysisk træning/motion;Pt",
      "definition" : "Pt—Fysisk anstrengende træning/motion; arb.akt.(Dagligt; Ugentligt; Månedligt; Ingen; Undgår; Ej spurgt) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fysisk træning/motion;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88146",
      "display" : "Heartscore;Pt",
      "definition" : "Pt—Heartscore(køn,alder,systolisk blodtryk,cholesterol); ratio=?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Heartscore;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88147",
      "display" : "Manniche VAS-score(total);Pt",
      "definition" : "Pt—Manniche VAS-score(total); antal(værdi 0-60) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Manniche VAS-score(total);Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88148",
      "display" : "STarT score;Pt",
      "definition" : "Pt—Subgroups for Targeted Treatment (STarT) score; arb.akt.(Lav; Middel; Høj) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "STarT score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88149",
      "display" : "Motion, mål aftalt;Pt(mål)",
      "definition" : "Pt(mål)—Motion, mål aftalt for kommende år; arb.akt.(Dagligt; Ugentligt; Månedligt; Ingen; Undgår; Ej spurgt) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Motion, mål aftalt;Pt(mål)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88150",
      "display" : "Alkohol, mål aftalt;Pt(mål)",
      "definition" : "Pt(mål)—Alkoholforbrug, mål aftalt for kommende år; antal = ? genstand/uge",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Alkohol, mål aftalt;Pt(mål)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "genstand/uge"
        }
      ]
    },
    {
      "code" : "MCS88151",
      "display" : "Rygning, mål aftalt;Pt(mål)",
      "definition" : "Pt(mål)—Rygning, mål aftalt for kommende år; arb.akt.(dagligt; lejlighedsvis; ophørt; aldrig røget) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rygning, mål aftalt;Pt(mål)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88152",
      "display" : "Øjenlægekontrol;Pt(diatetes)",
      "definition" : "Pt(diabetes)—Øjenlægekontrol; arb.akt.(ja;nej;ej relevant) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øjenlægekontrol;Pt(diatetes)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88153",
      "display" : "Fodundersøgelse;Pt(diabetes)",
      "definition" : "Pt(diabetes)—Fodundersøgelse; arb.akt.(ja;nej;ej relevant) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodundersøgelse;Pt(diabetes)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88154",
      "display" : "Ejection Fraction (EF); Hjerte",
      "definition" : "Hjerte—Ejection Fraction (EF), uddrivningsfunktion fra hjerte, ratio = ? (værdi 0-100)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ejection Fraction (EF); Hjerte"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88155",
      "display" : "E-cigaret status;Pt(rygning)",
      "definition" : "Pt(rygning)—E-cigaret status; arb.akt.(bruger, tidligere bruger, aldrig bruger)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "E-cigaret status;Pt(rygning)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88156",
      "display" : "Arbejdsbelastning;Pt",
      "definition" : "Pt—Arbejdsbelastning; effekt = ? W",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Arbejdsbelastning;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "W"
        }
      ]
    },
    {
      "code" : "MCS88157",
      "display" : "Maximalt iltoptag;Pt",
      "definition" : "Pt—Maximalt iltoptag; vol.hast.(proc.) = ? L/min",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Maximalt iltoptag;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "L/min"
        }
      ]
    },
    {
      "code" : "MCS88158",
      "display" : "Kondital;Pt",
      "definition" : "Pt—Kondital; vol.hast.(proc.) = ? mL/kg/min",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kondital;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mL/kg/min"
        }
      ]
    },
    {
      "code" : "MCS88159",
      "display" : "Iltbehandling i hjemmet;Pt",
      "definition" : "Pt—Iltbehandling i hjemmet; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Iltbehandling i hjemmet;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88160",
      "display" : "Livskvalitetsindex;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Livskvalitetsindex (DLQI); antal(værdi 0-30) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Livskvalitetsindex;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88161",
      "display" : "Symptomscore;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Symptomscore (PSSD); antal(værdi 0-100) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Symptomscore;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88162",
      "display" : "Sygdomsscore;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Sygdomstegnscore (PSSD); antal(værdi 0-100) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Sygdomsscore;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88163",
      "display" : "Hudpåvirkning;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning (BSA); antal(værdi 0-100) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkning;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88164",
      "display" : "Hudpåvirkning intim;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning intimområde (BSA);  arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkning intim;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88165",
      "display" : "Psoriasisgigtscore;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Screening for psoriasisgigt (PEST); antal(værdi 0-5) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Psoriasisgigtscore;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88166",
      "display" : "Hjerte/kar-helbred;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hjerte/kar helbredsmonitorering;  arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hjerte/kar-helbred;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88167",
      "display" : "Bivirkninger;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Bivirkninger til behandling; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Bivirkninger;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88168",
      "display" : "Helbredspåvirkning;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Samlet helbredspåvirkning i seneste uge (PGA); antal(værdi 0-10) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Helbredspåvirkning;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88169",
      "display" : "Generel trivsel;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Generel trivsel i seneste 2 uger (MDI); antal(værdi 0-5) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Generel trivsel;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88170",
      "display" : "Behov-reumatolog;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Behov for stillingtagning til reumatolog; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Behov-reumatolog;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88171",
      "display" : "TTI (12mdr);Pt(AFLI)",
      "definition" : "Pt(AFLI)—Tid i Terapeutisk Index over 12 mdr. (TTI); ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "TTI (12mdr);Pt(AFLI)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88172",
      "display" : "PAID-5;Pt",
      "definition" : "Pt—Problem Areas in Diabetes (PAID-5); antal(værdi 0-20) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "PAID-5;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88173",
      "display" : "WHO-5;Pt",
      "definition" : "Pt—Trivselsindekset (WHO-5); antal(værdi 0-100) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "WHO-5;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88174",
      "display" : "Ryger du;Pt",
      "definition" : "Pt(rygning)—Ryger du; arb.akt.(ja;nej) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ryger du;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88175",
      "display" : "Øjne undersøgt ifm. diabetes;Pt",
      "definition" : "Pt(diabetes)—Øjne undersøgt for diabetesforandringer indenfor de seneste 2 år; arb.akt.(ja;nej;ej besvaret) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øjne undersøgt ifm. diabetes;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88176",
      "display" : "Fødder undersøgt hos fodterapeut;Pt",
      "definition" : "Pt(diabetes)—Fødder undersøgt hos fodterapeut indenfor det seneste år; arb.akt.(ja;nej;ej besvaret) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fødder undersøgt hos fodterapeut;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88177",
      "display" : "Hudpåvirkning Hoved;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning Hoved; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkning Hoved;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88178",
      "display" : "Hudpåvirkn. Overkrop;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning Overkrop; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkn. Overkrop;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88179",
      "display" : "Hudpåvirkning Arme;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning Arme; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkning Arme;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88180",
      "display" : "Hudpåvirkning Ben;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning Ben; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkning Ben;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88181",
      "display" : "Samtale;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Emner til samtale; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Samtale;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88182",
      "display" : "Hudpåvirkning Ingen;Pt(psoriasis)",
      "definition" : "Pt(psoriasis)—Hudpåvirkning Ingen; arb.k.(0 1) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hudpåvirkning Ingen;Pt(psoriasis)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88183",
      "display" : "SCORE2 Hjerte;Pt",
      "definition" : "Pt—SCORE2 Hjerte (køn,alder,systolisk blodtryk,LDL-kolesterol,rygestatus); ratio=?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "SCORE2 Hjerte;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88184",
      "display" : "FEV1% - efter reversibilitet;Lunge",
      "definition" : "Lunge—FEV1 i % af forventede værdi ( ift. højde, alder og køn) - efter reversibilitet; ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FEV1% - efter reversibilitet;Lunge"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88185",
      "display" : "LDL-Kolesterol, beregn.anbef.mål;P",
      "definition" : "P(FLP mål)—LDL kolesterol beregnet anbefalet mål for kommende år; stofk. = ? mmol/L",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "LDL-Kolesterol, beregn.anbef.mål;P"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmol/L"
        }
      ]
    },
    {
      "code" : "MCS88186",
      "display" : "HbA1c, beregnet anbefalet mål;Hb(B)",
      "definition" : "Hb(B)(FLP mål)—HbA1c beregnet anbefalet mål for kommende år; stofratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "HbA1c, beregnet anbefalet mål;Hb(B)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88187",
      "display" : "BT(sys), beregnet anbefalet mål;Arm",
      "definition" : "Arm(FLP mål)—Blodtryk(systolisk) beregnet anbefalet mål for kommende år = ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "BT(sys), beregnet anbefalet mål;Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmHg"
        }
      ]
    },
    {
      "code" : "MCS88188",
      "display" : "BT(dia), beregnet anbefalet mål;Arm",
      "definition" : "Arm(FLP mål)—Blodtryk(diastolisk) beregnet anbefalet mål for kommende år = ? mmHg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "BT(dia), beregnet anbefalet mål;Arm"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "mmHg"
        }
      ]
    },
    {
      "code" : "MCS88189",
      "display" : "TTI (3mdr);Pt(AFLI)",
      "definition" : "Pt(AFLI)—Tid i Terapeutisk Index over 3 mdr. (TTI); ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "TTI (3mdr);Pt(AFLI)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88190",
      "display" : "TTI (6mdr);Pt(AFLI)",
      "definition" : "Pt(AFLI)—Tid i Terapeutisk Index over 6 mdr. (TTI); ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "TTI (6mdr);Pt(AFLI)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88191",
      "display" : "TTI (total interval);Pt(AFLI)",
      "definition" : "Pt(AFLI)—Tid i Terapeutisk Index total interval (TTI); ratio = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "TTI (total interval);Pt(AFLI)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88192",
      "display" : "Skridt per dag;Pt",
      "definition" : "Pt—Skridt; antal per dag (værdi) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Skridt per dag;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88193",
      "display" : "Skridt per uge;Pt",
      "definition" : "Pt—Skridt; antal per uge (værdi) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Skridt per uge;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88194",
      "display" : "Skridt;Pt",
      "definition" : "Pt—Skridt; antal (værdi) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Skridt;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88195",
      "display" : "PROMIS-10 Fysisk helbred;Pt",
      "definition" : "Pt—Generelt fysisk helbreds score (PROMIS-10); antal(værdi 16.2-67.7) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "PROMIS-10 Fysisk helbred;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88196",
      "display" : "PROMIS-10 Mentalt helbred;Pt",
      "definition" : "Pt—Generelt mentalt helbreds score (PROMIS-10); antal(værdi 21.2-67.6) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "PROMIS-10 Mentalt helbred;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88197",
      "display" : "SCORE2 Diabetes;Pt",
      "definition" : "Pt—SCORE2 Diabetes (køn,alder,debutår,systolisk blodtryk,total- og HDL-kolesterol,rygestatus,eGFR,HbA1c); ratio=?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "SCORE2 Diabetes;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88198",
      "display" : "BASIC SCORE (demens);Pt",
      "definition" : "Pt—BASIC (Brief Assessment of Impaired Cognition SCORE, Demens); antal(værdi 0-25) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "BASIC SCORE (demens);Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88199",
      "display" : "MDI-2 score;Pt",
      "definition" : "Pt—Major Depression Inventory 2; antal (værdi 0-10) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "MDI-2 score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88200",
      "display" : "Blodtryk",
      "definition" : "Blodtryk",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Blodtryk"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88203",
      "display" : "Audiometri",
      "definition" : "Audiometrimåling",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Audiometri"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88204",
      "display" : "Lungefunktion gruppe;Pt",
      "definition" : "Pt—Lungefunktion",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lungefunktion gruppe;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88205",
      "display" : "Lungefunktion reversibilitet gruppe",
      "definition" : "Pt—Lungefunktion reversibilitet",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lungefunktion reversibilitet gruppe"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88206",
      "display" : "Hjemmeblodtryk",
      "definition" : "Hjemmeblodtryk",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hjemmeblodtryk"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88207",
      "display" : "Ankel/Arm blodtryk",
      "definition" : "Ankel/Arm blodtryk",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ankel/Arm blodtryk"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88208",
      "display" : "Fodstatus",
      "definition" : "Fodstatus",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodstatus"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88209",
      "display" : "Følsomhed fod",
      "definition" : "Følsomhed fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følsomhed fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88210",
      "display" : "ASS-2 score;Pt",
      "definition" : "Pt—Angst scoreskema 2; antal (værdi 0-10) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "ASS-2 score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS88211",
      "display" : "AUDIT-C score;Pt",
      "definition" : "Pt—Alcohol Use Disorder Test; antal (værdi 0-12) = ?",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "AUDIT-C score;Pt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89001",
      "display" : "Risikogruppe 1/2/3/4",
      "definition" : "Risikogruppe",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Risikogruppe 1/2/3/4"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89002",
      "display" : "Udvikling i fodstatus",
      "definition" : "Fodstatus",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Udvikling i fodstatus"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89003",
      "display" : "Neuropati",
      "definition" : "Neuropati",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Neuropati"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89004",
      "display" : "Neuropati;højre fod",
      "definition" : "Neuropati;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Neuropati;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89005",
      "display" : "Neuropati;venstre fod",
      "definition" : "Neuropati;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Neuropati;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89006",
      "display" : "Iskæmi",
      "definition" : "Iskæmi",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Iskæmi"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89014",
      "display" : "Ødemer;højre fod",
      "definition" : "Ødemer;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ødemer;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89015",
      "display" : "Ødemer;venstre fod",
      "definition" : "Ødemer;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ødemer;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89016",
      "display" : "Væsentlige fejlstillinger;højre fod",
      "definition" : "Væsentlige fejlstillinger;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Væsentlige fejlstillinger;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89017",
      "display" : "Væsentlige fejlstillinger;venstre fod",
      "definition" : "Væsentlige fejlstillinger;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Væsentlige fejlstillinger;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89018",
      "display" : "Charcots fod;højre fod",
      "definition" : "Charcots fod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Charcots fod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89019",
      "display" : "Charcots fod;venstre fod",
      "definition" : "Charcots fod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Charcots fod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89020",
      "display" : "Anbefalinger fodtøj mm.",
      "definition" : "Anbefalinger fodtøj mm.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Anbefalinger fodtøj mm."
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89021",
      "display" : "Følger pt. behandlingsplan",
      "definition" : "Følger pt. behandlingsplan",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følger pt. behandlingsplan"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89022",
      "display" : "Øvrige kommentarer",
      "definition" : "Øvrige kommentarer",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øvrige kommentarer"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89023",
      "display" : "Behandlingsinterval",
      "definition" : "Behandlingsinterval",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Behandlingsinterval"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89024",
      "display" : "Anbefalet distal tåtrykmåling",
      "definition" : "Anbefalet distal tåtrykmåling",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Anbefalet distal tåtrykmåling"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89025",
      "display" : "Frarådet barfodsgang",
      "definition" : "Frarådet barfodsgang",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Frarådet barfodsgang"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89026",
      "display" : "Anbefalet tilretning af eksisterende fodtøj/hjælpemiddel",
      "definition" : "Anbefalet tilretning af fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Anbefalet tilretning af eksisterende fodtøj/hjælpemiddel"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89027",
      "display" : "Anbefalet nyt fodtøj/hjælpemiddel",
      "definition" : "Anbefalet nyt fodtøj/hjælpemiddel",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Anbefalet nyt fodtøj/hjælpemiddel"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89028",
      "display" : "Diabetestype",
      "definition" : "Diabetestype",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Diabetestype"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89029",
      "display" : "Diabetes konstateret år",
      "definition" : "Diabetes konstateret år",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Diabetes konstateret år"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89030",
      "display" : "Nedsat syn pga diabetes",
      "definition" : "Nedsat syn",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nedsat syn pga diabetes"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89031",
      "display" : "Nedsat nyrefunktion pga diabetes",
      "definition" : "Nedsat nyrefunktion",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nedsat nyrefunktion pga diabetes"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89032",
      "display" : "Amputation;højre fod",
      "definition" : "Amputation;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Amputation;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89033",
      "display" : "Amputation;venstre fod",
      "definition" : "Amputation;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Amputation;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89034",
      "display" : "Vibrationssans(biothesiometer);højre fod",
      "definition" : "Vibrationssans;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Vibrationssans(biothesiometer);højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89035",
      "display" : "Vibrationssans(biothesiometer);venstre fod",
      "definition" : "Vibrationssans;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Vibrationssans(biothesiometer);venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89036",
      "display" : "Følesans(Monofilament 10 g.);højre fod",
      "definition" : "Følesans;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følesans(Monofilament 10 g.);højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89037",
      "display" : "Følesans(Monofilament 10 g.);venstre fod",
      "definition" : "Følesans;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følesans(Monofilament 10 g.);venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89038",
      "display" : "Varmekuldesans;højre fod",
      "definition" : "Varmekuldesans;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Varmekuldesans;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89039",
      "display" : "Varmekuldesans;venstre fod",
      "definition" : "Varmekuldesans;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Varmekuldesans;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89040",
      "display" : "Stillingssans;højre fod",
      "definition" : "Stillingssans;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stillingssans;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89041",
      "display" : "Stillingssans;venstre fod",
      "definition" : "Stillingssans;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stillingssans;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89042",
      "display" : "Subjektive gener af neuropati;højre fod",
      "definition" : "Gener af neuropati;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Subjektive gener af neuropati;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89043",
      "display" : "Subjektive gener af neuropati;venstre fod",
      "definition" : "Gener af neuropati;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Subjektive gener af neuropati;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89044",
      "display" : "A. dorsalis pedis;højre fod",
      "definition" : "A. dorsalis pedis;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "A. dorsalis pedis;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89045",
      "display" : "A. dorsalis pedis;venstre fod",
      "definition" : "A. dorsalis pedis;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "A. dorsalis pedis;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89046",
      "display" : "A. tibialis posterior;højre fod",
      "definition" : "A. tibialis posterior;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "A. tibialis posterior;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89047",
      "display" : "A. tibialis posterior;venstre fod",
      "definition" : "A. tibialis posterior;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "A. tibialis posterior;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89048",
      "display" : "Normal kapilærrespons;højre fod",
      "definition" : "Normal kapilærrespons;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal kapilærrespons;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89049",
      "display" : "Normal kapilærrespons;venstre fod",
      "definition" : "Normal kapilærrespons;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal kapilærrespons;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89050",
      "display" : "Distaltryk på tåniveau(fra lægen);højre fod",
      "definition" : "Distaltryk på tåniveau;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Distaltryk på tåniveau(fra lægen);højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89051",
      "display" : "Distaltryk på tåniveau(fra lægen);venstre fod",
      "definition" : "Distaltryk på tåniveau;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Distaltryk på tåniveau(fra lægen);venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89052",
      "display" : "Subjektive gener ved nedsat blodforsyning;højre fod",
      "definition" : "Gener ved nedsat blodfor.;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Subjektive gener ved nedsat blodforsyning;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89053",
      "display" : "Subjektive gener ved nedsat blodforsyning;venstre fod",
      "definition" : "Gener ved nedsat blodfor.;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Subjektive gener ved nedsat blodforsyning;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89054",
      "display" : "Normal ledbevægelighed;højre fod",
      "definition" : "Normal ledbevægelighed;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal ledbevægelighed;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89055",
      "display" : "Normal ledbevægelighed;venstre fod",
      "definition" : "Normal ledbevægelighed;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal ledbevægelighed;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89056",
      "display" : "Normal muskelkraft;højre fod",
      "definition" : "Normal muskelkraft;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal muskelkraft;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89057",
      "display" : "Normal muskelkraft;venstre fod",
      "definition" : "Normal muskelkraft;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal muskelkraft;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89058",
      "display" : "Normal gang;højre fod",
      "definition" : "Normal gang;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal gang;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89059",
      "display" : "Normal gang;venstre fod",
      "definition" : "Normal gang;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Normal gang;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89060",
      "display" : "Smerter i bevægeapp.;højre fod",
      "definition" : "Smerter i bevægeapp.;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Smerter i bevægeapp.;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89061",
      "display" : "Smerter i bevægeapp.;venstre fod",
      "definition" : "Smerter i bevægeapp.;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Smerter i bevægeapp.;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89062",
      "display" : "Negleforandringer;højre fod",
      "definition" : "Negleforandringer;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Negleforandringer;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89063",
      "display" : "Negleforandringer;venstre fod",
      "definition" : "Negleforandringer;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Negleforandringer;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89064",
      "display" : "Nedgroede negle;højre fod",
      "definition" : "Nedgroede negle;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nedgroede negle;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89065",
      "display" : "Nedgroede negle;venstre fod",
      "definition" : "Nedgroede negle;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nedgroede negle;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89066",
      "display" : "Defekt hud;højre fod",
      "definition" : "Defekt hud;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Defekt hud;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89067",
      "display" : "Defekt hud;venstre fod",
      "definition" : "Defekt hud;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Defekt hud;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89068",
      "display" : "Tryk;højre fod",
      "definition" : "Tryk;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tryk;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89069",
      "display" : "Tryk;venstre fod",
      "definition" : "Tryk;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tryk;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89070",
      "display" : "Callositet;højre fod",
      "definition" : "Callositet;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Callositet;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89071",
      "display" : "Callositet;venstre fod",
      "definition" : "Callositet;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Callositet;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89072",
      "display" : "Fedtvævsatrofi;højre fod",
      "definition" : "Fedtvævsatrofi;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fedtvævsatrofi;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89073",
      "display" : "Fedtvævsatrofi;venstre fod",
      "definition" : "Fedtvævsatrofi;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fedtvævsatrofi;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89074",
      "display" : "Fabriksfremstillet fodtøj;højre fod",
      "definition" : "Fabriksfremstillet fodtøj;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fabriksfremstillet fodtøj;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89075",
      "display" : "Fabriksfremstillet fodtøj;venstre fod",
      "definition" : "Fabriksfremstillet fodtøj;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fabriksfremstillet fodtøj;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89076",
      "display" : "Semiortopædisk fodtøj;højre fod",
      "definition" : "Semiortopædisk fodtøj;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Semiortopædisk fodtøj;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89077",
      "display" : "Semiortopædisk fodtøj;venstre fod",
      "definition" : "Semiortopædisk fodtøj;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Semiortopædisk fodtøj;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89078",
      "display" : "Ortopædisk fodtøj;højre fod",
      "definition" : "Ortopædisk fodtøj;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ortopædisk fodtøj;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89079",
      "display" : "Ortopædisk fodtøj;venstre fod",
      "definition" : "Ortopædisk fodtøj;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ortopædisk fodtøj;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89080",
      "display" : "Fodindlæg;højre fod",
      "definition" : "Fodindlæg;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodindlæg;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89081",
      "display" : "Fodindlæg;venstre fod",
      "definition" : "Fodindlæg;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodindlæg;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89082",
      "display" : "Aflastninger;højre fod",
      "definition" : "Aflastninger;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Aflastninger;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89083",
      "display" : "Aflastninger;venstre fod",
      "definition" : "Aflastninger;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Aflastninger;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89084",
      "display" : "Kompressionsterapi;højre fod",
      "definition" : "Kompressionsterapi;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kompressionsterapi;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89085",
      "display" : "Kompressionsterapi;venstre fod",
      "definition" : "Kompressionsterapi;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kompressionsterapi;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89086",
      "display" : "Patienten er vejledt i senkomplikationer",
      "definition" : "Senkomplikationer",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Patienten er vejledt i senkomplikationer"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89087",
      "display" : "Patienten er vejledt i egenomsorg",
      "definition" : "Egenomsorg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Patienten er vejledt i egenomsorg"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89088",
      "display" : "Patienten er vejledt i fodtøj",
      "definition" : "Fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Patienten er vejledt i fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89089",
      "display" : "Overfladisk sår - Wagner 1;højre fod",
      "definition" : "Wagner 1;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Overfladisk sår - Wagner 1;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89090",
      "display" : "Overfladisk sår - Wagner 1;venstre fod",
      "definition" : "Wagner 1;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Overfladisk sår - Wagner 1;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89091",
      "display" : "Overfladisk sår med infektion - Wagner 1A;højre fod",
      "definition" : "Wagner 1A;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Overfladisk sår med infektion - Wagner 1A;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89092",
      "display" : "Overfladisk sår med infektion - Wagner 1A;venstre fod",
      "definition" : "Wagner 1A;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Overfladisk sår med infektion - Wagner 1A;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89093",
      "display" : "Dybt sår (til led, knogle eller sene) uden infektion - W. 2;h. f.",
      "definition" : "Wagner 2;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Dybt sår (til led, knogle eller sene) uden infektion - W. 2;h. f."
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89094",
      "display" : "Dybt sår (til led, knogle eller sene) uden infektion - W. 2;v. f.",
      "definition" : "Wagner 2;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Dybt sår (til led, knogle eller sene) uden infektion - W. 2;v. f."
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89095",
      "display" : "Dybt sår med infektion - Wagner 3;højre fod",
      "definition" : "Wagner 3;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Dybt sår med infektion - Wagner 3;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89096",
      "display" : "Dybt sår med infektion - Wagner 3;venstre fod",
      "definition" : "Wagner 3;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Dybt sår med infektion - Wagner 3;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89097",
      "display" : "Nekrose, lokalt - Wagner 4;højre fod",
      "definition" : "Wagner 4;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nekrose, lokalt - Wagner 4;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89098",
      "display" : "Nekrose, lokalt - Wagner 4;venstre fod",
      "definition" : "Wagner 4;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nekrose, lokalt - Wagner 4;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89099",
      "display" : "Nekrose, hele foden - Wagner 5;højre fod",
      "definition" : "Wagner 5;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nekrose, hele foden - Wagner 5;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89100",
      "display" : "Nekrose, hele foden - Wagner 5;venstre fod",
      "definition" : "Wagner 5;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Nekrose, hele foden - Wagner 5;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89101",
      "display" : "Hallux;højre fod",
      "definition" : "Hallux;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89102",
      "display" : "Hallux;venstre fod",
      "definition" : "Hallux;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89103",
      "display" : "Øvrige digiti;højre fod",
      "definition" : "Øvrige digiti;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øvrige digiti;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89104",
      "display" : "Øvrige digiti;venstre fod",
      "definition" : "Øvrige digiti;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øvrige digiti;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89105",
      "display" : "Forfod;højre fod",
      "definition" : "Forfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89106",
      "display" : "Forfod;venstre fod",
      "definition" : "Forfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89107",
      "display" : "Bagfod;højre fod",
      "definition" : "Bagfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Bagfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89108",
      "display" : "Bagfod;venstre fod",
      "definition" : "Bagfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Bagfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89109",
      "display" : "Hallux;højre fod",
      "definition" : "Hallux;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89110",
      "display" : "Hallux;venstre fod",
      "definition" : "Hallux;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89111",
      "display" : "Øvrige digiti;højre fod",
      "definition" : "Øvrige digiti;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øvrige digiti;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89112",
      "display" : "Øvrige digiti;venstre fod",
      "definition" : "Øvrige digiti;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øvrige digiti;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89113",
      "display" : "Forfod;højre fod",
      "definition" : "Forfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89114",
      "display" : "Forfod;venstre fod",
      "definition" : "Forfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89115",
      "display" : "Crus;højre fod",
      "definition" : "Crus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Crus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89116",
      "display" : "Crus;venstre fod",
      "definition" : "Crus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Crus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89117",
      "display" : "Femur;højre fod",
      "definition" : "Femur;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Femur;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89118",
      "display" : "Femur;venstre fod",
      "definition" : "Femur;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Femur;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89119",
      "display" : "Mobil pes planus transversus;højre fod",
      "definition" : "Mobil pes planus transvers.;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobil pes planus transversus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89120",
      "display" : "Mobil pes planus transversus;venstre fod",
      "definition" : "Mobil pes planus transvers.;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobil pes planus transversus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89121",
      "display" : "Rigid pes planus transversus;højre fod",
      "definition" : "Rigid pes planus transvers.;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid pes planus transversus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89122",
      "display" : "Rigid pes planus transversus;venstre fod",
      "definition" : "Rigid pes planus transvers.;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid pes planus transversus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89123",
      "display" : "Mobil applanation af mediale længdebue;højre fod",
      "definition" : "M. app. af mediale længdeb.;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobil applanation af mediale længdebue;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89124",
      "display" : "Mobil applanation af mediale længdebue;venstre fod",
      "definition" : "M. app. af mediale længdeb.;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobil applanation af mediale længdebue;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89125",
      "display" : "Rigid applanation af mediale længdebue;højre fod",
      "definition" : "R. app. af mediale længdeb.;hø.fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid applanation af mediale længdebue;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89126",
      "display" : "Rigid applanation af mediale længdebue;venstre fod",
      "definition" : "R. app. af mediale længdeb.;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid applanation af mediale længdebue;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89127",
      "display" : "Pes cavus;højre fod",
      "definition" : "Pes cavus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Pes cavus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89128",
      "display" : "Pes cavus;venstre fod",
      "definition" : "Pes cavus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Pes cavus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89129",
      "display" : "Rigid pes cavus;højre fod",
      "definition" : "Rigid pes cavus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid pes cavus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89130",
      "display" : "Rigid pes cavus;venstre fod",
      "definition" : "Rigid pes cavus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid pes cavus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89131",
      "display" : "Mobil digitus malleus;højre fod",
      "definition" : "Mobil digitus malleus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobil digitus malleus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89132",
      "display" : "Mobil digitus malleus;venstre fod",
      "definition" : "Mobil digitus malleus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mobil digitus malleus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89133",
      "display" : "Rigid digitus malleus;højre fod",
      "definition" : "Rigid digitus malleus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid digitus malleus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89134",
      "display" : "Rigid digitus malleus;venstre fod",
      "definition" : "Rigid digitus malleus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Rigid digitus malleus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89135",
      "display" : "Hallux rigidus;højre fod",
      "definition" : "Hallux rigidus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux rigidus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89136",
      "display" : "Hallux rigidus;venstre fod",
      "definition" : "Hallux rigidus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux rigidus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89137",
      "display" : "Hallux valgus;højre fod",
      "definition" : "Hallux valgus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux valgus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89138",
      "display" : "Hallux valgus;venstre fod",
      "definition" : "Hallux valgus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux valgus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89139",
      "display" : "Varus af bagfod;højre fod",
      "definition" : "Varus af bagfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Varus af bagfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89140",
      "display" : "Varus af bagfod;venstre fod",
      "definition" : "Varus af bagfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Varus af bagfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89141",
      "display" : "Valgus af bagfod;højre fod",
      "definition" : "Valgus af bagfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Valgus af bagfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89142",
      "display" : "Valgus af bagfod;venstre fod",
      "definition" : "Valgus af bagfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Valgus af bagfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89143",
      "display" : "Varus af forfod;højre fod",
      "definition" : "Varus af forfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Varus af forfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89144",
      "display" : "Varus af forfod;venstre fod",
      "definition" : "Varus af forfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Varus af forfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89145",
      "display" : "Valgus af forfod;højre fod",
      "definition" : "Valgus af forfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Valgus af forfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89146",
      "display" : "Valgus af forfod;venstre fod",
      "definition" : "Valgus af forfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Valgus af forfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89147",
      "display" : "Metatarsus varus primus;højre fod",
      "definition" : "Metatarsus varus primus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Metatarsus varus primus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89148",
      "display" : "Metatarsus varus primus;venstre fod",
      "definition" : "Metatarsus varus primus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Metatarsus varus primus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89149",
      "display" : "Demens",
      "definition" : "Demens",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Demens"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89150",
      "display" : "Gigt",
      "definition" : "Gigt",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Gigt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89151",
      "display" : "Parkinson",
      "definition" : "Parkinson",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Parkinson"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89152",
      "display" : "Syn",
      "definition" : "Syn",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Syn"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89153",
      "display" : "Sclerose",
      "definition" : "Sclerose",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Sclerose"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89154",
      "display" : "Andre komplicerede sygdomme",
      "definition" : "Andre komplicerede sygdomme",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Andre komplicerede sygdomme"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89155",
      "display" : "Øvrige årsager",
      "definition" : "Øvrige årsager",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øvrige årsager"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89156",
      "display" : "FF fodtøj",
      "definition" : "FF fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FF fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89157",
      "display" : "Semiortopædisk fodtøj",
      "definition" : "Semiortopædisk fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Semiortopædisk fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89158",
      "display" : "Håndsyet fodtøj",
      "definition" : "Håndsyet fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Håndsyet fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89159",
      "display" : "Fodindlæg",
      "definition" : "Fodindlæg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodindlæg"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89160",
      "display" : "Aflastning",
      "definition" : "Aflastning",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Aflastning"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89161",
      "display" : "Kompression",
      "definition" : "Kompression",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kompression"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89162",
      "display" : "FF fodtøj",
      "definition" : "FF fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "FF fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89163",
      "display" : "Semiortopædisk fodtøj",
      "definition" : "Semiortopædisk fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Semiortopædisk fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89164",
      "display" : "Håndsyet fodtøj",
      "definition" : "Håndsyet fodtøj",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Håndsyet fodtøj"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89165",
      "display" : "Fodindlæg",
      "definition" : "Fodindlæg",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fodindlæg"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89166",
      "display" : "Aflastning",
      "definition" : "Aflastning",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Aflastning"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89167",
      "display" : "Kompression",
      "definition" : "Kompression",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kompression"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89168",
      "display" : "Prikken og stikken;højre fod",
      "definition" : "Prikken og stikken;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Prikken og stikken;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89169",
      "display" : "Prikken og stikken;venstre fod",
      "definition" : "Prikken og stikken;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Prikken og stikken;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89170",
      "display" : "Stramme strømper;højre fod",
      "definition" : "Stramme strømper;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stramme strømper;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89171",
      "display" : "Stramme strømper;venstre fod",
      "definition" : "Stramme strømper;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Stramme strømper;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89172",
      "display" : "Vat;højre fod",
      "definition" : "Vat;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Vat;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89173",
      "display" : "Vat;venstre fod",
      "definition" : "Vat;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Vat;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89174",
      "display" : "Glasskår;højre fod",
      "definition" : "Glasskår;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Glasskår;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89175",
      "display" : "Glasskår;venstre fod",
      "definition" : "Glasskår;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Glasskår;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89176",
      "display" : "Brændende;højre fod",
      "definition" : "Brændende;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Brændende;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89177",
      "display" : "Brændende;venstre fod",
      "definition" : "Brændende;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Brændende;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89178",
      "display" : "Jagende;højre fod",
      "definition" : "Jagende;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Jagende;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89179",
      "display" : "Jagende;venstre fod",
      "definition" : "Jagende;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Jagende;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89180",
      "display" : "Usikker på sin balance;højre fod",
      "definition" : "Usikker på sin balance;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Usikker på sin balance;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89181",
      "display" : "Usikker på sin balance;venstre fod",
      "definition" : "Usikker på sin balance;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Usikker på sin balance;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89182",
      "display" : "Ubehag når dynen ligger på foden;højre fod",
      "definition" : "Ubehag n. dynen lig. på f.;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ubehag når dynen ligger på foden;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89183",
      "display" : "Ubehag når dynen ligger på foden;venstre fod",
      "definition" : "Ubehag n. dynen lig. på f.;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ubehag når dynen ligger på foden;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89184",
      "display" : "Ingen følelser i fødderne;højre fod",
      "definition" : "Ingen følelser i fødderne;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ingen følelser i fødderne;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89185",
      "display" : "Ingen følelser i fødderne;venstre fod",
      "definition" : "Ingen følelser i fødderne;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ingen følelser i fødderne;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89186",
      "display" : "Hyperæstesi (smerter ved berøring);højre fod",
      "definition" : "Hyperæstesi;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hyperæstesi (smerter ved berøring);højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89187",
      "display" : "Hyperæstesi (smerter ved berøring);venstre fod",
      "definition" : "Hyperæstesi;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hyperæstesi (smerter ved berøring);venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89188",
      "display" : "Smerter ved gang;højre fod",
      "definition" : "Smerter ved gang;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Smerter ved gang;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89189",
      "display" : "Smerter ved gang;venstre fod",
      "definition" : "Smerter ved gang;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Smerter ved gang;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89190",
      "display" : "Smerte ved hvile;højre fod",
      "definition" : "Smerte ved hvile;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Smerte ved hvile;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89191",
      "display" : "Smerte ved hvile;venstre fod",
      "definition" : "Smerte ved hvile;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Smerte ved hvile;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89192",
      "display" : "Hvide tæer;højre fod",
      "definition" : "Hvide tæer;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hvide tæer;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89193",
      "display" : "Hvide tæer;venstre fod",
      "definition" : "Hvide tæer;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hvide tæer;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89194",
      "display" : "Lindring ved benet nedad;højre fod",
      "definition" : "Lindring ved benet nedad;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lindring ved benet nedad;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89195",
      "display" : "Lindring ved benet nedad;venstre fod",
      "definition" : "Lindring ved benet nedad;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lindring ved benet nedad;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89196",
      "display" : "Bagfod;højre fod",
      "definition" : "Bagfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Bagfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89197",
      "display" : "Bagfod;venstre fod",
      "definition" : "Bagfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Bagfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89198",
      "display" : "Talocruralled;højre fod",
      "definition" : "Talocruralled;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Talocruralled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89199",
      "display" : "Talocruralled;venstre fod",
      "definition" : "Talocruralled;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Talocruralled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89200",
      "display" : "Subtalarled;højre fod",
      "definition" : "Subtalarled;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Subtalarled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89201",
      "display" : "Subtalarled;venstre fod",
      "definition" : "Subtalarled;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Subtalarled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89202",
      "display" : "Mellemfod;højre fod",
      "definition" : "Mellemfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mellemfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89203",
      "display" : "Mellemfod;venstre fod",
      "definition" : "Mellemfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Mellemfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89204",
      "display" : "Midttarsalled;højre fod",
      "definition" : "Midttarsalled;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Midttarsalled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89205",
      "display" : "Midttarsalled;venstre fod",
      "definition" : "Midttarsalled;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Midttarsalled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89206",
      "display" : "1. Metatarsalled;højre fod",
      "definition" : "1. Metatarsalled;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "1. Metatarsalled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89207",
      "display" : "1. Metatarsalled;venstre fod",
      "definition" : "1. Metatarsalled;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "1. Metatarsalled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89208",
      "display" : "Forfod;højre fod",
      "definition" : "Forfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89209",
      "display" : "Forfod;venstre fod",
      "definition" : "Forfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89210",
      "display" : "Hallux metatarso phalangealled;højre fod",
      "definition" : "Hallux met. pha.;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux metatarso phalangealled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89211",
      "display" : "Hallux metatarso phalangealled;venstre fod",
      "definition" : "Hallux met. Pha.;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux metatarso phalangealled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89212",
      "display" : "Hallux interphalangealled;højre fod",
      "definition" : "Hallux interphalangealled;hø. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux interphalangealled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89213",
      "display" : "Hallux interphalangealled;venstre fod",
      "definition" : "Hallux interphalangealled;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hallux interphalangealled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89214",
      "display" : "Digiti metatarso phalangealled;højre fod",
      "definition" : "Digiti met. pha.;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Digiti metatarso phalangealled;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89215",
      "display" : "Digiti metatarso phalangealled;venstre fod",
      "definition" : "Digiti met. pha.;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Digiti metatarso phalangealled;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89216",
      "display" : "2. digitus;højre fod",
      "definition" : "2&#46; digitus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "2. digitus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89217",
      "display" : "2. digitus;venstre fod",
      "definition" : "2&#46; digitus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "2. digitus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89218",
      "display" : "3. digitus;højre fod",
      "definition" : "3&#46; digitus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "3. digitus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89219",
      "display" : "3. digitus;venstre fod",
      "definition" : "3&#46; digitus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "3. digitus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89220",
      "display" : "4. digitus;højre fod",
      "definition" : "4&#46; digitus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "4. digitus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89221",
      "display" : "4. digitus;venstre fod",
      "definition" : "4&#46; digitus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "4. digitus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89222",
      "display" : "5. digitus;højre fod",
      "definition" : "5&#46; digitus;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "5. digitus;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89223",
      "display" : "5. digitus;venstre fod",
      "definition" : "5&#46; digitus;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "5. digitus;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89224",
      "display" : "Kan 2. digitus strækkes;højre fod",
      "definition" : "Kan 2. digitus strækkes;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 2. digitus strækkes;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89225",
      "display" : "Kan 2. digitus strækkes;venstre fod",
      "definition" : "Kan 2. digitus strækkes;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 2. digitus strækkes;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89226",
      "display" : "Kan 3. digitus strækkes;højre fod",
      "definition" : "Kan 3. digitus strækkes;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 3. digitus strækkes;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89227",
      "display" : "Kan 3. digitus strækkes;venstre fod",
      "definition" : "Kan 3. digitus strækkes;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 3. digitus strækkes;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89228",
      "display" : "Kan 4. digitus strækkes;højre fod",
      "definition" : "Kan 4. digitus strækkes;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 4. digitus strækkes;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89229",
      "display" : "Kan 4. digitus strækkes;venstre fod",
      "definition" : "Kan 4. digitus strækkes;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 4. digitus strækkes;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89230",
      "display" : "Kan 5. digitus strækkes;højre fod",
      "definition" : "Kan 5. digitus strækkes;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 5. digitus strækkes;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89231",
      "display" : "Kan 5. digitus strækkes;venstre fod",
      "definition" : "Kan 5. digitus strækkes;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Kan 5. digitus strækkes;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89232",
      "display" : "Forfod;højre fod",
      "definition" : "Forfod;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89233",
      "display" : "Forfod;venstre fod",
      "definition" : "Forfod;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Forfod;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89234",
      "display" : "Ankel;højre side",
      "definition" : "Ankel;højre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ankel;højre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89235",
      "display" : "Ankel;venstre side",
      "definition" : "Ankel;venstre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Ankel;venstre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89236",
      "display" : "Knæ;højre side",
      "definition" : "Knæ;højre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Knæ;højre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89237",
      "display" : "Knæ;venstre side",
      "definition" : "Knæ;venstre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Knæ;venstre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89238",
      "display" : "Hofte;højre side",
      "definition" : "Hofte;højre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hofte;højre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89239",
      "display" : "Hofte;venstre side",
      "definition" : "Hofte;venstre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Hofte;venstre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89240",
      "display" : "Lænd;højre side",
      "definition" : "Lænd;højre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lænd;højre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89241",
      "display" : "Lænd;venstre side",
      "definition" : "Lænd;venstre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Lænd;venstre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89242",
      "display" : "Fortykket negl;højre fod",
      "definition" : "Fortykket negl;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fortykket negl;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89243",
      "display" : "Fortykket negl;venstre fod",
      "definition" : "Fortykket negl;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fortykket negl;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89244",
      "display" : "Svampet negl;højre fod",
      "definition" : "Svampet negl;højre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Svampet negl;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89245",
      "display" : "Svampet negl;venstre fod",
      "definition" : "Svampet negl;venstre fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Svampet negl;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89246",
      "display" : "Følge af fejlstillinger - Wagner 0;højre fod",
      "definition" : "Følge af fejlstilling, W.0;hø. Fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følge af fejlstillinger - Wagner 0;højre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89247",
      "display" : "Følge af fejlstillinger - Wagner 0;venstre fod",
      "definition" : "Følge af fejlstilling, W.0;ve. fod",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følge af fejlstillinger - Wagner 0;venstre fod"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89248",
      "display" : "Følge af andet;højre side",
      "definition" : "Følge af andet;højre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følge af andet;højre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89249",
      "display" : "Følge af andet;venstre side",
      "definition" : "Følge af andet;venstre side",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Følge af andet;venstre side"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89250",
      "display" : "Risikogruppe 1/2/3/4 pr. dato",
      "definition" : "Risikogruppe pr. dato",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Risikogruppe 1/2/3/4 pr. dato"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89251",
      "display" : "Amputation pga diabetes",
      "definition" : "Amputation pga diabetes",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Amputation pga diabetes"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS89252",
      "display" : "Amputation pga andet (eks. traume)",
      "definition" : "Amputation pga andet",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Amputation pga andet (eks. traume)"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90001",
      "display" : "Øjenscreenings-indikation",
      "definition" : "Øjenscreenings-indikation (0-5)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Øjenscreenings-indikation"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90002",
      "display" : "Tidligere kataraktop.;højre øje",
      "definition" : "Tidligere kataraktoperation;højre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidligere kataraktop.;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90003",
      "display" : "Tidligere kataraktop.; venstre øje",
      "definition" : "Tidligere kataraktoperation; venstre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidligere kataraktop.; venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90004",
      "display" : "Tidl vitreoretinal kirg;højre øje",
      "definition" : "Tidligere vitreoretinal kirurgi for diabeteskomplikation;højre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidl vitreoretinal kirg;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90005",
      "display" : "Tidl vitreoretinal kirg;venstre øje",
      "definition" : "Tidligere vitreoretinal kirurgi for diabeteskomplikation;venstre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidl vitreoretinal kirg;venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90006",
      "display" : "Synsstyrke;højre øje",
      "definition" : "Synsstyrke;højre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Synsstyrke;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90007",
      "display" : "Synsstyrke;venstre øje",
      "definition" : "Synsstyrke;venstre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Synsstyrke;venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90008",
      "display" : "Fundusfoto",
      "definition" : "Fundusfoto",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Fundusfoto"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90009",
      "display" : "Funduskopi",
      "definition" : "Funduskopi",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Funduskopi"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90010",
      "display" : "Retinastatus;højre øje",
      "definition" : "Retinastatus;højre øje ((0-7)(51-55))",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Retinastatus;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90011",
      "display" : "Retinastatus;venstre øje",
      "definition" : "Retinastatus;venstre øje ((0-7)(51-55))",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Retinastatus;venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90012",
      "display" : "Maculopati-status;højre øje",
      "definition" : "Maculopati-status;højre øje (0-7)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Maculopati-status;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90013",
      "display" : "Maculopati-status;venstre øje",
      "definition" : "Maculopati-status;venstre øje (0-7)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Maculopati-status;venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90014",
      "display" : "Indikation f næste øjenlægekontakt",
      "definition" : "Indikation for næste øjenlægekontakt (0-6)",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Indikation f næste øjenlægekontakt"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90015",
      "display" : "Tidspunkt for næste Screening",
      "definition" : "Tidspunkt for næste Screening",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Tidspunkt for næste Screening"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90016",
      "display" : "Slørede medier-Katarakt;højre øje",
      "definition" : "Slørede medier-Katarakt;højre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Slørede medier-Katarakt;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90017",
      "display" : "Slørede medier-Katarakt;venstre øje",
      "definition" : "Slørede medier-Katarakt;venstre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Slørede medier-Katarakt;venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90018",
      "display" : "Slør med.-Glaslegemebl;højre øje",
      "definition" : "Slørede medier-Glaslegemeblødning;højre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Slør med.-Glaslegemebl;højre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90019",
      "display" : "Slør med.-Glaslegemebl;venstre øje",
      "definition" : "Slørede medier-Glaslegemeblødning;venstre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Slør med.-Glaslegemebl;venstre øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90020",
      "display" : "Slør med.-An/ukendt årsag;hø øje",
      "definition" : "Slørede medier-Anden / ukendt årsag;højre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Slør med.-An/ukendt årsag;hø øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS90021",
      "display" : "Slør med.-An/ukendt årsag;ven øje",
      "definition" : "Slørede medier-Anden / ukendt årsag;venstre øje",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Slør med.-An/ukendt årsag;ven øje"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    },
    {
      "code" : "MCS91001",
      "display" : "Wetsmear",
      "definition" : "Wetsmear",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
            "code" : "phmr-short-name"
          },
          "value" : "Wetsmear"
        }
      ],
      "property" : [
        {
          "code" : "phmr-unit",
          "valueString" : "BLANK"
        }
      ]
    }
  ]
}

```
