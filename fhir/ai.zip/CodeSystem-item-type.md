# Questionnaire Item Type - eHealth Infrastructure v10.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Questionnaire Item Type**

## CodeSystem: Questionnaire Item Type 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/item-type | *Version*:10.0.0 | |
| Active as of 2019-10-24 | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 3 | *Computable Name*:Questionnaire Item Type |

 
Distinguishes groups from questions and display text and indicates data type for questions 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem Supplement is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "item-type",
  "meta" : {
    "lastUpdated" : "2019-10-24T11:53:00+11:00"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-ballot-status",
    "valueString" : "Informative"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 3
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "fhir"
  }],
  "url" : "http://hl7.org/fhir/item-type",
  "version" : "10.0.0",
  "name" : "Questionnaire Item Type",
  "title" : "Questionnaire Item Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-10-24T11:53:00+11:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Distinguishes groups from questions and display text and indicates data type for questions",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "supplement",
  "supplements" : "http://hl7.org/fhir/ValueSet/item-type",
  "property" : [{
    "code" : "notSelectable",
    "uri" : "http://hl7.org/fhir/concept-properties#notSelectable",
    "description" : "Indicates that the code is abstract - only intended to be used as a selector for other concepts",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "group",
    "display" : "Group",
    "definition" : "An item with no direct answer but should have at least one child item.",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gruppe"
    }]
  },
  {
    "code" : "display",
    "display" : "Display",
    "definition" : "Text for display that will not capture an answer or have child items.",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Visning"
    }]
  },
  {
    "code" : "question",
    "display" : "Question",
    "definition" : "An item that defines a specific answer to be captured, and may have child items. (the answer provided in the QuestionnaireResponse should be of the defined datatype)",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Spørgsmål"
    }],
    "property" : [{
      "code" : "notSelectable",
      "valueBoolean" : true
    }],
    "concept" : [{
      "code" : "boolean",
      "display" : "Boolean",
      "definition" : "Question with a yes/no answer (valueBoolean)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Boolsk"
      }]
    },
    {
      "code" : "decimal",
      "display" : "Decimal",
      "definition" : "Question with is a real number answer (valueDecimal)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Decimal"
      }]
    },
    {
      "code" : "integer",
      "display" : "Integer",
      "definition" : "Question with an integer answer (valueInteger)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Heltal"
      }]
    },
    {
      "code" : "date",
      "display" : "Date",
      "definition" : "Question with a date answer (valueDate)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Dato"
      }]
    },
    {
      "code" : "dateTime",
      "display" : "Date Time",
      "definition" : "Question with a date and time answer (valueDateTime)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Dato & tidspunkt"
      }]
    },
    {
      "code" : "time",
      "display" : "Time",
      "definition" : "Question with a time (hour:minute:second) answer independent of date. (valueTime)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Tidspunkt"
      }]
    },
    {
      "code" : "string",
      "display" : "String",
      "definition" : "Question with a short (few words to short sentence) free-text entry answer (valueString)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Tekststreng"
      }]
    },
    {
      "code" : "text",
      "display" : "Text",
      "definition" : "Question with a long (potentially multi-paragraph) free-text entry answer (valueString)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Fritekst"
      }]
    },
    {
      "code" : "url",
      "display" : "Url",
      "definition" : "Question with a URL (website, FTP site, etc.) answer (valueUri)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "URL"
      }]
    },
    {
      "code" : "choice",
      "display" : "Choice",
      "definition" : "Question with a Coding drawn from a list of options (specified in either the option property, or via the valueset referenced in the options property) as an answer (valueCoding)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Valg"
      }]
    },
    {
      "code" : "open-choice",
      "display" : "Open Choice",
      "definition" : "Answer is a Coding drawn from a list of options (as with the choice type) or a free-text entry in a string (valueCoding or valueString)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Åbent valg"
      }]
    },
    {
      "code" : "attachment",
      "display" : "Attachment",
      "definition" : "Question with binary content such as a image, PDF, etc. as an answer (valueAttachment)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Vedhæftet fil"
      }]
    },
    {
      "code" : "reference",
      "display" : "Reference",
      "definition" : "Question with a reference to another resource (practitioner, organization, etc.) as an answer (valueReference)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Reference"
      }]
    },
    {
      "code" : "quantity",
      "display" : "Quantity",
      "definition" : "Question with a combination of a numeric value and unit, potentially with a comparator (<, >, etc.) as an answer. (valueQuantity) There is an extension 'http://hl7.org/fhir/StructureDefinition/questionnaire-unit' that can be used to define what unit whould be captured (or the a unit that has a ucum conversion from the provided unit)",
      "designation" : [{
        "language" : "da",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009"
        },
        "value" : "Antal"
      }]
    }]
  }]
}

```
