# PlanDefinition Recommendation - eHealth Infrastructure v11.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PlanDefinition Recommendation**

## ValueSet: PlanDefinition Recommendation (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/vs/plandefinition-recommendation | *Version*:11.0.3 |
| Active as of 2019-02-08 | *Computable Name*:PlanDefinitionRecommendation |

 
Value set of plan definition recommendation codes. 

 **References** 

* [recommendation](StructureDefinition-ehealth-recommendation.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ehealth-plandefinition-recommendation",
  "url" : "http://ehealth.sundhed.dk/vs/plandefinition-recommendation",
  "version" : "11.0.3",
  "name" : "PlanDefinitionRecommendation",
  "title" : "PlanDefinition Recommendation",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-08T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Value set of plan definition recommendation codes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://ehealth.sundhed.dk/cs/plandefinition-recommendation"
    }]
  }
}

```
