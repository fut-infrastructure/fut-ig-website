# View For Type - eHealth Infrastructure v10.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **View For Type**

## ValueSet: View For Type (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/vs/view-for-type | *Version*:10.0.0 |
| Active as of 2021-10-20 | *Computable Name*:ViewType |

 
View for types 

 **References** 

* [View for](StructureDefinition-ehealth-view-for.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ehealth-view-for-type",
  "url" : "http://ehealth.sundhed.dk/vs/view-for-type",
  "version" : "10.0.0",
  "name" : "ViewType",
  "title" : "View For Type",
  "status" : "active",
  "experimental" : true,
  "date" : "2021-10-20T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "View for types",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/resource-types",
      "version" : "4.0.1",
      "concept" : [{
        "code" : "Questionnaire",
        "display" : "Questionnaire",
        "designation" : [{
          "language" : "da",
          "value" : "Spørgeskema"
        }]
      }]
    }]
  }
}

```
