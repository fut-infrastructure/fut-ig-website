# SorOrganizationType - eHealth Infrastructure v11.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SorOrganizationType**

## ValueSet: SorOrganizationType (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/vs/sor-organization-type | *Version*:11.0.4 |
| Active as of 2019-05-27 | *Computable Name*:SorOrganizationType |

 
Value set used for indicating the organization type for organizations from Sor 

 **References** 

* Included into [Organization Type](ValueSet-ehealth-organization-type.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ehealth-sor-organization-type",
  "url" : "http://ehealth.sundhed.dk/vs/sor-organization-type",
  "version" : "11.0.4",
  "name" : "SorOrganizationType",
  "title" : "SorOrganizationType",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-05-27T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Value set used for indicating the organization type for organizations from Sor",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://ehealth.sundhed.dk/cs/sor-organization-type"
    },
    {
      "system" : "http://snomed.info/sct/554471000005108/version/20150731",
      "concept" : [{
        "code" : "554221000005108"
      },
      {
        "code" : "546821000005103"
      },
      {
        "code" : "547011000005103"
      },
      {
        "code" : "546811000005109"
      },
      {
        "code" : "550621000005101"
      },
      {
        "code" : "550631000005103"
      },
      {
        "code" : "550641000005106"
      },
      {
        "code" : "550651000005108"
      },
      {
        "code" : "550661000005105"
      },
      {
        "code" : "554211000005102"
      },
      {
        "code" : "550711000005101"
      },
      {
        "code" : "550671000005100"
      },
      {
        "code" : "554061000005105"
      },
      {
        "code" : "554041000005106"
      },
      {
        "code" : "554021000005101"
      },
      {
        "code" : "550681000005102"
      },
      {
        "code" : "550691000005104"
      },
      {
        "code" : "550701000005104"
      },
      {
        "code" : "554231000005106"
      },
      {
        "code" : "554051000005108"
      },
      {
        "code" : "550811000005108"
      },
      {
        "code" : "547211000005108"
      },
      {
        "code" : "550891000005100"
      },
      {
        "code" : "550881000005103"
      },
      {
        "code" : "550411000005105"
      },
      {
        "code" : "554851000005102"
      },
      {
        "code" : "550861000005106"
      },
      {
        "code" : "554881000005108"
      },
      {
        "code" : "554861000005100"
      },
      {
        "code" : "554821000005109"
      },
      {
        "code" : "554411000005101"
      },
      {
        "code" : "554871000005105"
      },
      {
        "code" : "550821000005102"
      },
      {
        "code" : "550871000005101"
      },
      {
        "code" : "554241000005103"
      },
      {
        "code" : "550841000005107"
      },
      {
        "code" : "550851000005109"
      },
      {
        "code" : "551611000005102"
      },
      {
        "code" : "554071000005100"
      },
      {
        "code" : "550831000005104"
      },
      {
        "code" : "554031000005103"
      }]
    },
    {
      "system" : "http://snomed.info/sct/554471000005108/version/20180331",
      "concept" : [{
        "code" : "557511000005107"
      },
      {
        "code" : "557501000005109"
      },
      {
        "code" : "557531000005103"
      },
      {
        "code" : "557591000005104"
      },
      {
        "code" : "557521000005101"
      },
      {
        "code" : "557561000005105"
      },
      {
        "code" : "557541000005106"
      },
      {
        "code" : "557581000005102"
      },
      {
        "code" : "556841000005105"
      }]
    },
    {
      "system" : "http://snomed.info/sct/554471000005108/version/20180930",
      "concept" : [{
        "code" : "557671000005101"
      }]
    },
    {
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "702916001"
      },
      {
        "code" : "284546000"
      },
      {
        "code" : "272511002"
      },
      {
        "code" : "557891000005101"
      },
      {
        "code" : "557901000005102"
      },
      {
        "code" : "398070004"
      },
      {
        "code" : "394761003"
      },
      {
        "code" : "20078004"
      },
      {
        "code" : "722173008"
      },
      {
        "code" : "702871004"
      },
      {
        "code" : "276037005"
      },
      {
        "code" : "22232009"
      },
      {
        "code" : "702824005"
      },
      {
        "code" : "42665001"
      },
      {
        "code" : "264361005"
      },
      {
        "code" : "703069008"
      },
      {
        "code" : "309964003"
      },
      {
        "code" : "309904001"
      },
      {
        "code" : "309939001"
      },
      {
        "code" : "225728007"
      },
      {
        "code" : "255203001"
      },
      {
        "code" : "264372000"
      }]
    }]
  }
}

```
