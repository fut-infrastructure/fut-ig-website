# PlanDefinition Recommendation - eHealth Infrastructure v11.0.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PlanDefinition Recommendation**

## CodeSystem: PlanDefinition Recommendation 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/plandefinition-recommendation | *Version*:11.0.5 |
| Active as of 2019-01-29 | *Computable Name*:PlanDefinitionRecommendation |

 
Plan Definition Recommendation 

This Code system is referenced in the definition of the following value sets:

* [PlanDefinition Recommendation](ValueSet-ehealth-plandefinition-recommendation.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-plandefinition-recommendation",
  "url" : "http://ehealth.sundhed.dk/cs/plandefinition-recommendation",
  "version" : "11.0.5",
  "name" : "PlanDefinitionRecommendation",
  "title" : "PlanDefinition Recommendation",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-01-29T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Plan Definition Recommendation",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [{
    "code" : "deprecated",
    "uri" : "http://hl7.org/fhir/concept-properties#deprecated",
    "description" : "Indicates that the concept is deprecated and should not be used",
    "type" : "dateTime"
  }],
  "concept" : [{
    "code" : "TBD",
    "display" : "Example value - Under construction",
    "definition" : "Example value - Under construction",
    "property" : [{
      "code" : "deprecated",
      "valueDateTime" : "2020-03-24"
    }]
  },
  {
    "code" : "Mandatory",
    "display" : "Mandatory",
    "definition" : "Mandatory",
    "designation" : [{
      "language" : "en-US",
      "value" : "Mandatory"
    },
    {
      "language" : "da",
      "value" : "Obligatorisk"
    }]
  },
  {
    "code" : "Recommended",
    "display" : "Recommended",
    "definition" : "Recommended",
    "designation" : [{
      "language" : "en-US",
      "value" : "Recommended"
    },
    {
      "language" : "da",
      "value" : "Anbefalet"
    }]
  },
  {
    "code" : "Confirmed",
    "display" : "Confirmed",
    "definition" : "Confirmed",
    "designation" : [{
      "language" : "en-US",
      "value" : "Confirmed"
    },
    {
      "language" : "da",
      "value" : "Bekræftet"
    }]
  },
  {
    "code" : "NotRecommended",
    "display" : "NotRecommended",
    "definition" : "NotRecommended",
    "designation" : [{
      "language" : "en-US",
      "value" : "Not recommended"
    },
    {
      "language" : "da",
      "value" : "Frarådes"
    }]
  },
  {
    "code" : "Applicable",
    "display" : "Applicable",
    "definition" : "Applicable",
    "designation" : [{
      "language" : "en-US",
      "value" : "Applicable"
    },
    {
      "language" : "da",
      "value" : "Anvendelig"
    }]
  },
  {
    "code" : "PhasedOut",
    "display" : "PhasedOut",
    "definition" : "PhasedOut",
    "designation" : [{
      "language" : "en-US",
      "value" : "PhasedOut"
    },
    {
      "language" : "da",
      "value" : "Udfaset"
    }]
  },
  {
    "code" : "Observed",
    "display" : "Observed",
    "definition" : "Observed",
    "designation" : [{
      "language" : "en-US",
      "value" : "Observed"
    },
    {
      "language" : "da",
      "value" : "Observeres"
    }]
  },
  {
    "code" : "Planned",
    "display" : "Planned",
    "definition" : "Planned",
    "designation" : [{
      "language" : "en-US",
      "value" : "Planned"
    },
    {
      "language" : "da",
      "value" : "Planlagt"
    }]
  }]
}

```
