# FS III, Egenomsorg - eHealth Infrastructure v11.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FS III, Egenomsorg**

## CodeSystem: FS III, Egenomsorg (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/fs3-group-selfcare | *Version*:11.0.4 |
| Active as of 2019-02-02 | *Computable Name*:FS III, Egenomsorg |

 
FS III, Egenomsorg 

This Code system is referenced in the definition of the following value sets:

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fs3-group-selfcare",
  "url" : "http://ehealth.sundhed.dk/cs/fs3-group-selfcare",
  "version" : "11.0.4",
  "name" : "FS III, Egenomsorg",
  "title" : "FS III, Egenomsorg",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "FS III, Egenomsorg",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "complete",
  "concept" : [{
    "code" : "WASH",
    "display" : "Vaske sig",
    "designation" : [{
      "language" : "da",
      "value" : "Vaske sig"
    }]
  },
  {
    "code" : "USE_TOILET",
    "display" : "Gå på toilet",
    "designation" : [{
      "language" : "da",
      "value" : "Gå på toilet"
    }]
  },
  {
    "code" : "BODY_CARE",
    "display" : "Kropspleje",
    "designation" : [{
      "language" : "da",
      "value" : "Kropspleje"
    }]
  },
  {
    "code" : "DRESS_UNDRESS",
    "display" : "Af- og påklædning",
    "designation" : [{
      "language" : "da",
      "value" : "Af- og påklædning"
    }]
  },
  {
    "code" : "EAT",
    "display" : "Spise",
    "designation" : [{
      "language" : "da",
      "value" : "Spise"
    }]
  },
  {
    "code" : "DRINK",
    "display" : "Drikke",
    "designation" : [{
      "language" : "da",
      "value" : "Drikke"
    }]
  },
  {
    "code" : "TAKE_CARE_OF_OWN_HEALTH",
    "display" : "Varetage egen sundhed",
    "designation" : [{
      "language" : "da",
      "value" : "Varetage egen sundhed"
    }]
  },
  {
    "code" : "FOOD_INTAKE",
    "display" : "Fødeindtagelse",
    "designation" : [{
      "language" : "da",
      "value" : "Fødeindtagelse"
    }]
  }]
}

```
