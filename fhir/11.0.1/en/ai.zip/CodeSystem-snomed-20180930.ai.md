# Danish SNOMED CT Extension - eHealth Infrastructure v11.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Danish SNOMED CT Extension**

## CodeSystem: Danish SNOMED CT Extension 

| | |
| :--- | :--- |
| *Official URL*:http://snomed.info/sct/554471000005108/version/20180930 | *Version*:11.0.1 |
| Active as of 2019-12-27 | *Computable Name*:Danish-SNOMED-CT-Extension |
| *Other Identifiers:*OID:2.16.840.1.113883.6.96 | |

 
Danish SNOMED CT Extension 

This Code system is referenced in the definition of the following value sets:

* [Facility Type Codes](ValueSet-ehealth-facility-type-codes.md)
* [SorOrganizationType](ValueSet-ehealth-sor-organization-type.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "snomed-20180930",
  "url" : "http://snomed.info/sct/554471000005108/version/20180930",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.6.96"
  }],
  "version" : "11.0.1",
  "name" : "Danish-SNOMED-CT-Extension",
  "title" : "Danish SNOMED CT Extension",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-12-27T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Danish SNOMED CT Extension",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "557671000005101",
    "display" : "Osteopathy clinic",
    "definition" : "Osteopathy clinic",
    "designation" : [{
      "language" : "da",
      "value" : "osteopatiklinik"
    }]
  }]
}

```
