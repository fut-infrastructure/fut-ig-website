# POST Schedule Practitioner Stats - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* **POST Schedule Practitioner Stats**

## POST Schedule Practitioner Stats

`POST [base]/$schedule-practitioner-stats`

**Header**

```
Accept-Charset: utf-8
Authorization: Bearer eyJhbGciOiJub25lIn0.eyJ1c2VyX2lkIjoiNTk3ZDg3OTgtZWIwMi00NzdmLWI1ODMtMzI5ZWZmOTk0M2NjIiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInJlcG9ydC1ub24tYW5vbnltaXplZCIsIiRmZXRjaC1wcmFjdGl0aW9uZXItc3RhdHMiLCJCaW5hcnkucmVhZCJdfSwiY29udGV4dCI6eyJvcmdhbml6YXRpb25faWQiOiJodHRwczovL29yZ2FuaXphdGlvbi5jaXQtcmVwb3J0aW5nLTExODIubG9jYWwvZmhpci9Pcmdhbml6YXRpb24vNzA5MiIsInRlYW1fb25fZW9jIjpmYWxzZX0sInVzZXJfdHlwZSI6IlBSQUNUSVRJT05FUiJ9.
Accept: application/fhir+json;q=1.0, application/json+fhir;q=0.9
User-Agent: HAPI-FHIR/6.10.5 (FHIR Client; FHIR 4.0.1/R4; apache)
Accept-Encoding: gzip
Content-Type: application/fhir+json; charset=UTF-8

```

**Body**:

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "anonymization",
      "valueString": "None"
    },
    {
      "name": "organization",
      "valueReference": {
        "reference": "https://organization.cit-reporting-1182.local/fhir/Organization/7092"
      }
    },
    {
      "name": "period",
      "valuePeriod": {
        "start": "2025-02-04T14:17:06+00:00",
        "end": "2025-02-04T14:17:06+00:00"
      }
    }
  ]
}

```

**Response**

```
{
  "resourceType": "Binary",
  "id": "23",
  "meta": {
    "versionId": "1",
    "lastUpdated": "2025-02-04T14:17:07.560+00:00",
    "source": "#781baedf-f387-91ac-afd9-5937cbd45ff6",
    "profile": [
      "http://hl7.org/fhir/StructureDefinition/Binary"
    ]
  },
  "contentType": "text/plain",
  "securityContext": {
    "identifier": {
      "value": "597d8798-eb02-477f-b583-329eff9943cc"
    }
  },
  "data": "Kk5PVCBHRU5FUkFURUQgWUVUKg=="
}

```

