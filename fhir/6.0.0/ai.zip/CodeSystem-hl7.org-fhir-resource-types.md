# Resource Type - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Resource Type**

## CodeSystem: Resource Type 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/resource-types | *Version*:6.0.0 | |
| *Standards status:*[Normative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 5 | *Computable Name*:ResourceType |

 
One of the resource types defined as part of FHIR. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem Supplement is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

This code system supplement `http://hl7.org/fhir/resource-types` defines displays on the following codes:



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "hl7.org-fhir-resource-types",
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/valueset-special-status",
      "valueString" : "This Code System is normative - it is generated based on the information defined in this      specification. The definition will remain fixed  across versions, but the actual contents      will change from version to version"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
      "valueCode" : "normative"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
      "valueCode" : "4.0.0"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
      "valueInteger" : 5
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
      "valueCode" : "cds"
    }
  ],
  "url" : "http://hl7.org/fhir/resource-types",
  "version" : "6.0.0",
  "name" : "ResourceType",
  "title" : "Resource Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-10-27T13:27:27+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "One of the resource types defined as part of FHIR.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "content" : "supplement",
  "supplements" : "http://hl7.org/fhir/resource-types",
  "concept" : [
    {
      "code" : "Account",
      "display" : "Account",
      "definition" : "A financial tool for tracking value accrued for a particular purpose.  In the healthcare field, used to track charges for a patient, cost centers, etc.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Konto"
        }
      ]
    },
    {
      "code" : "ActivityDefinition",
      "display" : "ActivityDefinition",
      "definition" : "This resource allows for the definition of some activity to be performed, independent of a particular patient, practitioner, or other performance context.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Aktivitetsdefinition"
        }
      ]
    },
    {
      "code" : "AdverseEvent",
      "display" : "AdverseEvent",
      "definition" : "Actual or  potential/avoided event causing unintended physical injury resulting from or contributed to by medical care, a research study or other healthcare setting factors that requires additional monitoring, treatment, or hospitalization, or that results in death.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Bivirkning"
        }
      ]
    },
    {
      "code" : "AllergyIntolerance",
      "display" : "AllergyIntolerance",
      "definition" : "Risk of harmful or undesirable, physiological response which is unique to an individual and associated with exposure to a substance.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Allergi / intolerance"
        }
      ]
    },
    {
      "code" : "Appointment",
      "display" : "Appointment",
      "definition" : "A booking of a healthcare event among patient(s), practitioner(s), related person(s) and/or device(s) for a specific date/time. This may result in one or more Encounter(s).",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Aftale"
        }
      ]
    },
    {
      "code" : "AppointmentResponse",
      "display" : "AppointmentResponse",
      "definition" : "A reply to an appointment request for a patient and/or practitioner(s), such as a confirmation or rejection.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Aftalesvar"
        }
      ]
    },
    {
      "code" : "AuditEvent",
      "display" : "AuditEvent",
      "definition" : "A record of an event made for purposes of maintaining a security log. Typical uses include detection of intrusion attempts and monitoring for inappropriate usage.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kontrolrapportering"
        }
      ]
    },
    {
      "code" : "Basic",
      "display" : "Basic",
      "definition" : "Basic is used for handling concepts not yet defined in FHIR, narrative-only resources that don't map to an existing resource, and custom resources not appropriate for inclusion in the FHIR specification.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Grundlæggende"
        }
      ]
    },
    {
      "code" : "Binary",
      "display" : "Binary",
      "definition" : "A binary resource can contain any content, whether text, image, pdf, zip archive, etc.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Binær"
        }
      ]
    },
    {
      "code" : "BodyStructure",
      "display" : "BodyStructure",
      "definition" : "Record details about the anatomical location of a specimen or body part.  This resource may be used when a coded concept does not provide the necessary detail needed for the use case.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kropspunkt"
        }
      ]
    },
    {
      "code" : "Bundle",
      "display" : "Bundle",
      "definition" : "A container for a collection of resources.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Bundt"
        }
      ]
    },
    {
      "code" : "CapabilityStatement",
      "display" : "CapabilityStatement",
      "definition" : "A Capability Statement documents a set of capabilities (behaviors) of a FHIR Server that may be used as a statement of actual server functionality or a statement of required or desired server implementation.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kapabilitetserklæring"
        }
      ]
    },
    {
      "code" : "CarePlan",
      "display" : "CarePlan",
      "definition" : "Describes the intention of how one or more practitioners intend to deliver care for a particular patient, group or community for a period of time, possibly limited to care for a specific condition or set of conditions.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Behandlingsplan"
        }
      ]
    },
    {
      "code" : "CareTeam",
      "display" : "CareTeam",
      "definition" : "The Care Team includes all the people and organizations who plan to participate in the coordination and delivery of care for a patient.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Behandlingsteam"
        }
      ]
    },
    {
      "code" : "ChargeItem",
      "display" : "ChargeItem",
      "definition" : "The resource ChargeItem describes the provision of healthcare provider products for a certain patient, therefore referring not only to the product, but containing in addition details of the provision, like date, time, amounts and participating organizations and persons. Main Usage of the ChargeItem is to enable the billing process and internal cost allocation.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Postering"
        }
      ]
    },
    {
      "code" : "Claim",
      "display" : "Claim",
      "definition" : "A provider issued list of services and products provided, or to be provided, to a patient which is provided to an insurer for payment recovery.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Krav"
        }
      ]
    },
    {
      "code" : "ClaimResponse",
      "display" : "ClaimResponse",
      "definition" : "This resource provides the adjudication details from the processing of a Claim resource.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kravssvar"
        }
      ]
    },
    {
      "code" : "ClinicalImpression",
      "display" : "ClinicalImpression",
      "definition" : "A record of a clinical assessment performed to determine what problem(s) may affect the patient and before planning the treatments or management strategies that are best to manage a patient's condition. Assessments are often 1:1 with a clinical consultation / encounter,  but this varies greatly depending on the clinical workflow. This resource is called \"ClinicalImpression\" rather than \"ClinicalAssessment\" to avoid confusion with the recording of assessment tools such as Apgar score.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Klinisk vurdering"
        }
      ]
    },
    {
      "code" : "CodeSystem",
      "display" : "CodeSystem",
      "definition" : "A code system resource specifies a set of codes drawn from one or more code systems.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kodesystem"
        }
      ]
    },
    {
      "code" : "Communication",
      "display" : "Communication",
      "definition" : "An occurrence of information being transmitted; e.g. an alert that was sent to a responsible provider, a public health agency was notified about a reportable condition.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Meddelelse"
        }
      ]
    },
    {
      "code" : "CommunicationRequest",
      "display" : "CommunicationRequest",
      "definition" : "A request to convey information; e.g. the CDS system proposes that an alert be sent to a responsible provider, the CDS system proposes that the public health agency be notified about a reportable condition.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kommunikationsanmodning"
        }
      ]
    },
    {
      "code" : "CompartmentDefinition",
      "display" : "CompartmentDefinition",
      "definition" : "A compartment definition that defines how resources are accessed on a server.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Rumdefinition"
        }
      ]
    },
    {
      "code" : "Composition",
      "display" : "Composition",
      "definition" : "A set of healthcare-related information that is assembled together into a single logical document that provides a single coherent statement of meaning, establishes its own context and that has clinical attestation with regard to who is making the statement. While a Composition defines the structure, it does not actually contain the content: rather the full content of a document is contained in a Bundle, of which the Composition is the first resource contained.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Sammensætning"
        }
      ]
    },
    {
      "code" : "ConceptMap",
      "display" : "ConceptMap",
      "definition" : "A statement of relationships from one set of concepts to one or more other concepts - either code systems or data elements, or classes in class models.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Konceptkortlægning"
        }
      ]
    },
    {
      "code" : "Condition",
      "display" : "Condition",
      "definition" : "A clinical condition, problem, diagnosis, or other event, situation, issue, or clinical concept that has risen to a level of concern.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Tilstand"
        }
      ]
    },
    {
      "code" : "Consent",
      "display" : "Consent",
      "definition" : "A record of a healthcare consumer’s policy choices, which permits or denies identified recipient(s) or recipient role(s) to perform one or more actions within a given policy context, for specific purposes and periods of time.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Samtykke"
        }
      ]
    },
    {
      "code" : "Contract",
      "display" : "Contract",
      "definition" : "A formal agreement between parties regarding the conduct of business, exchange of information or other matters.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kontrakt"
        }
      ]
    },
    {
      "code" : "Coverage",
      "display" : "Coverage",
      "definition" : "Financial instrument which may be used to reimburse or pay for health care products and services.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Dækning"
        }
      ]
    },
    {
      "code" : "DetectedIssue",
      "display" : "DetectedIssue",
      "definition" : "Indicates an actual or potential clinical issue with or between one or more active or proposed clinical actions for a patient; e.g. Drug-drug interaction, Ineffective treatment frequency, Procedure-condition conflict, etc.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Registreret problem"
        }
      ]
    },
    {
      "code" : "Device",
      "display" : "Device",
      "definition" : "This resource identifies an instance or a type of a manufactured item that is used in the provision of healthcare without being substantially changed through that activity. The device may be a medical or non-medical device.  Medical devices include durable (reusable) medical equipment, implantable devices, as well as disposable equipment used for diagnostic, treatment, and research for healthcare and public health.  Non-medical devices may include items such as a machine, cellphone, computer, application, etc.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Enhed"
        }
      ]
    },
    {
      "code" : "DeviceDefinition",
      "display" : "DeviceDefinition",
      "definition" : "The characteristics, operational status and capabilities of a medical-related component of a medical device.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Enhedskomponent"
        }
      ]
    },
    {
      "code" : "DeviceMetric",
      "display" : "DeviceMetric",
      "definition" : "Describes a measurement, calculation or setting capability of a medical device.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Enhedsfunktion"
        }
      ]
    },
    {
      "code" : "DeviceRequest",
      "display" : "DeviceRequest",
      "definition" : "Represents a request for a patient to employ a medical device. The device may be an implantable device, or an external assistive device, such as a walker.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Enhedsbrugsanmodning"
        }
      ]
    },
    {
      "code" : "DeviceUseStatement",
      "display" : "DeviceUseStatement",
      "definition" : "A record of a device being used by a patient where the record is the result of a report from the patient or another clinician.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Enhedsbrugsrapport"
        }
      ]
    },
    {
      "code" : "DiagnosticReport",
      "display" : "DiagnosticReport",
      "definition" : "The findings and interpretation of diagnostic  tests performed on patients, groups of patients, devices, and locations, and/or specimens derived from these. The report includes clinical context such as requesting and provider information, and some mix of atomic results, images, textual and coded interpretations, and formatted representation of diagnostic reports.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Diagnosticeringsrapport"
        }
      ]
    },
    {
      "code" : "DocumentManifest",
      "display" : "DocumentManifest",
      "definition" : "A collection of documents compiled for a purpose together with metadata that applies to the collection.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Dokumentsamling"
        }
      ]
    },
    {
      "code" : "DocumentReference",
      "display" : "DocumentReference",
      "definition" : "A reference to a document.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Dokumentsreference"
        }
      ]
    },
    {
      "code" : "DomainResource",
      "display" : "DomainResource",
      "definition" : "A resource that includes narrative, extensions, and contained resources.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Domæneressource"
        }
      ]
    },
    {
      "code" : "CoverageEligibilityRequest",
      "display" : "CoverageEligibilityRequest",
      "definition" : "The CoverageEligibilityRequest provides patient and insurance coverage information to an insurer for them to respond, in the form of an CoverageEligibilityResponse, with information regarding whether the stated coverage is valid and in-force and optionally to provide the insurance details of the policy.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Gyldighedsanmodning"
        }
      ]
    },
    {
      "code" : "CoverageEligibilityResponse",
      "display" : "CoverageEligibilityResponse",
      "definition" : "This resource provides eligibility and plan details from the processing of an CoverageEligibilityRequest resource.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Gyldighedssvar"
        }
      ]
    },
    {
      "code" : "Encounter",
      "display" : "Encounter",
      "definition" : "An interaction between a patient and healthcare provider(s) for the purpose of providing healthcare service(s) or assessing the health status of a patient.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kontakt"
        }
      ]
    },
    {
      "code" : "Endpoint",
      "display" : "Endpoint",
      "definition" : "The technical details of an endpoint that can be used for electronic services, such as for web services providing XDS.b or a REST endpoint for another FHIR server. This may include any security context information.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Endepunkt"
        }
      ]
    },
    {
      "code" : "EnrollmentRequest",
      "display" : "EnrollmentRequest",
      "definition" : "This resource provides the insurance enrollment details to the insurer regarding a specified coverage.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Tilmeldingsanmodning"
        }
      ]
    },
    {
      "code" : "EnrollmentResponse",
      "display" : "EnrollmentResponse",
      "definition" : "This resource provides enrollment and plan details from the processing of an Enrollment resource.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Tilmeldingssvar"
        }
      ]
    },
    {
      "code" : "EpisodeOfCare",
      "display" : "EpisodeOfCare",
      "definition" : "An association between a patient and an organization / healthcare provider(s) during which time encounters may occur. The managing organization assumes a level of responsibility for the patient during this time.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Forløb"
        }
      ]
    },
    {
      "code" : "ExplanationOfBenefit",
      "display" : "ExplanationOfBenefit",
      "definition" : "This resource provides: the claim details; adjudication details from the processing of a Claim; and optionally account balance information, for informing the subscriber of the benefits provided.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Kravsudfald"
        }
      ]
    },
    {
      "code" : "FamilyMemberHistory",
      "display" : "FamilyMemberHistory",
      "definition" : "Significant health events and conditions for a person related to the patient relevant in the context of care for the patient.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Familiemedlemshelbredshistorik"
        }
      ]
    },
    {
      "code" : "Flag",
      "display" : "Flag",
      "definition" : "Prospective warnings of potential issues when providing care to the patient.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Flag"
        }
      ]
    },
    {
      "code" : "Goal",
      "display" : "Goal",
      "definition" : "Describes the intended objective(s) for a patient, group or organization care, for example, weight loss, restoring an activity of daily living, obtaining herd immunity via immunization, meeting a process improvement objective, etc.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Mål"
        }
      ]
    },
    {
      "code" : "GraphDefinition",
      "display" : "GraphDefinition",
      "definition" : "A formal computable definition of a graph of resources - that is, a coherent set of resources that form a graph by following references. The Graph Definition resource defines a set and makes rules about the set.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Grafdefinition"
        }
      ]
    },
    {
      "code" : "Group",
      "display" : "Group",
      "definition" : "Represents a defined collection of entities that may be discussed or acted upon collectively but which are not expected to act collectively and are not formally or legally recognized; i.e. a collection of entities that isn't an Organization.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Gruppe"
        }
      ]
    },
    {
      "code" : "GuidanceResponse",
      "display" : "GuidanceResponse",
      "definition" : "A guidance response is the formal response to a guidance request, including any output parameters returned by the evaluation, as well as the description of any proposed actions to be taken.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Vejledningssvar"
        }
      ]
    },
    {
      "code" : "HealthcareService",
      "display" : "HealthcareService",
      "definition" : "The details of a healthcare service available at a location.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Sundhedsservice"
        }
      ]
    },
    {
      "code" : "Immunization",
      "display" : "Immunization",
      "definition" : "Describes the event of a patient being administered a vaccination or a record of a vaccination as reported by a patient, a clinician or another party and may include vaccine reaction information and what vaccination protocol was followed.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Immunisering"
        }
      ]
    },
    {
      "code" : "ImmunizationRecommendation",
      "display" : "ImmunizationRecommendation",
      "definition" : "A patient's point-in-time immunization and recommendation (i.e. forecasting a patient's immunization eligibility according to a published schedule) with optional supporting justification.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Immuniseringsanbefaling"
        }
      ]
    },
    {
      "code" : "ImplementationGuide",
      "display" : "ImplementationGuide",
      "definition" : "A set of rules of how FHIR is used to solve a particular problem. This resource is used to gather all the parts of an implementation guide into a logical whole and to publish a computable definition of all the parts.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Implementationsguide"
        }
      ]
    },
    {
      "code" : "Library",
      "display" : "Library",
      "definition" : "The Library resource is a general-purpose container for knowledge asset definitions. It can be used to describe and expose existing knowledge assets such as logic libraries and information model descriptions, as well as to describe a collection of knowledge assets.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Bibliotek"
        }
      ]
    },
    {
      "code" : "Linkage",
      "display" : "Linkage",
      "definition" : "Identifies two or more records (resource instances) that are referring to the same real-world \"occurrence\".",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Sammenkobling"
        }
      ]
    },
    {
      "code" : "List",
      "display" : "List",
      "definition" : "A set of information summarized from a list of other resources.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Liste"
        }
      ]
    },
    {
      "code" : "Location",
      "display" : "Location",
      "definition" : "Details and position information for a physical place where services are provided  and resources and participants may be stored, found, contained or accommodated.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Lokation"
        }
      ]
    },
    {
      "code" : "Measure",
      "display" : "Measure",
      "definition" : "The Measure resource provides the definition of a quality measure.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Måling"
        }
      ]
    },
    {
      "code" : "MeasureReport",
      "display" : "MeasureReport",
      "definition" : "The MeasureReport resource contains the results of evaluating a measure.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Målingsundersøgelse"
        }
      ]
    },
    {
      "code" : "Media",
      "display" : "Media",
      "definition" : "A photo, video, or audio recording acquired or used in healthcare. The actual content may be inline or provided by direct reference.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Medie"
        }
      ]
    },
    {
      "code" : "Medication",
      "display" : "Medication",
      "definition" : "This resource is primarily used for the identification and definition of a medication. It covers the ingredients and the packaging for a medication.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Medicin"
        }
      ]
    },
    {
      "code" : "MedicationAdministration",
      "display" : "MedicationAdministration",
      "definition" : "Describes the event of a patient consuming or otherwise being administered a medication.  This may be as simple as swallowing a tablet or it may be a long running infusion.  Related resources tie this event to the authorizing prescription, and the specific encounter between patient and health care practitioner.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Medicinering"
        }
      ]
    },
    {
      "code" : "MedicationDispense",
      "display" : "MedicationDispense",
      "definition" : "Indicates that a medication product is to be or has been dispensed for a named person/patient.  This includes a description of the medication product (supply) provided and the instructions for administering the medication.  The medication dispense is the result of a pharmacy system responding to a medication order.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Dispensering"
        }
      ]
    },
    {
      "code" : "MedicationRequest",
      "display" : "MedicationRequest",
      "definition" : "An order or request for both supply of the medication and the instructions for administration of the medication to a patient. The resource is called \"MedicationRequest\" rather than \"MedicationPrescription\" or \"MedicationOrder\" to generalize the use across inpatient and outpatient settings, including care plans, etc., and to harmonize with workflow patterns.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Medicineringsanmodning"
        }
      ]
    },
    {
      "code" : "MedicationStatement",
      "display" : "MedicationStatement",
      "definition" : "A record of a medication that is being consumed by a patient.   A MedicationStatement may indicate that the patient may be taking the medication now, or has taken the medication in the past or will be taking the medication in the future.  The source of this information can be the patient, significant other (such as a family member or spouse), or a clinician.  A common scenario where this information is captured is during the history taking process during a patient visit or stay.   The medication information may come from sources such as the patient's memory, from a prescription bottle,  or from a list of medications the patient, clinician or other party maintains   The primary difference between a medication statement and a medication administration is that the medication administration has complete administration information and is based on actual administration information from the person who administered the medication.  A medication statement is often, if not always, less specific.  There is no required date/time when the medication was administered, in fact we only know that a source has reported the patient is taking this medication, where details such as time, quantity, or rate or even medication product may be incomplete or missing or less precise.  As stated earlier, the medication statement information may come from the patient's memory, from a prescription bottle or from a list of medications the patient, clinician or other party maintains.  Medication administration is more formal and is not missing detailed information.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Medicinerklæring"
        }
      ]
    },
    {
      "code" : "MessageDefinition",
      "display" : "MessageDefinition",
      "definition" : "Defines the characteristics of a message that can be shared between systems, including the type of event that initiates the message, the content to be transmitted and what response(s), if any, are permitted.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Beskeddefinition"
        }
      ]
    },
    {
      "code" : "MessageHeader",
      "display" : "MessageHeader",
      "definition" : "The header for a message exchange that is either requesting or responding to an action.  The reference(s) that are the subject of the action as well as other information related to the action are typically transmitted in a bundle in which the MessageHeader resource instance is the first resource in the bundle.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Brevhoved"
        }
      ]
    },
    {
      "code" : "NamingSystem",
      "display" : "NamingSystem",
      "definition" : "A curated namespace that issues unique symbols within that namespace for the identification of concepts, people, devices, etc.  Represents a \"System\" used within the Identifier and Coding data types.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Navngivningssystem"
        }
      ]
    },
    {
      "code" : "NutritionOrder",
      "display" : "NutritionOrder",
      "definition" : "A request to supply a diet, formula feeding (enteral) or oral nutritional supplement to a patient/resident.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Ernæringsbestilling"
        }
      ]
    },
    {
      "code" : "Observation",
      "display" : "Observation",
      "definition" : "Measurements and simple assertions made about a patient, device or other subject.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Observation"
        }
      ]
    },
    {
      "code" : "OperationDefinition",
      "display" : "OperationDefinition",
      "definition" : "A formal computable definition of an operation (on the RESTful interface) or a named query (using the search interaction).",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Operationsdefinition"
        }
      ]
    },
    {
      "code" : "OperationOutcome",
      "display" : "OperationOutcome",
      "definition" : "A collection of error, warning or information messages that result from a system action.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Operationsudfald"
        }
      ]
    },
    {
      "code" : "Organization",
      "display" : "Organization",
      "definition" : "A formally or informally recognized grouping of people or organizations formed for the purpose of achieving some form of collective action.  Includes companies, institutions, corporations, departments, community groups, healthcare practice groups, etc.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Organisation"
        }
      ]
    },
    {
      "code" : "Parameters",
      "display" : "Parameters",
      "definition" : "This special resource type is used to represent an operation request and response (operations.html). It has no other use, and there is no RESTful endpoint associated with it.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Parametre"
        }
      ]
    },
    {
      "code" : "Patient",
      "display" : "Patient",
      "definition" : "Demographics and other administrative information about an individual or animal receiving care or other health-related services.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Patient"
        }
      ]
    },
    {
      "code" : "PaymentNotice",
      "display" : "PaymentNotice",
      "definition" : "This resource provides the status of the payment for goods and services rendered, and the request and response resource references.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Betalingsstatus"
        }
      ]
    },
    {
      "code" : "PaymentReconciliation",
      "display" : "PaymentReconciliation",
      "definition" : "This resource provides payment details and claim references supporting a bulk payment.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Betalingsafstemning"
        }
      ]
    },
    {
      "code" : "Person",
      "display" : "Person",
      "definition" : "Demographics and administrative information about a person independent of a specific health-related context.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Person"
        }
      ]
    },
    {
      "code" : "PlanDefinition",
      "display" : "PlanDefinition",
      "definition" : "This resource allows for the definition of various types of plans as a sharable, consumable, and executable artifact. The resource is general enough to support the description of a broad range of clinical artifacts such as clinical decision support rules, order sets and protocols.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Plandefinition"
        }
      ]
    },
    {
      "code" : "Practitioner",
      "display" : "Practitioner",
      "definition" : "A person who is directly or indirectly involved in the provisioning of healthcare.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Sundhedsperson"
        }
      ]
    },
    {
      "code" : "PractitionerRole",
      "display" : "PractitionerRole",
      "definition" : "A specific set of Roles/Locations/specialties/services that a practitioner may perform at an organization for a period of time.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Sundhedsrolle"
        }
      ]
    },
    {
      "code" : "Procedure",
      "display" : "Procedure",
      "definition" : "An action that is or was performed on a patient. This can be a physical intervention like an operation, or less invasive like counseling or hypnotherapy.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Procedure"
        }
      ]
    },
    {
      "code" : "ServiceRequest",
      "display" : "ServiceRequest",
      "definition" : "A record of a request for service such as diagnostic investigations, treatments, or operations to be performed.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Procedureanmodning"
        }
      ]
    },
    {
      "code" : "Provenance",
      "display" : "Provenance",
      "definition" : "Provenance of a resource is a record that describes entities and processes involved in producing and delivering or otherwise influencing that resource. Provenance provides a critical foundation for assessing authenticity, enabling trust, and allowing reproducibility. Provenance assertions are a form of contextual metadata and can themselves become important records with their own provenance. Provenance statement indicates clinical significance in terms of confidence in authenticity, reliability, and trustworthiness, integrity, and stage in lifecycle (e.g. Document Completion - has the artifact been legally authenticated), all of which may impact security, privacy, and trust policies.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Oprindelse"
        }
      ]
    },
    {
      "code" : "Questionnaire",
      "display" : "Questionnaire",
      "definition" : "A structured set of questions intended to guide the collection of answers from end-users. Questionnaires provide detailed control over order, presentation, phraseology and grouping to allow coherent, consistent data collection.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Spørgeskema"
        }
      ]
    },
    {
      "code" : "QuestionnaireResponse",
      "display" : "QuestionnaireResponse",
      "definition" : "A structured set of questions and their answers. The questions are ordered and grouped into coherent subsets, corresponding to the structure of the grouping of the questionnaire being responded to.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Spørgeskemasvar"
        }
      ]
    },
    {
      "code" : "RelatedPerson",
      "display" : "RelatedPerson",
      "definition" : "Information about a person that is involved in the care for a patient, but who is not the target of healthcare, nor has a formal responsibility in the care process.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Pårørende"
        }
      ]
    },
    {
      "code" : "RequestGroup",
      "display" : "RequestGroup",
      "definition" : "A group of related requests that can be used to capture intended activities that have inter-dependencies such as \"give this medication after that one\".",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Anmodningsgruppe"
        }
      ]
    },
    {
      "code" : "ResearchStudy",
      "display" : "ResearchStudy",
      "definition" : "A process where a researcher or organization plans and then executes a series of steps intended to increase the field of healthcare-related knowledge.  This includes studies of safety, efficacy, comparative effectiveness and other information about medications, devices, therapies and other interventional and investigative techniques.  A ResearchStudy involves the gathering of information about human or animal subjects.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Forskningsundersøgelse"
        }
      ]
    },
    {
      "code" : "ResearchSubject",
      "display" : "ResearchSubject",
      "definition" : "A process where a researcher or organization plans and then executes a series of steps intended to increase the field of healthcare-related knowledge.  This includes studies of safety, efficacy, comparative effectiveness and other information about medications, devices, therapies and other interventional and investigative techniques.  A ResearchStudy involves the gathering of information about human or animal subjects.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Forskningsemne"
        }
      ]
    },
    {
      "code" : "Resource",
      "display" : "Resource",
      "definition" : "This is the base resource type for everything.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Ressource"
        }
      ]
    },
    {
      "code" : "RiskAssessment",
      "display" : "RiskAssessment",
      "definition" : "An assessment of the likely outcome(s) for a patient or other subject as well as the likelihood of each outcome.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Risikovurdering"
        }
      ]
    },
    {
      "code" : "Schedule",
      "display" : "Schedule",
      "definition" : "A container for slots of time that may be available for booking appointments.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Tidsplan"
        }
      ]
    },
    {
      "code" : "SearchParameter",
      "display" : "SearchParameter",
      "definition" : "A search parameter that defines a named search item that can be used to search/filter on a resource.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Søgeparameter"
        }
      ]
    },
    {
      "code" : "MolecularSequence",
      "display" : "MolecularSequence",
      "definition" : "Raw data describing a biological sequence.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Sekvens"
        }
      ]
    },
    {
      "code" : "Slot",
      "display" : "Slot",
      "definition" : "A slot of time on a schedule that may be available for booking appointments.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Tidsvindue"
        }
      ]
    },
    {
      "code" : "Specimen",
      "display" : "Specimen",
      "definition" : "A sample to be used for analysis.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Prøve"
        }
      ]
    },
    {
      "code" : "StructureDefinition",
      "display" : "StructureDefinition",
      "definition" : "A definition of a FHIR structure. This resource is used to describe the underlying resources, data types defined in FHIR, and also for describing extensions and constraints on resources and data types.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Strukturdefinition"
        }
      ]
    },
    {
      "code" : "StructureMap",
      "display" : "StructureMap",
      "definition" : "A Map of relationships between 2 structures that can be used to transform data.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Strukturkortlægning"
        }
      ]
    },
    {
      "code" : "Subscription",
      "display" : "Subscription",
      "definition" : "The subscription resource is used to define a push based subscription from a server to another system. Once a subscription is registered with the server, the server checks every resource that is created or updated, and if the resource matches the given criteria, it sends a message on the defined \"channel\" so that another system is able to take an appropriate action.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Abonnement"
        }
      ]
    },
    {
      "code" : "Substance",
      "display" : "Substance",
      "definition" : "A homogeneous material with a definite composition.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Stof"
        }
      ]
    },
    {
      "code" : "SupplyDelivery",
      "display" : "SupplyDelivery",
      "definition" : "Record of delivery of what is supplied.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Forsyningslevering"
        }
      ]
    },
    {
      "code" : "SupplyRequest",
      "display" : "SupplyRequest",
      "definition" : "A record of a request for a medication, substance or device used in the healthcare setting.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Forsyningsanmodning"
        }
      ]
    },
    {
      "code" : "Task",
      "display" : "Task",
      "definition" : "A task to be performed.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Opgave"
        }
      ]
    },
    {
      "code" : "TestReport",
      "display" : "TestReport",
      "definition" : "A summary of information based on the results of executing a TestScript.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Testrapport"
        }
      ]
    },
    {
      "code" : "TestScript",
      "display" : "TestScript",
      "definition" : "A structured set of tests against a FHIR server implementation to determine compliance against the FHIR specification.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Testscript"
        }
      ]
    },
    {
      "code" : "ValueSet",
      "display" : "ValueSet",
      "definition" : "A value set specifies a set of codes drawn from one or more code systems.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Værdisæt"
        }
      ]
    },
    {
      "code" : "VisionPrescription",
      "display" : "VisionPrescription",
      "definition" : "An authorization for the supply of glasses and/or contact lenses to a patient.",
      "designation" : [
        {
          "language" : "da",
          "use" : {
            "system" : "http://snomed.info/sct",
            "code" : "900000000000013009"
          },
          "value" : "Synsrecept"
        }
      ]
    }
  ]
}

```
