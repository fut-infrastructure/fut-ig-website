# Reference Range Type - eHealth Infrastructure v11.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Reference Range Type**

## CodeSystem: Reference Range Type 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/reference-range-type | *Version*:11.0.4 |
| Active as of 2021-01-13 | *Computable Name*:ReferenceRangeType |
| *Other Identifiers:*OID:1.2.208.176.7.200.1 | |

 
Reference Range Type 

This Code system is referenced in the definition of the following value sets:

* [ClinicalImpression Finding Codes](ValueSet-ehealth-clinicalimpression-finding-codes.md)
* [Reference Range Type](ValueSet-ehealth-reference-range-type.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-reference-range-type",
  "url" : "http://ehealth.sundhed.dk/cs/reference-range-type",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.208.176.7.200.1"
  }],
  "version" : "11.0.4",
  "name" : "ReferenceRangeType",
  "title" : "Reference Range Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-01-13T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Reference Range Type",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [{
    "code" : "deprecated",
    "uri" : "http://hl7.org/fhir/concept-properties#deprecated",
    "description" : "Indicates that the concept is deprecated and should not be used",
    "type" : "dateTime"
  }],
  "concept" : [{
    "code" : "TBD",
    "display" : "Example value - Under construction",
    "definition" : "Example value - Under construction",
    "property" : [{
      "code" : "deprecated",
      "valueDateTime" : "2020-02-27"
    }]
  },
  {
    "code" : "TBD2",
    "display" : "Example value2 - Under construction",
    "definition" : "Example value2 - Under construction",
    "property" : [{
      "code" : "deprecated",
      "valueDateTime" : "2020-02-27"
    }]
  },
  {
    "code" : "RELRAL",
    "display" : "Terapeutic relative reference range for RED alarm",
    "definition" : "Terapeutic relative reference range for RED alarm",
    "designation" : [{
      "language" : "da",
      "value" : "Terapeutiske relative grænseværdier for RØD alarm"
    }]
  },
  {
    "code" : "RELGAL",
    "display" : "Terapeutic relative reference range for YELLOW alarm",
    "definition" : "Terapeutic relative reference range for YELLOW alarm",
    "designation" : [{
      "language" : "da",
      "value" : "Terapeutiske relative grænseværdier for GUL alarm"
    }]
  }]
}

```
