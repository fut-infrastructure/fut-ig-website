# FS III, Respiration og cirkulation - eHealth Infrastructure v11.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FS III, Respiration og cirkulation**

## CodeSystem: FS III, Respiration og cirkulation (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/fs3-health-respiration-and-circulation | *Version*:11.0.4 |
| Active as of 2019-02-02 | *Computable Name*:FS III, Respiration og cirkulation |

 
FS III, Respiration og cirkulation 

This Code system is referenced in the definition of the following value sets:

* [FS III, helbredstilstande](ValueSet-fs3-health.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fs3-health-respiration-and-circulation",
  "url" : "http://ehealth.sundhed.dk/cs/fs3-health-respiration-and-circulation",
  "version" : "11.0.4",
  "name" : "FS III, Respiration og cirkulation",
  "title" : "FS III, Respiration og cirkulation",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "FS III, Respiration og cirkulation",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "complete",
  "concept" : [{
    "code" : "RESPIRATION",
    "display" : "Respirationsproblemer",
    "designation" : [{
      "language" : "da",
      "value" : "Respirationsproblemer"
    }]
  },
  {
    "code" : "CIRCULATION",
    "display" : "Cirkulationsproblemer",
    "designation" : [{
      "language" : "da",
      "value" : "Cirkulationsproblemer"
    }]
  }]
}

```
