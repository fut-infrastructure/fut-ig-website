# FS III, niveauer - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FS III, niveauer**

## CodeSystem: FS III, niveauer (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/fs3-scores | *Version*:6.0.0 |
| Active as of 2019-02-02 | *Computable Name*:FS III, niveauer |

 
FS III, niveauer 

 This Code system is referenced in the content logical definition of the following value sets: 

* [IT Competence Level codes](ValueSet-competence-percentage-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fs3-scores",
  "url" : "http://ehealth.sundhed.dk/cs/fs3-scores",
  "version" : "6.0.0",
  "name" : "FS III, niveauer",
  "title" : "FS III, niveauer",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "FS III, niveauer",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "content" : "complete",
  "concept" : [
    {
      "code" : "0",
      "display" : "Ingen eller ubetydelige begrænsninger",
      "designation" : [
        {
          "language" : "da",
          "value" : "Ingen eller ubetydelige begrænsninger"
        }
      ]
    },
    {
      "code" : "1",
      "display" : "Lette begrænsninger",
      "designation" : [
        {
          "language" : "da",
          "value" : "Lette begrænsninger"
        },
        {
          "language" : "en-US",
          "value" : "Light restrictions"
        }
      ]
    },
    {
      "code" : "2",
      "display" : "Moderate begrænsninger",
      "designation" : [
        {
          "language" : "da",
          "value" : "Moderate begrænsninger"
        },
        {
          "language" : "en-US",
          "value" : "Moderate restrictions"
        }
      ]
    },
    {
      "code" : "3",
      "display" : "Svære begrænsninger",
      "designation" : [
        {
          "language" : "da",
          "value" : "Svære begrænsninger"
        },
        {
          "language" : "en-US",
          "value" : "Severe restrictions"
        }
      ]
    },
    {
      "code" : "4",
      "display" : "Totale begrænsninger",
      "designation" : [
        {
          "language" : "da",
          "value" : "Totale begrænsninger"
        },
        {
          "language" : "en-US",
          "value" : "Total restrictions"
        }
      ]
    },
    {
      "code" : "9",
      "display" : "Ikke relevant",
      "designation" : [
        {
          "language" : "da",
          "value" : "Ikke relevant"
        },
        {
          "language" : "en-US",
          "value" : "Not relevant"
        }
      ]
    }
  ]
}

```
