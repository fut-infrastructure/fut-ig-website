# Integer percentage codes - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Integer percentage codes**

## CodeSystem: Integer percentage codes (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/percentage-codes | *Version*:6.0.0 |
| Active as of 2019-02-02 | *Computable Name*:Integer percentage codes |

 
Integer percentage codes 0-100 

 This Code system is referenced in the content logical definition of the following value sets: 

* [IT Competence Level codes](ValueSet-competence-percentage-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "percentage-codes",
  "url" : "http://ehealth.sundhed.dk/cs/percentage-codes",
  "version" : "6.0.0",
  "name" : "Integer percentage codes",
  "title" : "Integer percentage codes",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [
    {
      "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://ehealth.sundhed.dk"
        }
      ]
    }
  ],
  "description" : "Integer percentage codes 0-100",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DK",
          "display" : "Denmark"
        }
      ]
    }
  ],
  "content" : "complete",
  "concept" : [
    {
      "code" : "0",
      "display" : "0"
    },
    {
      "code" : "1",
      "display" : "1"
    },
    {
      "code" : "2",
      "display" : "2"
    },
    {
      "code" : "3",
      "display" : "3"
    },
    {
      "code" : "4",
      "display" : "4"
    },
    {
      "code" : "5",
      "display" : "5"
    },
    {
      "code" : "6",
      "display" : "6"
    },
    {
      "code" : "7",
      "display" : "7"
    },
    {
      "code" : "8",
      "display" : "8"
    },
    {
      "code" : "9",
      "display" : "9"
    },
    {
      "code" : "10",
      "display" : "10"
    },
    {
      "code" : "11",
      "display" : "11"
    },
    {
      "code" : "12",
      "display" : "12"
    },
    {
      "code" : "13",
      "display" : "13"
    },
    {
      "code" : "14",
      "display" : "14"
    },
    {
      "code" : "15",
      "display" : "15"
    },
    {
      "code" : "16",
      "display" : "16"
    },
    {
      "code" : "17",
      "display" : "17"
    },
    {
      "code" : "18",
      "display" : "18"
    },
    {
      "code" : "19",
      "display" : "19"
    },
    {
      "code" : "20",
      "display" : "20"
    },
    {
      "code" : "21",
      "display" : "21"
    },
    {
      "code" : "22",
      "display" : "22"
    },
    {
      "code" : "23",
      "display" : "23"
    },
    {
      "code" : "24",
      "display" : "24"
    },
    {
      "code" : "25",
      "display" : "25"
    },
    {
      "code" : "26",
      "display" : "26"
    },
    {
      "code" : "27",
      "display" : "27"
    },
    {
      "code" : "28",
      "display" : "28"
    },
    {
      "code" : "29",
      "display" : "29"
    },
    {
      "code" : "30",
      "display" : "30"
    },
    {
      "code" : "31",
      "display" : "31"
    },
    {
      "code" : "32",
      "display" : "32"
    },
    {
      "code" : "33",
      "display" : "33"
    },
    {
      "code" : "34",
      "display" : "34"
    },
    {
      "code" : "35",
      "display" : "35"
    },
    {
      "code" : "36",
      "display" : "36"
    },
    {
      "code" : "37",
      "display" : "37"
    },
    {
      "code" : "38",
      "display" : "38"
    },
    {
      "code" : "39",
      "display" : "39"
    },
    {
      "code" : "40",
      "display" : "40"
    },
    {
      "code" : "41",
      "display" : "41"
    },
    {
      "code" : "42",
      "display" : "42"
    },
    {
      "code" : "43",
      "display" : "43"
    },
    {
      "code" : "44",
      "display" : "44"
    },
    {
      "code" : "45",
      "display" : "45"
    },
    {
      "code" : "46",
      "display" : "46"
    },
    {
      "code" : "47",
      "display" : "47"
    },
    {
      "code" : "48",
      "display" : "48"
    },
    {
      "code" : "49",
      "display" : "49"
    },
    {
      "code" : "50",
      "display" : "50"
    },
    {
      "code" : "51",
      "display" : "51"
    },
    {
      "code" : "52",
      "display" : "52"
    },
    {
      "code" : "53",
      "display" : "53"
    },
    {
      "code" : "54",
      "display" : "54"
    },
    {
      "code" : "55",
      "display" : "55"
    },
    {
      "code" : "56",
      "display" : "56"
    },
    {
      "code" : "57",
      "display" : "57"
    },
    {
      "code" : "58",
      "display" : "58"
    },
    {
      "code" : "59",
      "display" : "59"
    },
    {
      "code" : "60",
      "display" : "60"
    },
    {
      "code" : "61",
      "display" : "61"
    },
    {
      "code" : "62",
      "display" : "62"
    },
    {
      "code" : "63",
      "display" : "63"
    },
    {
      "code" : "64",
      "display" : "64"
    },
    {
      "code" : "65",
      "display" : "65"
    },
    {
      "code" : "66",
      "display" : "66"
    },
    {
      "code" : "67",
      "display" : "67"
    },
    {
      "code" : "68",
      "display" : "68"
    },
    {
      "code" : "69",
      "display" : "69"
    },
    {
      "code" : "70",
      "display" : "70"
    },
    {
      "code" : "71",
      "display" : "71"
    },
    {
      "code" : "72",
      "display" : "72"
    },
    {
      "code" : "73",
      "display" : "73"
    },
    {
      "code" : "74",
      "display" : "74"
    },
    {
      "code" : "75",
      "display" : "75"
    },
    {
      "code" : "76",
      "display" : "76"
    },
    {
      "code" : "77",
      "display" : "77"
    },
    {
      "code" : "78",
      "display" : "78"
    },
    {
      "code" : "79",
      "display" : "79"
    },
    {
      "code" : "80",
      "display" : "80"
    },
    {
      "code" : "81",
      "display" : "81"
    },
    {
      "code" : "82",
      "display" : "82"
    },
    {
      "code" : "83",
      "display" : "83"
    },
    {
      "code" : "84",
      "display" : "84"
    },
    {
      "code" : "85",
      "display" : "85"
    },
    {
      "code" : "86",
      "display" : "86"
    },
    {
      "code" : "87",
      "display" : "87"
    },
    {
      "code" : "88",
      "display" : "88"
    },
    {
      "code" : "89",
      "display" : "89"
    },
    {
      "code" : "90",
      "display" : "90"
    },
    {
      "code" : "91",
      "display" : "91"
    },
    {
      "code" : "92",
      "display" : "92"
    },
    {
      "code" : "93",
      "display" : "93"
    },
    {
      "code" : "94",
      "display" : "94"
    },
    {
      "code" : "95",
      "display" : "95"
    },
    {
      "code" : "96",
      "display" : "96"
    },
    {
      "code" : "97",
      "display" : "97"
    },
    {
      "code" : "98",
      "display" : "98"
    },
    {
      "code" : "99",
      "display" : "99"
    },
    {
      "code" : "100",
      "display" : "100"
    }
  ]
}

```
