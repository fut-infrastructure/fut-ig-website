# eHealth Telecom Purpose codes - eHealth Infrastructure v11.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eHealth Telecom Purpose codes**

## CodeSystem: eHealth Telecom Purpose codes 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/telecom-purpose | *Version*:11.0.3 |
| Active as of 2026-10-29 | *Computable Name*:EhealthTelecomPurposeCS |

 
Codes indicating the purpose of a telecom contact point. 

This Code system is referenced in the definition of the following value sets:

* [eHealth Telecom Purpose](ValueSet-ehealth-telecom-purpose.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-telecom-purpose",
  "url" : "http://ehealth.sundhed.dk/cs/telecom-purpose",
  "version" : "11.0.3",
  "name" : "EhealthTelecomPurposeCS",
  "title" : "eHealth Telecom Purpose codes",
  "status" : "active",
  "date" : "2026-10-29T11:52:17+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Codes indicating the purpose of a telecom contact point.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "video-appointment-reminder-sms",
    "display" : "SMS reminder to related person for video appointment"
  }]
}

```
