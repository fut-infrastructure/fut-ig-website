# FS III, Praktiske opgaver - eHealth Infrastructure v10.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FS III, Praktiske opgaver**

## CodeSystem: FS III, Praktiske opgaver (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/fs3-group-practicaltasks | *Version*:10.0.2 |
| Active as of 2019-02-02 | *Computable Name*:FS III, Praktiske opgaver |

 
FS III, Praktiske opgaver 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "fs3-group-practicaltasks",
  "url" : "http://ehealth.sundhed.dk/cs/fs3-group-practicaltasks",
  "version" : "10.0.2",
  "name" : "FS III, Praktiske opgaver",
  "title" : "FS III, Praktiske opgaver",
  "status" : "active",
  "experimental" : true,
  "date" : "2019-02-02T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "FS III, Praktiske opgaver",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "content" : "complete",
  "concept" : [{
    "code" : "PERFORM_DAILY_ROUTINES",
    "display" : "Udføre daglige rutiner",
    "designation" : [{
      "language" : "da",
      "value" : "Udføre daglige rutiner"
    }]
  },
  {
    "code" : "OBTAIN_GOODS_AND_SERVICES",
    "display" : "Skaffe sig varer og tjenesteydelser",
    "designation" : [{
      "language" : "da",
      "value" : "Skaffe sig varer og tjenesteydelser"
    }]
  },
  {
    "code" : "COOKING",
    "display" : "Lave mad",
    "designation" : [{
      "language" : "da",
      "value" : "Lave mad"
    }]
  },
  {
    "code" : "DOING_DOMESTIC_WORK",
    "display" : "Lave husligt arbejde",
    "designation" : [{
      "language" : "da",
      "value" : "Lave husligt arbejde"
    }]
  }]
}

```
