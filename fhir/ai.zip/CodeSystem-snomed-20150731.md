# Danish SNOMED CT Extension - eHealth Infrastructure v10.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Danish SNOMED CT Extension**

## CodeSystem: Danish SNOMED CT Extension 

| | |
| :--- | :--- |
| *Official URL*:http://snomed.info/sct/554471000005108/version/20150731 | *Version*:10.0.2 |
| Active as of 2019-12-27 | *Computable Name*:Danish-SNOMED-CT-Extension |
| *Other Identifiers:*OID:2.16.840.1.113883.6.96 | |

 
Danish SNOMED CT Extension 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Facility Type Codes](ValueSet-ehealth-facility-type-codes.md)
* [SorOrganizationSpecialty](ValueSet-sor-organization-specialty.md)
* [SorOrganizationType](ValueSet-ehealth-sor-organization-type.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "snomed-20150731",
  "url" : "http://snomed.info/sct/554471000005108/version/20150731",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.6.96"
  }],
  "version" : "10.0.2",
  "name" : "Danish-SNOMED-CT-Extension",
  "title" : "Danish SNOMED CT Extension",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-12-27T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Danish SNOMED CT Extension",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "551411000005104",
    "display" : "surgical gastroenterology",
    "definition" : "surgical gastroenterology",
    "designation" : [{
      "language" : "da",
      "value" : "kirurgisk gastroenterologi"
    }]
  },
  {
    "code" : "554011000005107",
    "display" : "forensic medicine",
    "definition" : "forensic medicine",
    "designation" : [{
      "language" : "da",
      "value" : "retsmedicin"
    }]
  },
  {
    "code" : "394812008",
    "display" : "dental medicine specialities",
    "definition" : "dental medicine specialities",
    "designation" : [{
      "language" : "da",
      "value" : "odontologiske specialer"
    }]
  },
  {
    "code" : "554221000005108",
    "display" : "dwilling place",
    "definition" : "dwilling place",
    "designation" : [{
      "language" : "da",
      "value" : "bosted"
    }]
  },
  {
    "code" : "554031000005103",
    "display" : "dietician clinic",
    "definition" : "dietician clinic",
    "designation" : [{
      "language" : "da",
      "value" : "diætistklinik"
    }]
  },
  {
    "code" : "546821000005103",
    "display" : "occupational therapy clinic",
    "definition" : "occupational therapy clinic",
    "designation" : [{
      "language" : "da",
      "value" : "ergoterapiklinik"
    }]
  },
  {
    "code" : "547011000005103",
    "display" : "fysiotherapy clinic",
    "definition" : "fysiotherapy clinic",
    "designation" : [{
      "language" : "da",
      "value" : "fysioterapiklinik"
    }]
  },
  {
    "code" : "546811000005109",
    "display" : "rehabilitation center",
    "definition" : "rehabilitation center",
    "designation" : [{
      "language" : "da",
      "value" : "genoptræningscenter"
    }]
  },
  {
    "code" : "550621000005101",
    "display" : "district nursing",
    "definition" : "district nursing",
    "designation" : [{
      "language" : "da",
      "value" : "hjemmesygepleje"
    }]
  },
  {
    "code" : "550631000005103",
    "display" : "midwife clinic",
    "definition" : "midwife clinic",
    "designation" : [{
      "language" : "da",
      "value" : "jordemoderklinik"
    }]
  },
  {
    "code" : "550641000005106",
    "display" : "chiropractic clinic",
    "definition" : "chiropractic clinic",
    "designation" : [{
      "language" : "da",
      "value" : "kiropraktorklinik"
    }]
  },
  {
    "code" : "550651000005108",
    "display" : "medical laboratory",
    "definition" : "medical laboratory",
    "designation" : [{
      "language" : "da",
      "value" : "lægelaboratorium"
    }]
  },
  {
    "code" : "550661000005105",
    "display" : "emergency medical service",
    "definition" : "emergency medical service",
    "designation" : [{
      "language" : "da",
      "value" : "lægevagt"
    }]
  },
  {
    "code" : "554211000005102",
    "display" : "prehospital unit",
    "definition" : "prehospital unit",
    "designation" : [{
      "language" : "da",
      "value" : "præhospitalsenhed"
    }]
  },
  {
    "code" : "550711000005101",
    "display" : "psychology counselling clinic",
    "definition" : "psychology counselling clinic",
    "designation" : [{
      "language" : "da",
      "value" : "psykologisk rådgivningsklinik"
    }]
  },
  {
    "code" : "550671000005100",
    "display" : "medical specialist practice site",
    "definition" : "medical specialist practice site",
    "designation" : [{
      "language" : "da",
      "value" : "speciallægepraksis"
    }]
  },
  {
    "code" : "554061000005105",
    "display" : "Chiropodist clinic",
    "definition" : "Chiropodist clinic",
    "designation" : [{
      "language" : "da",
      "value" : "fodterapeutklinik"
    }]
  },
  {
    "code" : "554041000005106",
    "display" : "health administration",
    "definition" : "health administration",
    "designation" : [{
      "language" : "da",
      "value" : "sundhedsforvaltning"
    }]
  },
  {
    "code" : "554021000005101",
    "display" : "health visitors",
    "definition" : "health visitors",
    "designation" : [{
      "language" : "da",
      "value" : "sundhedspleje"
    }]
  },
  {
    "code" : "550681000005102",
    "display" : "dental practice",
    "definition" : "dental practice",
    "designation" : [{
      "language" : "da",
      "value" : "tandlægepraksis"
    }]
  },
  {
    "code" : "550691000005104",
    "display" : "Dental care clinic",
    "definition" : "Dental care clinic",
    "designation" : [{
      "language" : "da",
      "value" : "tandplejeklinik"
    }]
  },
  {
    "code" : "550701000005104",
    "display" : "dental technician clinic",
    "definition" : "dental technician clinic",
    "designation" : [{
      "language" : "da",
      "value" : "tandteknisk klinik"
    }]
  },
  {
    "code" : "554231000005106",
    "display" : "vaccination clinic",
    "definition" : "vaccination clinic",
    "designation" : [{
      "language" : "da",
      "value" : "vaccinationsklinik"
    }]
  },
  {
    "code" : "554051000005108",
    "display" : "Reflexology clinic",
    "definition" : "Reflexology clinic",
    "designation" : [{
      "language" : "da",
      "value" : "zoneterapiklinik"
    }]
  },
  {
    "code" : "550811000005108",
    "display" : "admistrative unit",
    "definition" : "admistrative unit",
    "designation" : [{
      "language" : "da",
      "value" : "administrativ enhed"
    }]
  },
  {
    "code" : "547211000005108",
    "display" : "municipality",
    "definition" : "municipality",
    "designation" : [{
      "language" : "da",
      "value" : "kommune"
    }]
  },
  {
    "code" : "550891000005100",
    "display" : "private",
    "definition" : "private",
    "designation" : [{
      "language" : "da",
      "value" : "privat"
    }]
  },
  {
    "code" : "550881000005103",
    "display" : "region",
    "definition" : "region",
    "designation" : [{
      "language" : "da",
      "value" : "region"
    }]
  },
  {
    "code" : "550411000005105",
    "display" : "Other health institution",
    "definition" : "Other health institution",
    "designation" : [{
      "language" : "da",
      "value" : "anden sundhedsinstitution"
    }]
  },
  {
    "code" : "554851000005102",
    "display" : "Asylum centre",
    "definition" : "Asylum centre",
    "designation" : [{
      "language" : "da",
      "value" : "asylcenter"
    }]
  },
  {
    "code" : "550861000005106",
    "display" : "fysiotherapy and occupational clinic",
    "definition" : "fysiotherapy and occupational clinic",
    "designation" : [{
      "language" : "da",
      "value" : "fysioterapi- og ergoterapiklinik"
    }]
  },
  {
    "code" : "554881000005108",
    "display" : "handicap and psychiatry",
    "definition" : "handicap and psychiatry",
    "designation" : [{
      "language" : "da",
      "value" : "handicap og psykiatri"
    }]
  },
  {
    "code" : "554861000005100",
    "display" : "handicap",
    "definition" : "handicap",
    "designation" : [{
      "language" : "da",
      "value" : "handicap"
    }]
  },
  {
    "code" : "554821000005109",
    "display" : "home care",
    "definition" : "home care",
    "designation" : [{
      "language" : "da",
      "value" : "hjemmepleje"
    }]
  },
  {
    "code" : "554411000005101",
    "display" : "employment agency",
    "definition" : "employment agency",
    "designation" : [{
      "language" : "da",
      "value" : "jobcenter"
    }]
  },
  {
    "code" : "554871000005105",
    "display" : "psychiatry",
    "definition" : "psychiatry",
    "designation" : [{
      "language" : "da",
      "value" : "psykiatri"
    }]
  },
  {
    "code" : "550821000005102",
    "display" : "service unit",
    "definition" : "service unit",
    "designation" : [{
      "language" : "da",
      "value" : "serviceenhed"
    }]
  },
  {
    "code" : "550871000005101",
    "display" : "emergency admission unit",
    "definition" : "emergency admission unit",
    "designation" : [{
      "language" : "da",
      "value" : "akutmodtageenhed"
    }]
  },
  {
    "code" : "554241000005103",
    "display" : "technical location number",
    "definition" : "technical location number",
    "designation" : [{
      "language" : "da",
      "value" : "teknisk lokationsnummer"
    }]
  },
  {
    "code" : "550841000005107",
    "display" : "research unit",
    "definition" : "research unit",
    "designation" : [{
      "language" : "da",
      "value" : "forskningsenhed"
    }]
  },
  {
    "code" : "550851000005109",
    "display" : "clinical unit",
    "definition" : "clinical unit",
    "designation" : [{
      "language" : "da",
      "value" : "klinisk enhed"
    }]
  },
  {
    "code" : "551611000005102",
    "display" : "surgical ward",
    "definition" : "surgical ward",
    "designation" : [{
      "language" : "da",
      "value" : "operationsgang"
    }]
  },
  {
    "code" : "554071000005100",
    "display" : "hospital pharmacy",
    "definition" : "hospital pharmacy",
    "designation" : [{
      "language" : "da",
      "value" : "sygehusapotek"
    }]
  },
  {
    "code" : "550831000005104",
    "display" : "education unit",
    "definition" : "education unit",
    "designation" : [{
      "language" : "da",
      "value" : "uddannelsesenhed"
    }]
  }]
}

```
