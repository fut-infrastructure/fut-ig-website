# POST Get Report Job Status - eHealth Infrastructure v6.0.0

* [**Table of Contents**](toc.md)
* **POST Get Report Job Status**

## POST Get Report Job Status

`POST [base]/$get-report-job-status`

**Header**

```
Accept-Charset: utf-8
Authorization: Bearer eyJhbGciOiJub25lIn0.eyJ1c2VyX2lkIjoiOTZiYzg5NGEtOGI3Ny00MWYwLTgzNzUtNTE3ZmRmNjM5NDA4IiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInJlcG9ydC1ub24tYW5vbnltaXplZCIsIkJpbmFyeS5yZWFkIl19LCJ1c2VyX3R5cGUiOiJQUkFDVElUSU9ORVIifQ.
Accept: application/fhir+json;q=1.0, application/json+fhir;q=0.9
User-Agent: HAPI-FHIR/6.10.5 (FHIR Client; FHIR 4.0.1/R4; apache)
Accept-Encoding: gzip
Content-Type: application/fhir+json; charset=UTF-8

```

**Body**:

```
{
  "resourceType": "Parameters"
}

```

**Response**

```
{
  "resourceType": "Bundle",
  "type": "collection"
}

```

