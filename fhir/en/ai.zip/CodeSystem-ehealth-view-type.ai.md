# View types - eHealth Infrastructure v11.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **View types**

## CodeSystem: View types 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/view-type | *Version*:11.0.4 |
| Active as of 2021-10-15 | *Computable Name*:ViewType |

 
View types 

This Code system is referenced in the definition of the following value sets:

* [View Type](ValueSet-ehealth-view-type.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-view-type",
  "url" : "http://ehealth.sundhed.dk/cs/view-type",
  "version" : "11.0.4",
  "name" : "ViewType",
  "title" : "View types",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-10-15T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "View types",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "interpretedview",
    "display" : "Interpreted view",
    "definition" : "interpretedView",
    "designation" : [{
      "language" : "da",
      "value" : "Fortolket visning"
    }]
  }]
}

```
