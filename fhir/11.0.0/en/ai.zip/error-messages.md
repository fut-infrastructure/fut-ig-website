# Error Messages - eHealth Infrastructure v11.0.0

* [**Table of Contents**](toc.md)
* **Error Messages**

## Error Messages

* `GENERAL_RESOURCE_NOT_FOUND`: Resource %s with id %s is not found.
* `GENERAL_SUBJECT_AND_CONTEXT_NOT_PROVIDED`: At least one of subject and context must be provided.
* `GENERAL_VALIDATION_ERROR`: Validation error: %s.
* `GENERAL_TIMING_VALIDATION_ERROR`: Timing is invalid for ServiceRequest with id %s and status %s: %s.
* `GENERAL_VALIDATION_ERROR_NO_OCCURRENCE`: Service request with id %s has no occurrence.
* `GENERAL_TIMING_OCCURENCE_WITHOUT_START_VALIDATION_ERROR`: ServiceRequest with id %s not valid with status: %s since occurrence timing has no start date.
* `GENERAL_TRIGGER_ENABLEMENT_VALIDATION_ERROR`: ServiceRequest cannot be changed from %s to %s %s
* `GENERAL_EXPORT_FAILED`: Export resource has failed.
* `GENERAL_CANONICAL_TARGET_NOT_ALLOWED_ERROR`: Unsupported target in canonical: %s
* `GENERAL_NAMING_SYSTEM_NOT_FOUND`: NamingSystem with identifier %s is not found.
* `GENERAL_FIELD_ACCESS_FAILURE`: Failed to access field: %s
* `GENERAL_FIELD_COMPARE_FAILURE`: Failed to compare field: %s

#### ehealth-actionguidanceview

* `ACTIONGUIDANCEVIEW_ILLEGAL_CONTENT_SIZE`: Size of content is greater than the max allowed size. Content size: %s, max size: %s
* `ACTIONGUIDANCEVIEW_ILLEGAL_STATUS_CHANGE`: Illegal status change for action_guidance or view from %s and to %s
* `ACTIONGUIDANCEVIEW_ILLEGAL_CHANGE_OF_ELEMENTS`: Illegal element change in either EHealthActonGuidance or EhealthView. If status is equal to Active or Retired, only the following elements can be changed (Recommendation, IntendedAudience, useContext, modifierrole and status). The following differences were found when updating existing resource with id %s: %s.
* `ACTIONGUIDANCEVIEW_ILLEGAL_PROFILE_CHANGE`: Illegal profile change for resource with id %s: existing profile %s, update profile %s.

#### ehealth-activitydefinition

* `ACTIVITYDEFINITION_UPDATE_ALLOWED_FOR_STATUS`: Update is only allowed for ActivityDefinition with status: %s or %s, otherwise, only useContext can be modified. The following differences were found when updating existing resource with id %s: %s.
* `ACTIVITYDEFINITION_UPDATE_ALLOWED_FOR_USECONTEXT_STATUS`: Updating ActivityDefinition with/to status %s is not allowed when modifying fields other than useContext. The following differences were found when updating existing resource with id %s: %s.
* `ACTIVITYDEFINITION_UPDATE_TO_NOT_ALLOWED_STATE`: Update is not allowed for ActivityDefinition with %s status to different than %s status.
*  

| | |
| :--- | :--- |
| `ACTIVITYDEFINITION_SHARINGAPPROVALPOLICY_NOT_ALLOWED`: Resource %s does not allow SharingApprovalPolicy to be set with code: %s | %s. |

 
*  

| | |
| :--- | :--- |
| `ACTIVITYDEFINITION_SHARINGAPPROVALPOLICY_NOT_SET`: Resource %s with code: %s | %s must have SharingApprovalPolicy set. |

 
* `ACTIVITYDEFINITION_CREATE_MODIFIER_ROLE_OWNER_MANDATORY`: Modifier role owner is mandatory
* `ACTIVITYDEFINITION_BODYSITE_MISMATCH`: Body Site mismatch: Codes in .bodysite [%s] must match body-site codes in .useContext [%s]

#### ehealth-appointment

* `APPOINTMENT_LISTENER_APPOINTMENT_MISSING_CAREPLAN`: Appointment has no CarePlan

#### ehealth-assembler

* `ASSEMBLER_QRD_FOUND_NON_OR_SEVERAL_MATCHES_FOR_QFDD_DOCUMENT_REFERENCE`: Found non or more than 1 match for QFDD DocumentReference. Identifier: system: %s, value: %s.
* `ASSEMBLER_QRD_NOT_ABLE_TO_DETERMINE_QFDD_REFERENCE`: Not able to determine QFDD reference from questionnaire.identifier. Non or more than 1 identifier system starting with 'urn:oid'. Questionnaire: %s.
* `ASSEMBLER_QRD_QR_SOURCE_IS_UNSUPPORTED`: QuestionnaireResponse with id: '%s' has source '%s', which is not supported - Skipping publication
* `ASSEMBLER_QRD_QR_AUTHOR_RESOURCE_NOT_FOUND`: QuestionnaireResponse with id: '%s', no resource found for author reference '%s' - Skipping publication
* `ASSEMBLER_APD_MISSING_SUPPORTING_INFORMATION`: Appointment must have supportingInformation
* `ASSEMBLER_APD_MISSING_PATIENT_PARTICIPANT`: Appointment must have at least one Patient participant
* `ASSEMBLER_APD_MISSING_RESPONSIBLE_ORGANIZATION`: Appointment must have responsible-organization
* `ASSEMBLER_APD_MISSING_PERFORMER`: Appointment must have performer
* `ASSEMBLER_APD_MISSING_RESPONSIBLE_PRACTITIONER`: Appointment must have responsible Practitioner
* `ASSEMBLER_APD_MISSING_PATIENT_CPR`: Patient has no CPR number
* `ASSEMBLER_PHMR_UNKNOWN_AUTHOR_TYPE`: Unknown author type:

#### ehealth-assigned

* `ASSIGNED_MATERIAL_COUNT_DOCUMENT_REFERENCE_PARAMETER_MANDATORY`: The 'ehealth-documentReference' parameter is mandatory and must refer to a general-material DocumentReference from the Plan service
* `ASSIGNED_MATERIAL_COUNT_STATUS_PARAMETER_MANDATORY`: The 'status' parameter is mandatory

#### ehealth-careplan

* `CAREPLAN_APPLY_NO_PLANDEFINITION`: There is no PlanDefinition with id %s
* `CAREPLAN_APPLY_NOT_ACTIVE_PLANDEFINITION`: The apply operation can only be performed on Plandefinitions with status "active"
* `CAREPLAN_APPLY_EPISODE_OF_CARE_REFERENCE_NOT_SPECIFIED`: EpisodeOfCare reference must be specified
* `CAREPLAN_APPLY_PLAN_DEFINITION_REFERENCE_NOT_SPECIFIED`: PlanDefinition reference must be specified
* `CAREPLAN_APPLY_CAN_NOT_FIND_ACTIVITY_DEFINITION`: Can not find activity definition with id :%s
* `CAREPLAN_APPLY_NO_SUITABLE_DIAGNOSIS`: Applying plan failed as no suitable diagnosis found from EpisodeOfCare with id %s when applying PlanDefinition with id %s. Conditions with status: [%s] are ignored
* `CAREPLAN_NOT_FOUND`: CarePlan is not found.
* `CAREPLAN_SEARCH_SUBJECT_CONTEXT_OR_RESPONSIBLE_ACTOR_IS_NOT_SPECIFIED`: At least subject, context or responsible actor must be specified
* `CAREPLAN_SERVICEREQUEST_CREATE_OUTSIDE_APPLY`: ServiceRequest can only be created by applying a plan
* `CAREPLAN_SERVICEREQUEST_PERFORMER_RELATED_PERSON_OUTSIDE_PERIOD`: ServiceRequest.performer refers to RelatedPerson %s whose period does not include the current date
*  

| | |
| :--- | :--- |
| `CAREPLAN_SERVICEREQUEST_PERFORMER_RELATED_PERSON_NOT_MANAGED`: ServiceRequest.performer refers to RelatedPerson %s which is not tagged with meta.security %s | %s |

 
* `CAREPLAN_SERVICEREQUEST_PERFORMER_RELATED_PERSON_PATIENT_MISMATCH`: ServiceRequest.performer refers to RelatedPerson %s with patient %s, which differs from ServiceRequest.subject %s

#### ehealth-careteam

* `CARETEAM_GENERAL_EXTERNAL_SECURITY_TOKEN_CARETEAM_IDENTIFIER_SYSTEM_IS_MISSING`: The CareTeam must contain an identifier using system "urn:ietf:rfc:3986"

#### ehealth-cda

* `CDA_XML_VALIDATION_FAILED`: Validation of the CDA XML failed: %s

#### ehealth-clinical

* `CLINICAL_IMPRESSION_VALIDATION_STATE_FINDING_CODE_NOT_ALLOWED`: Invalidation/Invalidation Retraction finding code is not allowed for ClinicalImpression outside custom operation.
* `CLINICAL_IMPRESSION_MEASUREMENT_VALIDITY_UPDATED_CODE_REQUIRED`: ClinicalImpressions for Invalidation/Invalidation Retraction must have ClinicalImpression.code=MeasurementValidityUpdated

#### ehealth-codesystem

* `CODESYSTEM_CONCEPT_CHANGE_NOT_ALLOWED_WHEN_ACTIVE`: Not allowed to remove or update concept when status is active.

#### ehealth-communicationrequest

* `COMMUNICATIONREQUEST_CONTEXT_NOT_MATCHING_SERVICEREQUEST`: The context for the CommunicationRequest: %s does not match the context of the referenced ServiceRequest: %s
* `COMMUNICATIONREQUEST_SUBJECT_NOT_MATCHING_RECIPIENT`: Patient recipient: %s does not match the subject: %s
* `COMMUNICATIONREQUEST_SUBJECT_NOT_MATCHING_SERVICEREQUEST`: The subject for the CommunicationRequest: %s does not match the subject of the referenced ServiceRequest: %s
* `COMMUNICATIONREQUEST_EXCACTLY_ONE_RECIPIENT_SEARCHPRARAM`: Exactly one recipient search parameter required
* `COMMUNICATIONREQUEST_NO_SYSTEM_TAGS_WITHOUT_EOC`: CommunicationRequest must have a system tags when referencing an EpisodeOfCare

#### ehealth-context

* `CONTEXT_VALIDATION_EPISODEOFCARE_EXCEPTION`: Episode of care does not match the security token context

#### ehealth-definition

* `DEFINITION_WITHOUT_SELF_TREATMENT_TOPIC`: %s has to be with self-treatment topic

#### ehealth-device

* `DEVICE_WRITE_WRONG_PATIENT_CONTEXT`: User with patient context can only read devices that has been issued to the patient
* `DEVICE_WRITE_WRONG_ORGANIZATION_CONTEXT`: User must be logged into the organization that is the owner of the device
* `DEVICE_METRIC_WRITE_WRONG_ORGANIZATION_CONTEXT`: User must be logged into the organization that is the owner of the device
* `DEVICE_USE_STATEMENT_WRITE_WRONG_ORGANIZATION_CONTEXT`: User must be logged into the organization that is the owner of the device
* `DEVICE_WRONG_PATIENT_CONTEXT`: User with patient context can only interact with devices that has been issued to the patient or not issued to anyone yet
* `DEVICE_WRITE_NON_PRIVATELY_OWNED`: Patient user can only create/update privately owned devices
* `DEVICE_USE_STATEMENT_MISSING_CONTEXT`: DeviceUseStatement.context must reference a valid CarePlan when referred Device is not smartphone.

#### ehealth-document

* `DOCUMENT_REFERENCE_MISSING_URL`: DocumentReference to update must contain an URL identifying the content.
* `DOCUMENT_REFERENCE_CONTENT_MANDATORY`: DocumentReference for material must contain exactly one content
* `DOCUMENT_REFERENCE_INVALID_CONTENT_ON_UPDATE`: When updating registration of DocumentReference for material, data is only allowed for URLs identifying internal content.
* `DOCUMENT_REFERENCE_INVALID_CONTENT_ON_CREATE`: When registering a new DocumentReference for material, either a URL identifying external content, a URL identifying internal content or data in the Attachment must be provided.
* `DOCUMENT_REFERENCE_INVALID_CONTENT_ORIGIN_UPDATE`: It is not allowed to change the content origin from internal to external or vice versa.
* `DOCUMENT_REFERENCE_INVALID_CONTENT_DATA_EXTERNAL_ORIGIN`: It is not allowed to have data in the content attachment when the URL is external.
* `DOCUMENT_REFERENCE_UPDATE_NOT_ALLOWED_FOR_FIELD`: DocumentReference for material does not allow update operations with changes for field: %s
* `DOCUMENT_REFERENCE_SIZE_MUST_BE_PROVIDED_FOR_URL`: When providing URL instead of data for content, DocumentReference.attachment.size must be provided (number of bytes of content).
* `DOCUMENT_NOT_OF_TYPE_QFDD`: The document is expected to be of type QFDD
* `DOCUMENT_QUERY_SOR_ORGANIZATION_REQUIRED`: Security token organization context must be resolvable to a SOR identifier for query
* `DOCUMENT_QUERY_XDS_ERROR`: The following errors where received from Document Sharing
* `DOCUMENT_QUERY_DOCUMENT_URL_NOT_CORRECT_FORMAT`: Url doesn't have expected format: __
* `DOCUMENT_QUERY_DOCUMENT_NOT_VALID_TYPE`: Requested document type is not valid. The requested type was %s, but the operation only supports %s
* `DOCUMENT_QUERY_DOCUMENT_NOT_VALID_XML`: Retrieved document is not valid XML
* `DOCUMENT_QUERY_REASON_NOT_PRESENT_WHEN_CONSENT_OVERRIDDEN`: Reason is mandatory when the consent is overridden

#### ehealth-documentreference

* `DOCUMENTREFERENCE_SUBJECT_REFER_TO_PATIENT`: It is not possible to set a patient as a subject for a Document reference
* `DOCUMENTREFERENCE_EPISODEOFCARE_CONTEXT_ENCOUNTER`: DocumentReference for general material must not contain references to EpisodeOfCare in context.encounter
* `DOCUMENTREFERENCE_STORAGE_SERVICE_UPLOAD_ERROR`: Failed to upload material: Invalid response from storage service
* `DOCUMENTREFERENCE_SUBJECT_MANDATORY`: DocumentReference.subject is mandatory, but is not set
* `DOCUMENTREFERENCE_ENCOUNTER_MANDATORY`: DocumentReference.context.encounter must have exactly one reference
* `DOCUMENTREFERENCE_URL_CHANGED`: The contents attachment.url cannot be changed. The url was: %s, but the new url is: %s
* `DOCUMENTREFERENCE_INTERNAL_URL_NO_CONTENT`: No content found at internal URL: %s
* `DOCUMENTREFERENCE_INTERNAL_URL_REGISTRATION_MUST_MATCH_CONTENT`: DocumentReference.context.encounter and DocumentReference.subject must match EpisodeOfCare and Patient for content at internal URL: %s
* `DOCUMENTREFERENCE_PATIENT_MATERIAL_NOT_ALLOWED`: It is not possible to create or update a DocumentReference for patient-specific material on this service.
* `DOCUMENTREFERENCE_EXTERNAL_URL_NOT_ALLOWED`: It is not allowed to set an external url for patient-specific material
* `DOCUMENTREFERENCE_INVALID_CITIZEN_SPECIFIC_DATA`: When the content is patient-specific material, either an internal content URL or data must be provided
* `DOCUMENTREFERENCE_NOT_CITIZEN_SPECIFIC`: Patient-specific material must use the correct category code, but is: %s

#### ehealth-episodeofcare

* `EPISODEOFCARE_CREATE_WRONG_EOC_COUNT`: Bundle has to contain only one Episode of Care
* `EPISODEOFCARE_CREATE_UNSUPPORTED_RESOURCE_TYPE`: Bundle contains unsupported resource type
* `EPISODEOFCARE_CREATE_INCORRECT_PROVENANCE_TARGET`: Provenance has incorrect target
* `EPISODEOFCARE_CREATE_NO_REQUIRED_PROVENANCE_POLICIES`: No provenance with required policies
* `EPISODEOFCARE_CREATE_INCORRECT_CONDITION_SUBJECT`: EpisodeOfCare and Condition doesn't point to the same Patient
* `EPISODEOFCARE_CREATE_MISSING_COEXISTENCE_TAGS`: Missing coexistence-tags in JWToken when creating EpisodeOfCare
* `EPISODEOFCARE_CREATE_INVALID_COEXISTENCE_TAGS`: Invalid Conditions provided when creating EpisodeOfCare using coexistence-tags: %s
* `EPISODEOFCARE_PATCH_NO_CONSENT`: No valid Episode Of Care related consent
* `EPISODEOFCARE_PATCH_DIAGNOSIS_REMOVAL_NOT_ALLOWED`: It is not allowed to remove diagnosis(condition) from an episodeOfCare
* `EPISODEOFCARE_CREATE_PATIENT_MUST_NOT_BE_DECEASED`: Patient.deceased must be false to create episode of care
* `EPISODEOFCARE_CREATE_STATUS_HISTORY_NOT_EMPTY`: It is not allowed to fill status history manually
* `EPISODEOFCARE_CREATE_EPISODE_OF_CARE_IN_NON_PLANNED_STATUS`: It is only possible to create an episode of care in status 'Planned'
* `EPISODEOFCARE_CREATE_TEAM_HISTORY_NOT_EMPTY`: It is not allowed to fill team history manually
* `EPISODEOFCARE_CREATE_PATIENT_DOESNT_MATCH_CONTEXT`: Episode of care patient doesn't match to the context
* `EPISODEOFCARE_IS_CONTEXT_ALLOWED_MATCH_NOT_FOUND`: It is not possible to set the Episode Of Care as a context
* `EPISODEOFCARE_CROSS_TEAM_SEARCH_INVALID_CONDITION_PARAMETER`: When using cross-team search on EpisodeOfCare, Condition parameter must use the Condition:code chained property
* `EPISODEOFCARE_CROSS_TEAM_SEARCH_CONDITION_INVALID_AGAINST_TREATMENT_AREA`: Condition:code search parameter must be valid against treatment area determined by coexistence-tag: %s
* `EPISODEOFCARE_RESOLVE_MANAGING_ORGANIZATION_REFERENCE_MISSING`: A reference to the organisation to resolve must be provided in the 'organization' parameter
* `EPISODEOFCARE_RESOLVE_MANAGING_ORGANIZATION_NO_AUTHORITY`: No data-controller authority (municipality or region) could be resolved for organisation: %s
* `EPISODEOFCARE_MANAGING_ORGANIZATION_MISSING_START`: A data controller (ehealth-managing-organization) must have a period start date
* `EPISODEOFCARE_MANAGING_ORGANIZATION_END_BEFORE_START`: A data controller period end date must not be before its start date
* `EPISODEOFCARE_MANAGING_ORGANIZATION_HISTORICAL_IMMUTABLE`: A historical data controller (its period has already ended) cannot be modified or removed
* `EPISODEOFCARE_MANAGING_ORGANIZATION_CURRENT_MODIFICATION_NOT_ALLOWED`: A current data controller can only be closed by setting an end date; it cannot be removed, reopened, or have its organisation or start date changed
* `EPISODEOFCARE_MANAGING_ORGANIZATION_CURRENT_END_IN_PAST`: A current data controller can only be closed with an end date of today or later
* `EPISODEOFCARE_MANAGING_ORGANIZATION_BACKDATED_ADD_NOT_ALLOWED`: A data controller whose period has already ended cannot be added
* `EPISODEOFCARE_MANAGING_ORGANIZATION_CONTINUITY_GAP`: Data controller assignments must be continuous; the resulting periods leave a gap with no active data controller
* `EPISODEOFCARE_MANAGING_ORGANIZATION_REQUIRED`: An EpisodeOfCare must have at least one data controller (ehealth-managing-organization)

#### ehealth-library

* `LIBRARY_EVALUATE_NO_INPUT_PARAMETER`: An input parameter of type Parameters should be provided.
* `LIBRARY_EVALUATE_INCORRECT_INPUT_PARAMETER`: Input parameter 'parameters' should contain exactly one resource of type QuestionnaireResponse, Observation or Media.
* `LIBRARY_EVALUATE_NO_RULE_DEFINED`: Library with id %s do not contain a rule to use for evaluation.
* `LIBRARY_EVALUATE_NO_CAREPLAN_REFERENCING_PROVIDED_PROCEDUREQUEST`: CarePlan with reference to ServiceRequest with id %s is not found.
* `LIBRARY_EVALUATE_NO_AGGREGATING_PROVENANCE_TARGETING_PROVIDED_RESOURCE`: Aggregate Provenance targeting factResolvingResource with id %s is not found.
* `LIBRARY_EVALUATE_RULE_SYNTAX_ERRORS`: Syntax for rule is invalid. %s
* `LIBRARY_EVALUATE_OUTPUT_PARAMETER_NOT_SUPPORTED`: Output parameter of type %s is not supported.
* `LIBRARY_EVALUATE_INPUT_PARAMETER_NOT_SUPPORTED`: Input parameter of type %s is not supported.
* `LIBRARY_EVALUATE_UNEXPECTED_LIBRARY`: Evaluate is invoked on Library with id %s. This Library is not the expected Library referenced by the ActivityDefinition.
* `LIBRARY_EVALUATE_UNABLE_TO_RESOLVE_RESOURCE`: Not able to resolve %s when input is of type %s.
* `LIBRARY_EVALUATE_UNABLE_TO_RESOLVE_HISTORICAL_RESOURCE`: Not able to resolve historical %s when input is of type %s.
* `LIBRARY_EVALUATE_DURATION_UNIT_CODE_UNKNOWN`: Unsupported code %s for Duration.code. Duration.code should be a valid UCUM code. Supported codes are ('s', 'min', 'h', 'd', 'wk', 'mo', 'a').
* `LIBRARY_EVALUATE_LOGIC_RULE_INVALID_INPUT`: Error evaluating logic rule. Category: %s, Focus: %s, RuleDescription: %s
* `LIBRARY_IDENTIFIER_UPDATE_RESTRICTED`: Validation error: attempt to update Library Identifiers list.
* `LIBRARY_UNKNOWN_IDENTIFIER`: Unable to find unique Library with identifier: %s and name: %s. Number of search results: %s
* `LIBRARY_MISSING_IDENTIFIER`: Library with identifier: %s and name: %s does not have identifier of type: %s
* `LIBRARY_EVALUATE_LIMIT_EXCEEDED`: Limit %s exceeds the maximum allowed soft limit of %s. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_SORT_PATH_NOT_RECOGNIZED`: Sort path %s is not recognized. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_SORT_DIRECTION_NOT_RECOGNIZED`: Sort direction %s is not recognized. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_SORT_EMPTY`: Sort path is empty. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_LIMITS_EXCEEDED`: Duration %s exceeds the maximum allowed duration of %s months or limit %s exceeds the maximum allowed soft limit of %s. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_MISSING_DURATION_OR_LIMIT`: Duration or limit not set. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_DATE_FILTER_PATH_NOT_RECOGNIZED`: DateFilter path %s is not recognized. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_DATE_FILTER_EMPTY`: DateFilter path is empty. Historical data will not be processed for library %s
* `LIBRARY_EVALUATE_INCORRECT_REFERENCE_TARGETED_BY_AGGREGATING_PROVENANCE`: Reference %s targeted by aggregating Provenance should be of type QuestionnaireResponse, Observation or Media.

#### ehealth-material

* `MATERIAL_COMMUNICATION_MISSING_PAYLOAD`: Expected a single payload entry on MaterialCommunication, but it is missing.
* `MATERIAL_COMMUNICATION_MISSING_EPISODE_OF_CARE`: Missing EpisodeOfCare reference on MaterialCommunication
* `MATERIAL_COMMUNICATION_PATIENT_MISMATCH_ON_EPISODEOFCARE`: Mismatch between Patient on MaterialCommunication and EpisodeOfCare. Subject on MaterialCommunication: %s, Patient on EpisodeOfCare: %s
* `MATERIAL_COMMUNICATION_EPISODE_OF_CARE_MISMATCH_ON_CONTENT`: Mismatch between EpisodeOfCare on MaterialCommunication and DocumentReference content. EpisodeOfCare on MaterialCommunication: %s, EpisodeOfCare on DocumentReference content: %s
* `MATERIAL_COMMUNICATION_PATIENT_MISMATCH_ON_CONTENT`: Mismatch between Patient on MaterialCommunication and DocumentReference content. Patient on MaterialCommunication: %s, Patient on DocumentReference content: %s
* `MATERIAL_COMMUNICATION_UNABLE_TO_FIND_CONTENT`: Unable to find content for DocumentReference with id %s
* `MATERIAL_COMMUNICATION_UPDATE_NOT_ALLOWED_FOR_FIELD`: MaterialCommunication does not allow update operations with changes for field: %s
* `MATERIAL_COMMUNICATION_SUBJECT_AND_RECIPIENT_MISMATCH`: MaterialCommunication subject must also be the recipient.

#### ehealth-measurement

* `MEASUREMENT_SEARCHMEASUREMENT_PERIOD_NOT_SPECIFIED`: Period must be specified
* `MEASUREMENT_SEARCHMEASUREMENT_PATIENT_AND_EPISODE_NOT_SPECIFIED`: At least patient or episodeOfCare must be specified
* `MEASUREMENT_SEARCHMEASUREMENT_PATIENT_AND_EPISODE_AND_SERVICEREQUEST_NOT_SPECIFIED`: At least one patient, episodeOfCare or serviceRequest must be specified
* `MEASUREMENT_SEARCHMEASUREMENT_COUNT_NOT_SPECIFIED`: A positive number for Count must be specified
* `MEASUREMENT_SEARCHMEASUREMENT_COUNT_LIMIT_EXCEEDED`: Count limit of 100 exceeded
* `MEASUREMENT_SEARCHMEASUREMENT_START_OR_END_NOT_SPECIFIED`: Either start or end must be provided, but none was provided
* `MEASUREMENT_SEARCHMEASUREMENT_START_AND_END_BOTH_SPECIFIED`: Both start and end cannot be specified
* `MEASUREMENT_SEARCHMEASUREMENT_UNSUPPORTED_REFERENCE`: Unsupported resource reference, expected %s but was %s
* `MEASUREMENT_SEARCHMEASUREMENT_UNSUPPORTED_DEVICE_REFERENCE`: Unsupported device reference
* `MEASUREMENT_SEARCHMEASUREMENT_UNSUPPORTED_BASEDON_REFERENCE`: Unsupported based-on reference: %s
* `MEASUREMENT_SEARCHMEASUREMENT_REFERENCED_RESOURCE_NOT_FOUND`: Referenced resource not found: %s
* `MEASUREMENT_SUBMITMEASUREMENT_INVALID_OBSERVATION_CODE`: Observation.code does not match the code of the referenced ServiceRequest with id %s.
* `MEASUREMENT_SUBMITMEASUREMENT_INVALID_QUESTIONNAIRE_REFERENCE`: Questionnaire reference with id %s is unexpected. Expected questionnaire reference to match questionnaire reference of related ActivityDefinition with id %s.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_SHOULD_REFERENCE_PATIENT`: Input resources of type EHealthObservation, EHealthMedia and EHealthQuestionnaireResponse should reference a patient.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_SHOULD_REFERENCE_EPISODEOFCARE`: Input resources of type EHealthObservation, EHealthMedia and EHealthQuestionnaireResponse should reference an episode of care.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_SHOULD_REFERENCE_RELATEDPERSON`: Measurements submitted by a related person on behalf of a patient should reference the related person
* `MEASUREMENT_SUBMITMEASUREMENT_EMPTY_INPUT_BUNDLE`: The input bundle does not contain any resources.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_BUNDLE_CONTAINS_NONE_OF_EXPECTED_RESOURCES`: The input bundle does not contain any resources of type EHealthObservation, EHealthMedia, EHealthQuestionnaireResponse.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_BUNDLE_CONTAINS_INVALID_RESOURCES`: The input bundle contains resources which are not of type EHealthObservation, EHealthMedia, EHealthQuestionnaireResponse or EHealthProvenance.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_INVALID_POLICY`: Submitted provenances should use the policy 'Reuse of measurement chosen by citizen'
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_REFERENCE_MISSING`: EHealthProvenance resource is referencing %s but it is not provided as part of the input.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_NOT_SINGLE_TARGET`: Provenance.target should have exactly one reference.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_TARGET_AND_ENTITY_SHOULD_BE_SAME_TYPE`: Provenance.target and Provenance.entity should be of same type.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_TARGET_AND_ENTITY_SHOULD_REFERENCE_SAME_PATIENT`: Provenance.target and Provenance.entity should reference the same patient
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_TARGET_AND_ENTITY_SHOULD_USE_SAME_DATE`: Provenance.target and Provenance.entity should use the same date.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_ENTITY_IS_REUSING`: Provenance.entity is reusing another measurement and thus can not be used for reuse.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_INVALID`: %s is invalid.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_PROVENANCE_NOT_SINGLE_ENTITY`: Provenance.entity should have exactly one reference.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_FOR_DIFFERENT_PATIENTS`: The resources provided are for different patients.
* `MEASUREMENT_SUBMITMEASUREMENT_INPUT_NOT_PART_OF_SAME_EPISODEOFCARE`: The resources provided are not all part of the same episode of care.
* `MEASUREMENT_SUBMITMEASUREMENT_PROCEDURE_REQUEST_IS_NOT_ACTIVE`: Procedure request with id:[%s] is not active.
* `MEASUREMENT_SUBMITMEASUREMENT_ACTIVITYDEFINITION_MISSING_QUESTIONNAIRE_REFERENCE`: ActivityDefinition with id %s does not contain a relatedArtifact with a Questionnaire reference
* `MEASUREMENT_SUBMITMEASUREMENT_DIFFERENT_PATIENT_REFERENCE`: The patient referenced by the EpisodeOfCare is different than the patient referenced by the provided resources
* `MEASUREMENT_SUBMITMEASUREMENT_REUSE_NOT_ALLOWED`: Reuse of resource with id %s is not allowed.
* `MEASUREMENT_SUBMITMEASUREMENT_ASSOCIATED_QUALITY_NOT_PRESENT`: Associated quality %s is not present on submitted resource. Reuse of resource is not allowed.
* `MEASUREMENT_SUBMITMEASUREMENT_QUALITY_IS_NOT_SUBSUMED`: Quality %s does not subsume %s. Reuse of resource is not allowed.
* `MEASUREMENT_SUBMITMEASUREMENT_RESOURCE_TO_OLD_TO_BE_USED_FOR_REUSE`: Reuse of resource is not allowed due to the resource being too old.
* `MEASUREMENT_SUBMITMEASUREMENT_DURATION_UNIT_CODE_UNKNOWN`: Unsupported code %s for Duration.code. Duration.code should be a valid UCUM code. Supported codes are ('s', 'min', 'h', 'd', 'wk', 'mo', 'a').
* `MEASUREMENT_SUBMITMEASUREMENT_MORE_THAN_ONE_DEVICE_QUALITY`: Only one device quality allowed for each observation/media
* `MEASUREMENT_SUBMITMEASUREMENT_INVALID_RESOLVED_TIMING`: ResolvedTiming must have either type=Resolved and start/end or type=Unresolved/Adhoc/Extra and no start/end
* `MEASUREMENT_SUBMITMEASUREMENT_TOO_MANY_ANSWERS`: QuestionnaireResponse: %s has too many answers for the item with linkId: %s
* `MEASUREMENT_SUBMITMEASUREMENT_SERVICEREQUEST_NOT_MARKED_FOR_AGGREGATION`: The PlanDefinition was not marked for Aggregation
* `MEASUREMENT_SUBMITMEASUREMENT_INVALID_RESOURCE_FOR_AGGREGATION`: Unexpected resource of type %s found in the input bundle for aggregation
* `MEASUREMENT_SUBMITMEASUREMENT_TOO_FEW_ANSWERS`: QuestionnaireResponse: %s has too few answers for the item with linkId: %s
* `MEASUREMENT_GET_DATA_NO_DATA_FOUND`: Media data with id %s was not found
* `MEASUREMENT_GET_THUMBNAIL_DATA_NO_DATA_FOUND`: Media thumbnail data with size %d for id %s was not found
* `MEASUREMENT_GET_THUMBNAIL_DATA_NOT_SUPPORTED`: Media thumbnail data for id %s is not supported
* `MEASUREMENT_SUBMITMEASUREMENT_INVALID_STATUS`: Measurement status %s is invalid. Status must be %s for measurement of type %s

#### ehealth-observation

* `OBSERVATION_MEDIA_NOT_SUPPORTED_MESSAGE`: Measurement was of media type. This was not translated to an observation since it is not supported in FHIR

#### ehealth-organization

* `ORGANIZATION_SOURCE_MUST_BE_MANUAL`: The operation can only be performed for Organization with source "manual"
* `ORGANIZATION_IDENTIFIER_MUST_BE_SSL_WHEN_SOURCE_MANUAL`: The operation can only be performed for SSL Organizations when the source is "manual"
* `ORGANIZATION_IDENTIFIER_NOT_UNIQUE`: Organization Identifier not unique: %s
* `ORGANIZATION_IDENTIFIER_SYSTEM_NOT_ALLOWED_FOR_SOURCE_MANUAL`: Identifier system is not allowed for Organization with source "manual"
* `ORGANIZATION_TRAVERSE_TO_SOR_NOT_POSSIBLE`: No related SOR organization could be found for: %s
* `ORGANIZATION_IDENTIFIER_MUST_CONTAIN_AT_LEAST_CVR_FOR_SOURCE_MANUAL`: Identifier system CVR required for Organization with source "manual"
* `ORGANIZATION_UNKNOWN_IDENTIFIER`: Unable to find unique Organization with identifier: %s. Number of search results: %s
* `ORGANIZATION_MISSING_IDENTIFIER`: Organization %s does not have identifier of type: %s
* `ORGANIZATION_REFERENCE_IDENTIFIER_MISSING_PROVIDER_NUMBER`: There are no identifiers of type ProviderNumber in the Organization reference list: %s
* `ORGANIZATION_REFERENCE_IDENTIFIER_PROVIDER_NUMBER_NOT_UNIQUE`: The identifiers of type ProviderNumber are not unique in the Organization reference list: %s
* `ORGANIZATION_NOT_FOUND`: No Organization could be found for the ProviderNumber: %s
* `ORGANIZATION_INVALID_PROVIDER_NUMBER`: Invalid ProviderNumber: %s

#### ehealth-plandefinition

* `PLANDEFINITION_UPDATE_ALLOWED_FOR_STATUS`: Update is only allowed for PlanDefinition with status: %s or %s, otherwise, only useContext can be modified. The following differences were found when updating existing resource with id %s: %s.
* `PLANDEFINITION_UPDATE_ALLOWED_FOR_USECONTEXT_STATUS`: Updating PlanDefinition with/to status %s is not allowed when modifying fields other than useContext. The following differences were found when updating existing resource with id %s: %s.
* `PLANDEFINITION_UPDATE_TO_NOT_ALLOWED_STATE`: Update is not allowed for PlanDefinition with %s status to different than %s status.
* `PLANDEFINITION_VALIDATE_MANDATORY_ACTIVITYDEFINITION_OR_SUBPLAN_REFERENCE`: At least one activity definition or subplan should be referenced.
* `PLANDEFINITION_VALIDATE_ALL_REFERENCED_ACTIVITYDEFINITIONS_OR_SUBPLANS_SHOULD_BE_ACTIVE`: All referenced activity definitions or subplans should be with state: "active"
* `PLANDEFINITION_MISSING_RELATED_ACTION`: An action points to a non-existing related action
* `PLANDEFINITION_CREATE_MODIFIER_ROLE_OWNER_MANDATORY`: Modifier role owner is mandatory
* `PLANDEFINITION_AGGREGATE_GROUP_ID_MANDATORY`: Aggregate group id is mandatory for the following resources: %s
* `PLANDEFINITION_AGGREGATION_RULE_CONSTRAINTS`: There are aggregation rule constraints violations: %s

#### ehealth-provenance

* `PROVENANCE_NO_READ_PRIVILEGE`: User must be logged in with the provenance read privilege
* `PROVENANCE_NO_SEARCH_PRIVILEGE`: User must be logged in with the provenance search privilege
* `PROVENANCE_SEARCH_DATA_NOT_MATCH_CONTEXT`: The target property should match to the episode of care in context

#### ehealth-qfdd

* `QFDD_DISPLAY_ITEM_MUST_HAVE_A_TEXT`: Display item must have a text. LinkId: %s
* `QFDD_NARRATIVE_MISSING_EXTENSION_ERROR`: Information section does not have a rendering-xhtml extension. LinkId: %s

#### ehealth-questionnaire

* `QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_EMPTY_PERIOD`: QuestionnaireResponse cannot have an effectivePeriod without start or end DateTimeType.
* `QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_INVALID_DATETIME`: QuestionnaireResponse has invalid DateTimeType on effectivePeriod.%s, must have minutes, seconds or millis precision and must have a timezone.
* `QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_START_AFTER_END`: QuestionnaireResponse has invalid effectivePeriod, effectivePeriod.start must be before effectivePeriod.end
* `QUESTIONNAIRE_UPDATE_ALLOWED_FOR_USECONTEXT_STATUS`: Updating Questionnaire with/to status %s is not allowed when modifying fields other than useContext. The following differences were found when updating existing resource with id %s: %s.
* `QUESTIONNAIRE_NOT_ALLOWED_TO_UPDATE_IN_STATUS`: Update is not allowed for questionnaires with statuses: %s, %s, except for changes to useContext. The following differences were found when updating existing resource with id %s: %s.
* `QUESTIONNAIRE_NOT_ALLOWED_TO_UPDATE_STATUS`: Update is not allowed for questionnaires with %s status to different than %s status.
* `QUESTIONNAIRE_NOT_ALLOWED_TO_DELETE_WITH_STATUS`: Delete only possible for questionnaires with status: %s
* `QUESTIONNAIRE_IMAGE_FORMAT_VALIDATION_MESSAGE`: %s Image in questionnaire item with linkID %s and Binary contentType %s does not match any code in ValueSet: %s
* `QUESTIONNAIRE_IMAGE_SIZE_VALIDATION_MESSAGE`: %s Image in questionnaire item with linkID %s exceeds the maximum size of %s kB
* `QUESTIONNAIRE_QFDD_DOES_NOT_EXIST_IN_DOCUMENT_TRANSFORMATION`: The QFDD with the identifier %s does not exist in document transformation
* `QUESTIONNAIRE_CREATE_MODIFIER_ROLE_OWNER_MANDATORY`: Modifier role owner is mandatory
* `QUESTIONNAIRE_TERMINOLOGY_HELPER_CODE_NOT_FOUND`: Code %s for CodeSystem %s not found
* `QUESTIONNAIRE_TERMINOLOGY_HELPER_CODE_SYSTEM_NOT_FOUND`: Code system not found for url: %s
* `QUESTIONNAIRE_TERMINOLOGY_HELPER_CODE_SYSTEM_FOUND_MORE_THAN_ONE`: Found more than one code system for url: %s

#### ehealth-questionnairelinkage

* `QUESTIONNAIRELINKAGE_ILLEGAL_IDENTIFIER_CHANGE`: Illegal identifier change for QuestionnaireLinkage with id %s. The identifier is assigned by the server at creation and cannot be changed or removed.
* `QUESTIONNAIRELINKAGE_ILLEGAL_STATUS_CHANGE`: Illegal status change for QuestionnaireLinkage from %s to %s
* `QUESTIONNAIRELINKAGE_ILLEGAL_CHANGE_OF_ELEMENTS`: Illegal element change for QuestionnaireLinkage. If status is Active or Retired, only the following elements can be changed (recommendation, intendedAudience, useContext, modifierRole and status). The following differences were found when updating existing resource with id %s: %s.
* `QUESTIONNAIRELINKAGE_ACTIVATION_REQUIRES_QUESTIONNAIRE`: A QuestionnaireLinkage can only be activated when it references at least one questionnaire in the questionnaireLinkageFor extension.
* `QUESTIONNAIRELINKAGE_QUESTIONNAIRE_NOT_FOUND`: The Questionnaire %s referenced by the QuestionnaireLinkage does not exist.
* `QUESTIONNAIRELINKAGE_QUESTIONNAIRE_ILLEGAL_STATUS`: The Questionnaire %s referenced by the QuestionnaireLinkage must have status active or retired, but has status %s.
* `QUESTIONNAIRELINKAGE_ITEM_QUESTIONNAIRE_NOT_IN_FOR`: The item linkage references Questionnaire %s, which is not referenced in the questionnaireLinkageFor extension.
* `QUESTIONNAIRELINKAGE_UNKNOWN_LINKID`: The linkId %s does not exist in Questionnaire %s.
* `QUESTIONNAIRELINKAGE_ILLEGAL_USER_TYPE`: User type %s is not allowed to %s a QuestionnaireLinkage.

#### ehealth-reporting

* `REPORTING_MISSING_INPUT_PARAMETER`: Parameter "%s" is mandatory for report "%s".
* `REPORTING_REPORT_GENERATION_FAILED`: Report generation has failed
* `REPORTING_SYNCHRONOUS_GENERATION_NOT_ALLOWED`: Synchronous generation of the report is not allowed
* `REPORTING_SCHEDULE_NOT_ALLOWED`: Scheduled generation of the report is not allowed
* `REPORTING_EXECUTE_NOT_ALLOWED`: Asynchronous generation of the report is not allowed
* `REPORTING_MUTUALLY_EXCLUSIVE_INPUT_PARAMETER`: Parameters "%s" and "%s" are mutually exclusive for report "%s".

#### ehealth-security

* `SECURITY_TOKEN_CONTEXT_NOT_ALLOWED`: Security token context not allowed: %s
* `SECURITY_TOKEN_INSUFFICIENT_PERMISSION`: Insufficient permission for %s for %s
* `SECURITY_USER_NOT_ALLOWED`: Resource not allowed for user: %s
* `SECURITY_TOKEN_CONTEXT_MISSING`: Security token context missing for user type: %s
* `SECURITY_TOKEN_CONTEXT_MISSING_CONTEXT`: Security token context missing for context type: %s
* `SECURITY_RESOURCE_NOT_MATCHING_TOKEN_CONTEXT`: Resource not matching security token context: %s
* `SECURITY_OPERATION_NOT_ALLOWED_FOR_USER_TYPE`: Operation not allowed for user type: %s
* `SECURITY_OPERATION_NOT_ALLOWED_FOR_USER_TYPE_WITH_ROLE`: Operation not allowed for user type: %s, with the role: %s
* `SECURITY_SEARCH_PARAM_NOT_MATCHING_TOKEN_CONTEXT`: Search parameters not matching security token context: %s
* `SECURITY_SEARCH_PARAMS_MANDATORY`: Search parameters mandatory with current user type and combination of search parameters: %s
* `SECURITY_SEARCH_OPERATION_POST_CONSTRAINT`: Search on %s only supports POST style.
* `SECURITY_PATIENT_MUST_BE_SENDER_ON_COMMUNICATION`: Patient user must be the sender of the communication
* `SECURITY_PARENT_AUTHORITY_MUST_BE_SENDER_ON_COMMUNICATION`: RelatedPerson with contextType parent_authority must be sender of the communication
* `SECURITY_PATIENT_MUST_ASSIGNED_TO_TASK`: Patient user must be explicitly assigned to the Task
* `SECURITY_PARENT_AUTHORITY_MUST_BE_REQUESTER_OF_TASK`: RelatedPerson with contextType parent_authority must be requester of the task
* `SECURITY_MANDATORY_RELATED_PERSON_PATIENTCONTEXT`: The RelatedPerson users patientContext must be explicitly assigned to the Task
* `SECURITY_PARENT_AUTHORITY_MUST_BE_PERFORMER`: RelatedPerson with contextType parent_authority holder must be the performer

#### ehealth-status

* `STATUS_SCHEDULE_IDENTICAL_TIME`: Multiple status changes may not be scheduled to be activated simultaneously

#### ehealth-system

* `SYSTEM_TAG_UNEXPECTED_TAG`: Resource contains system tag(s), which do not match related resource.

#### ehealth-task

* `TASK_INVESTIGATION_ITEM_REFERENCES_MUST_HAVE_VERSION_AND_VERSIONLESS`: Investigation references must have an item with version and one versionless
* `TASK_RESTRICTION_CATEGORY_NONE_CANT_BE_COMBINED`: Restriction category 'None' can't be combined with others
* `TASK_RESTRICTION_CATEGORY_NOT_MATCHING_TOKEN_CONTEXT`: Restriction category '%s' does not match token context
* `TASK_MEASUREMENT_PROCESSING_FAILED`: Measurement processing failed for Provenance %s
* `TASK_AUTOMATED_PROCESSING_RESOURCE_HANDLER_INVALID_JSON`: Unable to parse json string: %s.
* `TASK_AUTOMATED_PROCESSING_INVALID_INPUT_RESOURCE`: Resource of type %s is not a valid input resource.
* `TASK_AUTOMATED_PROCESSING_MISSING_MEASUREMENT_PROCEDURE_REQUEST`: Could not determine if measurement is missing for procedure request: %s.
* `TASK_AUTOMATED_PROCESSING_FAILING_REQUESTS_JOB_TERMINATED`: Limit of %s consecutive failing requests is reached. Scheduled audit job is terminated.
* `TASK_AUTOMATED_PROCESSING_CAREPLAN_NOT_FOUND`: CarePlan is not found when searching by activity: %s.
* `TASK_AUTOMATED_PROCESSING_RULE_OUTPUT_NOT_FOUND`: RuleOutput not found when searching through Task Automated Processing Resource
* `TASK_FOR_NOT_SET`: When episode of care is set, the field 'for' must reference the corresponding patient
* `TASK_MEASUREMENT_VALIDITY_INVALID_MEASUREMENT_REFERENCE`: Expecting ClinicalImpression to include a single Investigations. The investigation must contain two items: one item with an versionless reference and one item with a versioned reference of the Measurement that is being invalidated or retracted.
* `TASK_MEASUREMENT_VALIDITY_INVALID_INVESTIGATION_ITEM_TYPE`: Investigation item type must be of type Media, Observation or QuestionnaireResponse.
* `TASK_MEASUREMENT_VALIDITY_INVALID_FINDING_CODE_ON_PREVIOUS`: Previous ClinicalImpression must be of type 'invalidation' when trying to retract invalidation.
* `TASK_MEASUREMENT_VALIDITY_INVALID_INITIAL_STATUS`: ClinicalImpression for invalidation/retracted invalidation must be created with 'COMPLETED' status.
* `TASK_MEASUREMENT_VALIDITY_INVALID_DECISION_CODE`: ClinicalImpression must contain a single decision, with a single Coding of code 'invalidated-fulfills' or 'invalidated-is-not-fulfillment'.
* `TASK_MEASUREMENT_VALIDITY_INVALID_FINDING_CODE`: ClinicalImpression must contain a single finding, with a single Coding of code 'measurement-invalidated' or 'measurement-invalidation-retracted'.
* `TASK_MEASUREMENT_VALIDITY_REFERENCE_MISMATCH`: Mismatch between references: %s(%s) and %s(%s).
* `TASK_MEASUREMENT_VALIDITY_MISSING_PREVIOUS`: Unable to find previous ClinicalImpression when trying to retract invalidation.
* `TASK_MEASUREMENT_VALIDITY_INVALID_PREVIOUS_EXPECTING_INVALIDATION_RETRACTION`: Previous ClinicalImpression must be of type invalidation retraction when trying to invalidate measurement.
* `TASK_MEASUREMENT_VALIDITY_INVALID_PREVIOUS_EXPECTING_INVALIDATION`: Previous ClinicalImpression must be of type invalidation when trying to retract invalidation for measurement.
* `TASK_MEASUREMENT_VALIDITY_MULTIPLE_PREVIOUS`: Unable to determine previous invalidation/invalidation retracted ClinicalImpression, due to finding multiple candidates for the Measurement.

#### ehealth-transformation

* `TRANSFORMATION_DEPRECATE_DOCUMENT_CPR_DIDNT_MATCH`: Found document didn't match with CPR
* `TRANSFORMATION_DEPRECATE_DOCUMENT_MORE_THAN_ONE_FOUND`: More than 1 DocumentReference with same master identifier found. The master identifier should be unique.
* `TRANSFORMATION_DEPRECATE_DOCUMENT_NO_DOCUMENT_FOUND`: No matching document found
* `TRANSFORMATION_GENERIC_NARRATIVE_ERROR`: Can't generate narrative for: %s
* `TRANSFORMATION_QFDD_UNKNOWN_QUESTION_TYPE`: Unknown QFDD question type. Question id: %s
* `TRANSFORMATION_QFDD_UNSUPPORTED_STRUCTURE`: The root item structure was neither an Information Only Section nor a Question Section. LinkId: %s
* `TRANSFORMATION_QFDD_XML_MISSING`: Invalid input document reference, it must contain content with data of QFDD xml
* `TRANSFORMATION_QFDD_ITEM_WITH_SLIDER_MISSING_STEPVALUE`: Questionnaire item with linkId '%s' has itemControl: 'slider' but has no step value extension.
* `TRANSFORMATION_QFDD_ITEM_WITH_SLIDER_NOT_MATCHING_DISCRETE_SLIDER`: Questionnaire item with linkId '%s' has itemControl: 'slider', but either Repeats is true or MaxOccurs is not null. Repeats was: %s and MaxOccurs was: %s.
* `TRANSFORMATION_QFDD_CODESYSTEM_TITLE_MISSING`: CodeSystem title is missing, for CodeSystem with url: %s
* `TRANSFORMATION_QFDD_QUESTION_NARRATIVE_FILE_TEMPLATE_ERROR`: Template for question section narrative can't be found or written.
* `TRANSFORMATION_QFDD_QUESTION_NARRATIVE_TEMPLATE_SYNTAX_ERROR`: Could not process template for question section narrative due to syntax errors or missing variables
* `TRANSFORMATION_QRD_INVALID_INPUT_PARAMETERS`: Input bundle should contain just one EHealthComposition, EHealthQuestionnaireResponse, EHealthQuestionnaire and DocumentReference(QFDD).
* `TRANSFORMATION_FROM_QRD_INVALID_INPUT_PARAMETERS`: Input bundle should contain just one EHealthQuestionnaire and DocumentReference(QRD).
* `TRANSFORMATION_FROM_QRD_DUPLICATED_EXTERNAL_IDENTIFIER`: Cannot transform from QRD to QuestionnaireResponse. Duplicated external identifiers: %s.
* `TRANSFORMATION_FROM_QRD_EXTERNAL_DOCUMENT_NOT_MATCHING_QFDD_IDENTIFIER_ON_QUESTIONNAIRE`: External Document reference in QRD does not match QFDD identifier on Questionnaire. External Document reference: '%s'. QFDD identifier on Questionnaire: '%s'.
* `TRANSFORMATION_FROM_QRD_NO_EXTERNAL_DOCUMENT_FOUND_IN_QRD`: No External Document reference found in QRD.
* `TRANSFORMATION_FROM_QRD_NO_QFDD_IDENTIFIER_ON_QUESTIONNAIRE`: Questionnaire does not have a QFDD identifier. No identifier with system starting with 'urn:oid'.
* `TRANSFORMATION_FROM_QRD_COULD_NOT_FIND_PARENT_FOR_LINK_ID`: Could not find parent for item with linkId: %s.
* `TRANSFORMATION_FROM_QRD_QRD_HAS_NO_SECTIONS`: QRD has no sections with questions.
* `TRANSFORMATION_FROM_QRD_QRD_QUESTION_TYPE_DOES_NOT_MATCH_QUESTIONNAIRE_ITEM_TYPE`: QRD Question type '%s' does not match questionnaire item type '%s'. LinkId: %s.
* `TRANSFORMATION_QRD_UNSUPPORTED_QUESTION_TYPE`: Unsupported Questionnaire type: '%s'.
* `TRANSFORMATION_QRD_INVALID_NUMBER_OF_ANSWERS`: QuestionnaireResponse item should contain from '%s' to '%s' answers. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_SLIDER_MISMATCH_BETWEEN_TYPE_AND_SLIDER_STEP`: Questionnaire item with linkId '%s' has itemControl: 'slider' and item.type: 'Integer' but has decimal step value: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_INVALID_SLIDER_EXTENSIONS`: Questionnaire item with linkId '%s' has itemControl: 'slider', therefore it must contain at least the following extensions: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_NO_SLIDER_STEP_EXTENSION`: Questionnaire item with linkId '%s' has itemControl: 'slider', therefore it must contain one of the following extensions: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_NO_SLIDER_ITEM_CONTROL_EXTENSION`: Questionnaire item with linkId '%s' has no itemControl extension with code: 'slider'.
* `TRANSFORMATION_QRD_MISSING_IDENTIFIER`: Identifier on composition is mandatory
* `TRANSFORMATION_QRD_XML_MISSING`: Invalid input document reference, it must contain content with data of QRD xml
* `TRANSFORMATION_QRD_EXPECTING_DISPLAY_ITEM_FOR_INFO_SECTION`: QFDD section with title '%s' has no organizers(Information Only Section). Expecting FHIR Questionnaire root group to have exactly one item of display. Found %s items. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_DISPLAY_ITEM_FOR_INFO_SECTION_FOUND_OTHER_TYPE`: QFDD section with title '%s' has no organizers(Information Only Section). Expecting FHIR Questionnaire root group to contain exactly one item of type 'display'. Found item of type: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_DISPLAY_ITEM_FOR_COPYRIGHT_SECTION`: Expecting FHIR Questionnaire root group to have one or more items of type display for structure matching QFDD section with title '%s'. Found %s items. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_DISPLAY_ITEM_FOR_COPYRIGHT_SECTION_FOUND_OTHER_TYPE`: Expecting FHIR Questionnaire root group to contain only sub items of type 'display'. QFDD section with title '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_DISPLAY_ITEM_TO_MATCH_COPYRIGHT_ENTRIES_IN_QFDD`: Expecting FHIR Questionnaire root group to contain the same number of display items as copyright entries in the matching QFDD section. QFDD section with title '%s'. Found %s items, expecting %s items. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_ROOT_GROUP_TO_BE_COPYRIGHT`: Expecting FHIR Questionnaire root group isCopyright to be true as corresponding QFDD section is a copyright section. QFDD section with title '%s'. QuestionnaireResponse: '%s'
* `TRANSFORMATION_QRD_EXPECTING_COPYRIGHT_SUBITEMS_TO_HAVE_IS_COPYRIGHT_TRUE`: Expecting FHIR Questionnaire root group to contain sub items with isCopyright set to true as corresponding QFDD section is a copyright section. QFDD section with title '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_NUMBER_OF_ITEMS_IN_ROOT_GROUP_DOES_NOT_MATCH_NUMBER_OF_ORGANIZERS`: QFDD section with title '%s' has %s organizers. Expect FHIR Questionnaire root group to contain the same number of items with type 'group'. Found: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_ONLY_SUB_GROUPS_IN_ROOT_GROUP`: QFDD section with title '%s' has %s organizers. Expect FHIR Questionnaire root group to contain only items of type: 'group'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_ROOT_ITEM_TO_BE_OF_TYPE_GROUP`: Root item on questionnaire is not of type 'group'. Type was: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_ITEM_TO_BE_OF_TYPE_GROUP`: Item is not of type group. Type: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_NUMBER_OF_ITEMS_ON_ROOT_LEVEL_DOES_NOT_MATCH_NUMBER_OF_SECTIONS`: The number of root items on questionnaire does not match the number of QFDD sections. Questionnaire: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_FOUND_MORE_THAN_ONE_MATCH_FOR_LINKID_IN_QUESTIONNAIRE_RESPONSE`: Found more than 1 match for LinkId in QuestionnaireResponse. LinkId: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECTING_QUESTIONNAIRE_TIEM_TO_HAVE_EXTERNAL_IDENTIFIER`: Expected questionnaireItem to have externalIdentifier: '%s'. But was: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_FOUND_NO_QUESTIONNAIRE_RESPONSE_FOR_ASSOCIATED_TEST_QUESTION`: Found no QuestionnaireResponse for associatedTextQuestion. Found Questionnaire item with linkId: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_PRECONDITION_DO_NOT_MATCH_THE_QUESTION_FOR_ASSOCIATED_TEXT_QUESTION`: The precondition criterion code does not match the expected question code. Expected: '%s'. But was: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_MULTIPLE_CHOICE_ANSWER_EXPECTING_CODING_TYPE_FOR_VALUE`: Expecting answer value to be of type Coding. QuestionResponseItem with linkId: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_PRECONDITION_GROUP_GROUP_TYPE_UNKNOWN`: Unknown GroupType: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_PRECONDITION_MORE_THAN_ONE`: Transformation do not support more than one precondition for associatedTextQuestion. Found '%s'. AssociatedTextQuestion: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_EXPECT_IMAGE_IN_QUESTIONNAIRE_ITEM`: Expecting QuestionnaireItem to have an image as the corresponding QFDD question has an image. Question id: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_NOT_EXPECTING_IMAGE_IN_QUESTIONNAIRE_ITEM`: Not expecting QuestionnaireItem to have an image as the corresponding QFDD question do not have an image. Question id: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_UNKNOWN_QRD_RESPONSE_TYPE`: Unknown QRD response type. QRD Question id: '%s'
* `TRANSFORMATION_QRD_ASSOCIATED_TEXT_QUESTION_ITEM_NOT_OF_TYPE_TEXT_OR_STRING`: AssociatedTextQuestion item with id: '%s' is not of type 'text' or 'string'. Type was: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_QFDD_QUESTION_DOES_NOT_SUPPORT_ASSOCIATED_TEXT_QUESTION`: QFDDQuestion with id: '%s' does not support associatedText. Class was: '%s'. QuestionnaireResponse: '%s'.
* `TRANSFORMATION_QRD_INVALID_QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_MISSING_START`: QuestionnaireResponse with id: '%s' is missing effective period start.
* `TRANSFORMATION_QRD_INVALID_QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_INVALID_START`: QuestionnaireResponse with id: '%s' must have a valid effective period start, including time precision and timezone.
* `TRANSFORMATION_QRD_INVALID_QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_INVALID_END`: QuestionnaireResponse with id: '%s' must have a valid effective period end, including time precision and timezone.
* `TRANSFORMATION_QRD_INVALID_QUESTIONNAIRE_RESPONSE_EFFECTIVE_PERIOD_EQUAL_BOUNDS`: The low and high bounds of the effective period in QuestionnaireResponse with ID '%s' must not be equal.
* `TRANSFORMATION_PHMR_MISSING_RESOURCE`: Input bundle missing resource: %s
* `TRANSFORMATION_HEADER_MISSING_CPR`: CPR is mandatory for patient but not present in fhir bundle
* `TRANSFORMATION_PHMR_MISSING_OBSERVATION`: Observation is mandatory for PHMR
* `TRANSFORMATION_PHMR_INVALID_OBSERVATION_CODING`: Observation coding system must be urn:oid:1.2.208.176.2.1
* `TRANSFORMATION_PHMR_OBSERVATION_QUANTITY_MISSING`: Value should be Quantity type and not null
* `TRANSFORMATION_PHMR_XML_MISSING`: Invalid input document reference, it must contain content with data of PHMR xml
* `TRANSFORMATION_PHMR_ID_OID_NOT_FOUND`: NamingSystem or CodeSystem with url %s is not found.
* `TRANSFORMATION_PHMR_MISSING_MEASUREMENT_IDENTIFIER`: No identifier found for measurement
* `TRANSFORMATION_PHMR_DOCUMENT_TIME_INTERVAL_MISSING`: Document is missing serviceStartTime and serviceStopTime.
* `TRANSFORMATION_PHMR_DOCUMENT_INVALID_EFFECTIVE`: Invalid Observation.effective, expecting DateTime, Period or Instant
* `TRANSFORMATION_PHMR_CODESYSTEM_NOT_FOUND`: CodeSystem was not found. System: '%s'
* `TRANSFORMATION_PHMR_DOCUMENT_OBSERVATION_ENTRY_CODESYSTEM_NAME_NOT_DEFINED`: PHMR document observation entry must have a CodeSystem name. No one defined for '%s'
* `TRANSFORMATION_PHMR_CODE_NOT_FOUND_IN_CODESYSTEM`: Code '%s' was not found in CodeSystem '%s'
* `TRANSFORMATION_PHMR_NO_PHMR_DESIGNATION_FOR_CODE`: Could not find designation use 'phmr-short-name' for code '%s' in CodeSystem '%s'
* `TRANSFORMATION_PHMR_NO_PHMR_DESIGNATION_VALUE_FOR_CODE`: No value specified for designation use 'phmr-short-name'. Code: '%s'. CodeSystem: '%s'
* `TRANSFORMATION_PHMR_MEASUREMENT_INVALID_METHOD_CODES`: Method codes for performerType and provisionMethod for observation with id '%s' could not be established.
* `TRANSFORMATION_PHMR_OBSERVATION_MISSING_UNIT_CODE_FOR_QUANTITY`: No unit code found for quantity with observation code '%s'
* `TRANSFORMATION_PHMR_OBSERVATION_INVALID_UNIT_MAPPING_FOR_OBSERVATION_CODE`: Invalid UCUM unit mapping found for observation code '%s'. Observation has unit: '%s', but expected is one of ('%s')
* `TRANSFORMATION_PHMR_OBSERVATION_MISSING_UNIT_MAPPING_FOR_OBSERVATION_CODE`: No UCUM unit mapping found for observation code '%s' in ConceptMap. Has unit code: '%s'
* `TRANSFORMATION_PHMR_INVALID_COMBINATION_OBSERVATION_UNIT_AND_PHMR_UNIT_PROPERTY`: Invalid combination of observation unit: '%s' and PHMR unit property: '%s'
* `TRANSFORMATION_PHMR_NO_PHMR_UNIT_PROPERTY_FOR_CODE`: Could not find property 'phmr-unit' for code '%s' in CodeSystem '%s'
* `TRANSFORMATION_PHMR_NO_PHMR_UNIT_VALUE_PROPERTY_FOR_CODE`: No value specified for property 'phmr-unit'. Code: '%s'. CodeSystem: '%s'
* `TRANSFORMATION_HEADER_MISSING_CONFIDENTIALITY_CODE`: Composition.confidentiality is mandatory
* `TRANSFORMATION_HEADER_WRONG_TYPE_COMPOSITION_SUBJECT`: Composition.subject should be a Patient
* `TRANSFORMATION_HEADER_MISSING_CUSTODIAN`: Custodian is mandatory for transformation
* `TRANSFORMATION_HEADER_MISSING_COMPOSITION`: Composition expected for transformation is not found
* `TRANSFORMATION_HEADER_MISSING_ATTESTER`: Composition.attester must contain one Practitioner and one Organization if the document is shared manually
* `TRANSFORMATION_HEADER_WRONG_TYPE_COMPOSITION_AUTHOR`: Composition.author should either be a Patient or Practitioner
* `TRANSFORMATION_HEADER_MISSING_COMPOSITION_AUTHOR_ORGANIZATION`: Composition.authorOrganization is mandatory for transformation
* `TRANSFORMATION_HEADER_AUTHOR_ORGANIZATION_MUST_CONTAIN_SOR_ID`: Composition.authorOrganization must contain SOR identifier: %s
* `TRANSFORMATION_HEADER_ATTESTER_ORGANIZATION_MUST_CONTAIN_SOR_ID`: Composition.attester.party Organization must contain SOR identifier: %s
* `TRANSFORMATION_HEADER_CUSTODIAN_MUST_CONTAIN_SOR_ID`: Custodian organization must contain SOR identifier: %s
* `TRANSFORMATION_HEADER_COMPOSITION_HAS_NO_TIMEZONE_OR_SECONDS`: Composition has no timezone or seconds set: %s
* `TRANSFORMATION_XDS_PROPERTY_MISSING_EXCEPTION`: '%s' is missing which is required for document sharing. DocumentReference id: '%s'.
* `TRANSFORMATION_XDS_PROPERTY_CODE_INVALID_EXCEPTION`: '%s' is required for document sharing but the specified coding is not valid for the valueSet '%s': system=%s, code=%s, display=%s. DocumentReference id: '%s'
* `TRANSFORMATION_FROM_XHTML_TO_CDA_XML_FAILED`: Unable to transform XHTML to CDA XML format
* `TRANSFORMATION_FROM_CDA_XML_TO_XHTML_FAILED`: Unable to tranform CDA XML to XHTML format
* `TRANSFORMATION_XSLT_CONFIGURATION_ERROR`: Error creating XLST transformer: %s
* `TRANSFORMATION_XSD_CONFIGURATION_ERROR`: Error creating XSD transformer: %s
* `TRANSFORMATION_APD_XML_MISSING`: Invalid input document reference, it must contain content with data of APD xml

#### ehealth-upload

* `UPLOAD_QFDD_MASTERIDENTIFIER_IS_ALREADY_IN_USE`: The masterIdentifier on the DocumentReference is not unique
* `UPLOAD_QFDD_THE_ID_OF_THE_DOCUMENT_IS_NULL`: Missing Id in the QFDD.

#### ehealth-use

* `USE_CONTEXT_VALIDATION_FAILED`: UseContext validation for %s failed: value code %s not found in %s ValueSet

#### ehealth-versioning

* `VERSIONING_RESOURCE_MUST_BE_FROM_CURRENT_ENVIRONMENT`: Versioning validation error: Resource must be from current environment: %s.
* `VERSIONING_MULTIPLE_DRAFTS_IN_BASE_NOT_ALLOWED`: Versioning validation error: Only one draft resource at a time is allowed per base.
* `VERSIONING_RESOURCE_NOT_ELIGIBLE_FOR_CLONE`: Versioning validation error: A resource must have base-identifier, environment-identifier, versioning-identifier and version to be cloned.
* `VERSIONING_REFERENCE_NOT_RELEVANT_FOR_RESOURCE`: Versioning validation error: References included in deep_clone_references must be present in resource to clone, %s: %s.
* `VERSIONING_REFERENCE_MISSING_IN_TREE_PATH`: Versioning validation error: The following resources could not be cloned since their parent resource, %s, is not present in deep_clone_refernces: %s.

