# NPU DK - eHealth Infrastructure v10.0.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NPU DK**

## CodeSystem: NPU DK 

| | |
| :--- | :--- |
| *Official URL*:urn:oid:1.2.208.176.2.1 | *Version*:10.0.2 |
| Active as of 2019-12-18 | *Computable Name*:npu-dk |
| *Other Identifiers:*OID:1.2.208.176.2.1 | |

 
It is the translation into Danish of the International NPU Terminology. The NPU terminology defines types of clinical laboratory results expressed as patient properties, with measurement units where relevant, and with individual identifiers. The NPU terminology is owned by: the International Union of Pure and Applied Chemistry (IUPAC) and the International Federation of Clinical Chemistry and laboratory medicine (IFCC). The Danish Health Data Authority (see OID {iso(1) member-body(2) dk(208) nsi(176)}) serves as the international repository for the international version. Child OIDs may be registered by the Danish Health Data Authority on decision by the NPU Terminology Steering Committee. OIDs for the national versions are registered by the National Release Centers. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Device Measurement Unit](ValueSet-ehealth-device-measurement-unit.md)
* [Observation Codes](ValueSet-ehealth-observation-codes.md)
* [MedCom PHMR Observation ValueSet](ValueSet-phmr-observation-vs.md)
* [DK_IHE_EventCodeLists_VS](ValueSet-dk-ihe-eventcodelists-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "1.2.208.176.2.1--20190829",
  "url" : "urn:oid:1.2.208.176.2.1",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.208.176.2.1"
  }],
  "version" : "10.0.2",
  "name" : "npu-dk",
  "title" : "NPU DK",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-12-18T23:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "It is the translation into Danish of the International NPU Terminology. The NPU terminology defines types of clinical laboratory results expressed as patient properties, with measurement units where relevant, and with individual identifiers. The NPU terminology is owned by: the International Union of Pure and Applied Chemistry (IUPAC) and the International Federation of Clinical Chemistry and laboratory medicine (IFCC). The Danish Health Data Authority (see OID {iso(1) member-body(2) dk(208) nsi(176)}) serves as the international repository for the international version. Child OIDs may be registered by the Danish Health Data Authority on decision by the NPU Terminology Steering Committee. OIDs for the national versions are registered by the National Release Centers.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [{
    "code" : "phmr-unit",
    "uri" : "http://ehealth.sundhed.dk/cs/ehealth-property#phmr-unit",
    "type" : "string"
  }],
  "concept" : [{
    "code" : "NPU02193",
    "display" : "P(kB;fPt)—Glucose; stofk. = ? mmol/L",
    "definition" : "P(kB;fPt)—Glucose; stofk. = ? mmol/L",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Fastende blodsukker"
    }]
  },
  {
    "code" : "NPU03011",
    "display" : "Hb(Fe; O2-bind.; aB)—Oxygen(O2); mætn. = ?",
    "definition" : "Hb(Fe; O2-bind.; aB)—Oxygen(O2); mætn. = ?",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Iltmætning"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "O2 sat.;Hb(aB)"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "BLANK"
    }]
  },
  {
    "code" : "NPU22089",
    "display" : "P(kB)—Glucose; stofk. = ? mmol/L",
    "definition" : "P(kB)—Glucose; stofk. = ? mmol/L",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Glukose"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "Glukose;P(kB)"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "mmol/L"
    }]
  },
  {
    "code" : "NPU27281",
    "display" : "Pt—Legeme; massekoefficient(masse/kvadreret højde) = ? kg/m²",
    "definition" : "Pt—Legeme; massekoefficient(masse/kvadreret højde) = ? kg/m²",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "BMI"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "BMI;Pt"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "kg/m²"
    }]
  },
  {
    "code" : "NPU03804",
    "display" : "Pt—Legeme; masse = ? kg",
    "definition" : "Pt—Legeme; masse = ? kg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Vægt"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "Legeme vægt;Pt"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "kg"
    }]
  },
  {
    "code" : "NPU21692",
    "display" : "Hjerte—Systole; frekv. = ? × 1/min",
    "definition" : "Hjerte—Systole; frekv. = ? × 1/min",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Puls"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "Puls;Hjerte"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "1/min"
    }]
  },
  {
    "code" : "NPU03794",
    "display" : "Pt—Legeme; højde = ? m",
    "definition" : "Pt—Legeme; højde = ? m",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Højde"
    }]
  },
  {
    "code" : "NPU03963",
    "display" : "U—Erythrocytter; arb.k.(proc.) = ?",
    "definition" : "U—Erythrocytter; arb.k.(proc.) = ?",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Erytrocytter(semikvant)"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "Erytrocytter(semikvant);U"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "BLANK"
    }]
  },
  {
    "code" : "NPU08676",
    "display" : "Pt—Legeme; temp. = ? °C",
    "definition" : "Pt—Legeme; temp. = ? °C",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Temperatur"
    }]
  },
  {
    "code" : "NPU19748",
    "display" : "P—C-reaktivt protein; massek. = ? mg/L",
    "definition" : "P—C-reaktivt protein; massek. = ? mg/L",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "C-reaktivt protein"
    },
    {
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "C-reaktivt protein [CRP];P"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "mg/L"
    }]
  },
  {
    "code" : "DNK05463",
    "display" : "Ankel(højre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "definition" : "Ankel(højre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Ankeltryk højre"
    }]
  },
  {
    "code" : "DNK05465",
    "display" : "Tå(højre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "definition" : "Tå(højre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Tåtryk højre"
    }]
  },
  {
    "code" : "DNK05467",
    "display" : "Ankel(venstre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "definition" : "Ankel(venstre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Ankeltryk venstre"
    }]
  },
  {
    "code" : "DNK05469",
    "display" : "Tå(venstre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "definition" : "Tå(venstre)—Blodtryk(systolisk); tryk(liggende) = ? mmHg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://terminology.hl7.org/CodeSystem/hl7TermMaintInfra",
        "code" : "consumer"
      },
      "value" : "Tåtryk venstre"
    }]
  },
  {
    "code" : "DNK05472",
    "display" : "Blodtryk systolisk;Arm",
    "definition" : "Arm—Blodtryk(systolisk); tryk = ? mmHg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "Blodtryk systolisk;Arm"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "mmHg"
    }]
  },
  {
    "code" : "DNK05473",
    "display" : "Blodtryk diastolisk;Arm",
    "definition" : "Arm—Blodtryk(diastolisk); tryk = ? mmHg",
    "designation" : [{
      "language" : "da",
      "use" : {
        "system" : "http://ehealth.sundhed.dk/cs/ehealth-designation-use",
        "code" : "phmr-short-name"
      },
      "value" : "Blodtryk diastolisk;Arm"
    }],
    "property" : [{
      "code" : "phmr-unit",
      "valueString" : "mmHg"
    }]
  }]
}

```
