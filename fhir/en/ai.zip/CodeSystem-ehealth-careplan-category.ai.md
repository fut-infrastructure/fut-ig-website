# CarePlan Category - eHealth Infrastructure v11.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CarePlan Category**

## CodeSystem: CarePlan Category 

| | |
| :--- | :--- |
| *Official URL*:http://ehealth.sundhed.dk/cs/careplan-category | *Version*:11.0.4 |
| Active as of 2019-01-29 | *Computable Name*:CarePlanCategory |

 
Care Plan Category 

This Code system is referenced in the definition of the following value sets:

* [Careplan Category](ValueSet-ehealth-careplan-category.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ehealth-careplan-category",
  "url" : "http://ehealth.sundhed.dk/cs/careplan-category",
  "version" : "11.0.4",
  "name" : "CarePlanCategory",
  "title" : "CarePlan Category",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-01-29T00:00:00+00:00",
  "publisher" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
  "contact" : [{
    "name" : "Den telemedicinske infrastruktur (eHealth Infrastructure)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ehealth.sundhed.dk"
    }]
  }],
  "description" : "Care Plan Category",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [{
    "code" : "deprecated",
    "uri" : "http://hl7.org/fhir/concept-properties#deprecated",
    "description" : "Indicates that the concept is deprecated and should not be used",
    "type" : "dateTime"
  }],
  "concept" : [{
    "code" : "TBD",
    "display" : "Example value - Under construction",
    "definition" : "Example value - Under construction",
    "property" : [{
      "code" : "deprecated",
      "valueDateTime" : "2020-02-03"
    }]
  },
  {
    "code" : "TBD2",
    "display" : "Example value 2 - Under construction",
    "definition" : "Example value 2 - Under construction",
    "property" : [{
      "code" : "deprecated",
      "valueDateTime" : "2020-02-03"
    }]
  }]
}

```
